export {};
//# sourceMappingURL=AcDbLibreDwgParserWorker.d.ts.map