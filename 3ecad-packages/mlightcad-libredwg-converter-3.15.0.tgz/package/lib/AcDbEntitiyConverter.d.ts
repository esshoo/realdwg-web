import { AcDbEntity } from '@mlightcad/data-model';
import type { DwgEntity } from '@mlightcad/libredwg-web';
export declare class AcDbEntityConverter {
    convert(entity: DwgEntity): AcDbEntity | null;
    /**
     * Create the corresponding drawing database entity from data in dxf format
     * @param entity Input entity data in dxf format
     * @returns Return the converted drawing database entity
     */
    private createEntity;
    /**
     * Converts a DWG ACAD_PROXY_ENTITY to an AcDbProxyEntity.
     */
    private convertProxyEntity;
    private convertFace;
    private convertArc;
    private convertCirle;
    private convertEllipse;
    private convertLine;
    private convertSpline;
    private convertPoint;
    private convertShape;
    private convertSolid;
    private convertLWPolyline;
    private convertPolyline2d;
    private convertPolyline3d;
    private convertHatch;
    private convertTable;
    private convertText;
    private convertArcAlignedText;
    private convertTolerance;
    private convertMText;
    private convertLeader;
    private convertMLine;
    private convertMLeader;
    private convertDimension;
    private processImage;
    private convertImage;
    private convertWipeout;
    private convertOleFrame;
    private convertOle2Frame;
    private convertViewport;
    private convertRay;
    private convertXline;
    private convertAttributeCommon;
    private convertAttribute;
    private convertAttributeDefinition;
    private convertBlockReference;
    private processDimensionCommonAttrs;
    private processCommonAttrs;
    private applyExtendedData;
    private convertMLeaderEntityColor;
    private readMLeaderEntityColor;
    private isValidHandleId;
    private readNumber;
    private readPositiveNumber;
    private readString;
    private readBoolean;
    private readPoint;
    private readLeaderLineArray;
    private readMLeaderLeaders;
    private readMLeaderLine;
    private readMLeaderBreaks;
    private isPointLike;
}
//# sourceMappingURL=AcDbEntitiyConverter.d.ts.map