export declare function parseDwg(data: string): Promise<{
    database: import("@mlightcad/libredwg-web").DwgDatabase;
    stats: {
        unknownEntityCount: number;
    };
}>;
//# sourceMappingURL=AcDbLibreDwgConverterUtil.d.ts.map