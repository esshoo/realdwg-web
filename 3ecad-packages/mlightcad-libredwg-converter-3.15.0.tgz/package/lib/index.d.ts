export { AcDbLibreDwgConverter } from './AcDbLibreDwgConverter';
//# sourceMappingURL=index.d.ts.map