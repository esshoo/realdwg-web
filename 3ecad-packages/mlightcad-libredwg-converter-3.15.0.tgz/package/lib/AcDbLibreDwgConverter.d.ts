import { AcDbConversionProgressCallback, AcDbDatabase, AcDbDatabaseConverter, AcDbDatabaseConverterConfig, AcDbParsingTaskResult } from '@mlightcad/data-model';
import { DwgDatabase } from '@mlightcad/libredwg-web';
/**
 * Database converter for DWG files based on [libredwg-web](https://github.com/mlight-lee/libredwg-web).
 */
export declare class AcDbLibreDwgConverter extends AcDbDatabaseConverter<DwgDatabase> {
    constructor(config?: AcDbDatabaseConverterConfig);
    protected parse(data: ArrayBuffer, timeout?: number): Promise<AcDbParsingTaskResult<DwgDatabase>>;
    protected processLineTypes(model: DwgDatabase, db: AcDbDatabase): void;
    protected processTextStyles(model: DwgDatabase, db: AcDbDatabase): void;
    protected processDimStyles(model: DwgDatabase, db: AcDbDatabase): void;
    protected processLayers(model: DwgDatabase, db: AcDbDatabase): void;
    /**
     * Maps a libredwg-web {@link DwgLayerTableEntry} colour onto {@link AcCmColor}.
     *
     * `libredwg-web` `convertLayer` leaves `colorIndex` at the ByLayer sentinel
     * **256** for CMC method `0xC2` while storing the real CMC RGB in `color`.
     * Layer colours cannot be ByLayer — treating 256 as ByLayer washes legend
     * solid fills white (same failure mode as dwg-converter's Index/256 bug).
     */
    private applyLibreLayerColor;
    protected processViewports(model: DwgDatabase, db: AcDbDatabase): void;
    protected processBlockTables(model: DwgDatabase, db: AcDbDatabase): void;
    protected processBlocks(_model: DwgDatabase, _db: AcDbDatabase): void;
    private processEntitiesInBlock;
    /**
     * Breaks up the work into smaller chunks that are executed asynchronously. This is often referred to
     * as "batch processing" or "cooperative multitasking," where the time-consuming task is broken into
     * smaller pieces and executed in small intervals to allow the UI to remain responsive.
     */
    protected processEntities(model: DwgDatabase, db: AcDbDatabase, minimumChunkSize: number, startPercentage: {
        value: number;
    }, progress?: AcDbConversionProgressCallback): Promise<void>;
    protected processClasses(model: DwgDatabase, db: AcDbDatabase): void;
    protected processHeader(model: DwgDatabase, db: AcDbDatabase): void;
    private processCommonTableEntryAttrs;
    protected processObjects(model: DwgDatabase, db: AcDbDatabase): void;
    /**
     * Imports extension dictionaries and (when present) representation pointers
     * so {@link AcDbDynBlockReference} works with LibreDWG-parsed drawings.
     *
     * LibreDWG does not expose a typed `ACDB_BLOCKREPRESENTATION_DATA` object;
     * we still import the dictionary graph so `AcDbBlockRepresentation` /
     * `ACAD_ENHANCEDBLOCK` keys resolve. When a dictionary entry named
     * `AcDbRepData` points at a handle that is not a converted object, a
     * placeholder is created by {@link acdbImportDynBlockMetadata}.
     */
    private processDynBlockMetadata;
    /**
     * Reconstructs the Layer Manager filter tree (`AcLy*` classes) from the
     * `ACAD_LAYERFILTERS` / `ACLYDICTIONARY` dictionaries and their XRecords.
     *
     * @remarks
     * Reads `DICTIONARY` and `XRECORD` objects from the parsed DWG. When either
     * collection is empty, nested filter payloads are unavailable and this
     * method is a no-op.
     *
     * @param model - Parsed DWG database.
     * @param db - Target database whose {@link AcDbDatabase.layerFilters} is set.
     */
    private processLayerFilterTree;
    private processLayouts;
    private processImageDefs;
    private processLayerFilters;
    private processLayerIndexes;
    private processMLeaderStyles;
    private processCommonObjectAttrs;
    /**
     * Groups entities by their `type` property and flattens the result into a single array.
     *
     * The order of `type` groups follows the order in which they first appear in the input array.
     * Items within each group preserve their original order.
     *
     * This runs in O(n) time, which is generally faster than sorting when you
     * don't care about alphabetical order of types.
     *
     * @param entities - The array of entities to group and flatten.
     *
     * @returns A new array of entities grouped by their `type` property.
     */
    private groupAndFlattenByType;
    private isModelSpace;
    private normalizeHeaderStringValue;
}
//# sourceMappingURL=AcDbLibreDwgConverter.d.ts.map