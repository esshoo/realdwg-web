import { AcDbLayerFilter, AcDbLayerIndex, AcDbMLeaderStyle } from '@mlightcad/data-model';
import { DwgLayerFilterObject, DwgLayerIndexObject, DwgMLeaderStyleObject } from '@mlightcad/libredwg-web';
/**
 * Converts libredwg object records to AcDbObject instances.
 */
export declare class AcDbObjectConverter {
    /**
     * Converts a DWG MLEADERSTYLE object to an AcDbMLeaderStyle.
     */
    convertMLeaderStyle(style: DwgMLeaderStyleObject): AcDbMLeaderStyle;
    /**
     * Converts a DWG LAYER_FILTER object to an AcDbLayerFilter.
     *
     * @param filter - The DWG layer filter object to convert
     * @returns The converted AcDbLayerFilter instance
     */
    convertLayerFilter(filter: DwgLayerFilterObject): AcDbLayerFilter;
    /**
     * Converts a DWG LAYER_INDEX object to an AcDbLayerIndex.
     *
     * @param index - The DWG layer index object to convert
     * @returns The converted AcDbLayerIndex instance
     */
    convertLayerIndex(index: DwgLayerIndexObject): AcDbLayerIndex;
    private processCommonAttrs;
}
//# sourceMappingURL=AcDbObjectConverter.d.ts.map