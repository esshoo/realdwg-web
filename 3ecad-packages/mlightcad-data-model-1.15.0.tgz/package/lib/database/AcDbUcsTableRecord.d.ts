import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbSymbolTableRecord, AcDbSymbolTableRecordAttrs } from './AcDbSymbolTableRecord';
/**
 * Attributes for a UCS table record.
 */
export interface AcDbUcsTableRecordAttrs extends AcDbSymbolTableRecordAttrs {
    /** Standard flags (group 70) */
    standardFlags: number;
    /** UCS origin */
    origin: AcGePoint3d;
    /** UCS X axis direction */
    xAxis: AcGePoint3d;
    /** UCS Y axis direction */
    yAxis: AcGePoint3d;
    /** Whether this UCS is orthographic (DXF group 79) */
    isOrthographic: boolean;
    /** Elevation of this UCS (DXF group 146) */
    elevation: number;
    /**
     * ID/handle of the base UCS when this UCS is orthographic; assumed to be
     * WORLD if absent (DXF group 346)
     */
    baseUcsId?: string;
    /**
     * Orthographic type paired with {@link orthographicOrigin}: 1=Top,
     * 2=Bottom, 3=Front, 4=Back, 5=Left, 6=Right (DXF group 71)
     */
    orthographicType?: number;
    /**
     * Origin for {@link orthographicType} relative to this UCS
     * (DXF groups 13/23/33)
     */
    orthographicOrigin?: AcGePoint3d;
}
/**
 * Named User Coordinate System table record (DXF UCS table).
 */
export declare class AcDbUcsTableRecord extends AcDbSymbolTableRecord<AcDbUcsTableRecordAttrs> {
    constructor(attrs?: Partial<AcDbUcsTableRecordAttrs>, defaultAttrs?: Partial<AcDbUcsTableRecordAttrs>);
    get standardFlags(): number;
    set standardFlags(value: number);
    get origin(): AcGePoint3d;
    set origin(value: AcGePoint3d);
    get xAxis(): AcGePoint3d;
    set xAxis(value: AcGePoint3d);
    get yAxis(): AcGePoint3d;
    set yAxis(value: AcGePoint3d);
    /** Whether this UCS is orthographic (DXF group 79). */
    get isOrthographic(): boolean;
    set isOrthographic(value: boolean);
    /** Elevation of this UCS (DXF group 146). */
    get elevation(): number;
    set elevation(value: number);
    /**
     * ID/handle of the base UCS when this UCS is orthographic (DXF group 346).
     */
    get baseUcsId(): string | undefined;
    set baseUcsId(value: string | undefined);
    /**
     * Orthographic type paired with {@link orthographicOrigin}
     * (DXF group 71).
     */
    get orthographicType(): number | undefined;
    set orthographicType(value: number | undefined);
    /**
     * Origin for {@link orthographicType} relative to this UCS
     * (DXF groups 13/23/33).
     */
    get orthographicOrigin(): AcGePoint3d | undefined;
    set orthographicOrigin(value: AcGePoint3d | undefined);
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbUcsTableRecord.d.ts.map