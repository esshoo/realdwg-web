export interface AcDbDwgVersionEntry {
    name: string;
    value: number;
}
/**
 * Represents a DWG file format version.
 *
 * Instances can be constructed from either a known DWG version name
 * (e.g. 'AC1032') or its numeric value counterpart.
 */
/**
 * DXF dialect capabilities derived from {@link AcDbDwgVersion}.
 *
 * Thresholds follow Autodesk DXF Reference / ObjectARX AcDb::AcDbDwgVersion:
 * - R13 (AC1012, value 19): handles, subclass markers, CLASSES, OBJECTS,
 *   BLOCK_RECORD, LWPOLYLINE
 * - 2000 (AC1015, value 23): lineweight (370)
 * - 2004 (AC1018, value 25): true color (420), transparency (440)
 * - 2007 (AC1021, value 27): UTF-8 `$DWGCODEPAGE`
 */
export interface AcDbDxfVersionCapabilities {
    /** R13+: entity/object handles (group 5 / 105) and soft/hard pointers. */
    supportsHandles: boolean;
    /** R13+: group 100 subclass markers. */
    supportsSubclassMarkers: boolean;
    /** R13+: CLASSES section. */
    supportsClassesSection: boolean;
    /** R13+: OBJECTS section. */
    supportsObjectsSection: boolean;
    /** R13+: BLOCK_RECORD table. */
    supportsBlockRecordTable: boolean;
    /** R13+: LWPOLYLINE entity (R12 uses POLYLINE + VERTEX). */
    supportsLwPolyline: boolean;
    /** AutoCAD 2000+: lineweight group 370. */
    supportsLineWeight: boolean;
    /** AutoCAD 2004+: true color group 420. */
    supportsTrueColor: boolean;
    /** AutoCAD 2004+: transparency group 440. */
    supportsTransparency: boolean;
    /** AutoCAD 2007+: emit `$DWGCODEPAGE` as UTF-8. */
    supportsUtf8CodePage: boolean;
}
export declare class AcDbDwgVersion {
    /**
     * DWG version name as defined in `AcDbDwgVersionEntry.name`.
     */
    name: string;
    /**
     * Numeric DWG version value as defined in `AcDbDwgVersionEntry.value`.
     */
    value: number;
    /**
     * Create a DWG version from a version name or numeric value.
     *
     * If a string is provided, it is treated as the version name and must
     * match one of the known entries. If a number is provided, it is treated
     * as the numeric version value.
     *
     * @param nameOrValue The DWG version name (e.g. 'AC1032') or the DWG version numeric value.
     * @throws Error if the provided name or value is not recognized.
     */
    constructor(nameOrValue: string | number);
    /** DXF write/read dialect flags for this version. */
    get capabilities(): AcDbDxfVersionCapabilities;
    /** Latest known drawing version (all modern DXF features enabled). */
    static get latest(): AcDbDwgVersion;
    static capabilitiesFor(value: number): AcDbDxfVersionCapabilities;
}
//# sourceMappingURL=AcDbDwgVersion.d.ts.map