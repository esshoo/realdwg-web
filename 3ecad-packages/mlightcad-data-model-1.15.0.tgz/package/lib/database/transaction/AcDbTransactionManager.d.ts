import { AcDbTransaction } from './AcDbTransaction';
/**
 * Manages database transactions.
 *
 * @deprecated Use {@link AcDbDatabaseTransactionManager} via
 * {@link AcDbDatabase.transactionManager} for database-bound transactions,
 * undo/redo, and change recording.
 */
export declare class AcDbTransactionManager {
    /** Stack of active transactions */
    private readonly transactionStack;
    /**
     * Starts a new transaction and pushes it onto the stack.
     *
     * Equivalent to AcDbTransactionManager::startTransaction().
     *
     * @returns The newly created transaction
     */
    startTransaction(): AcDbTransaction;
    /**
     * Returns the top-most active transaction.
     *
     * @returns The current transaction or undefined if none exists
     */
    currentTransaction(): AcDbTransaction | undefined;
    /**
     * Commits the current transaction.
     *
     * Changes made during the transaction become permanent.
     *
     * @throws Error if no transaction is active
     */
    commitTransaction(): void;
    /**
     * Aborts the current transaction.
     *
     * All changes made during the transaction are rolled back.
     *
     * @throws Error if no transaction is active
     */
    abortTransaction(): void;
    /**
     * Returns true if at least one transaction is active.
     */
    hasTransaction(): boolean;
}
//# sourceMappingURL=AcDbTransactionManager.d.ts.map