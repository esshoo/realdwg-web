import { AcDbUndoRecord } from './AcDbUndoRecord';
/**
 * Manages undo and redo history for database changes.
 *
 * Stores committed {@link AcDbUndoRecord} entries and clears the redo stack
 * whenever a new undo record is pushed.
 */
export declare class AcDbUndoStack {
    private readonly undoRecords;
    private readonly redoRecords;
    /** Maximum number of undo records retained. */
    maxDepth: number;
    /**
     * Pushes a new undo record and clears redo history.
     *
     * When {@link maxDepth} is exceeded, the oldest undo record is discarded.
     *
     * @param record - Undo record produced by {@link AcDbDatabaseTransactionManager}
     */
    push(record: AcDbUndoRecord): void;
    /**
     * Removes and returns the most recent undo record.
     *
     * @returns The record popped from the undo stack, or undefined when empty
     */
    popUndo(): AcDbUndoRecord | undefined;
    /**
     * Stores an undo record on the redo stack after {@link popUndo}.
     *
     * @param record - Record that was just undone and may be redone
     */
    pushRedo(record: AcDbUndoRecord): void;
    /**
     * Removes and returns the most recent redo record.
     *
     * @returns The record popped from the redo stack, or undefined when empty
     */
    popRedo(): AcDbUndoRecord | undefined;
    /**
     * Returns true when at least one undo record is available.
     */
    canUndo(): boolean;
    /**
     * Returns true when at least one redo record is available.
     */
    canRedo(): boolean;
    /**
     * Discards all undo and redo records.
     */
    clear(): void;
}
//# sourceMappingURL=AcDbUndoStack.d.ts.map