import { AcDbObject } from '../../base';
import { AcDbDatabase } from '../AcDbDatabase';
import { AcDbChangeContainer, AcDbDatabaseChange } from './AcDbDatabaseChange';
/**
 * Accumulates structured database changes during an active transaction.
 *
 * Append/remove pairs that cancel within the same transaction are coalesced,
 * and duplicate modify/sysvar entries for the same target are ignored.
 */
export declare class AcDbChangeRecorder {
    private readonly changes;
    /**
     * Returns the changes recorded so far in this transaction.
     *
     * The returned array is the internal store; callers should treat it as read-only.
     */
    getChanges(): AcDbDatabaseChange[];
    /**
     * Discards all recorded changes without applying them.
     */
    clear(): void;
    /**
     * Merges changes from a nested transaction into this recorder.
     *
     * Used when an inner transaction commits into its parent without touching
     * the undo stack.
     *
     * @param other - Recorder from a child transaction being committed
     */
    mergeFrom(other: AcDbChangeRecorder): void;
    /**
     * Records the pre-modification snapshot of an opened-for-write object.
     *
     * Only the first modify entry per {@link AcDbObject.objectId} is kept.
     *
     * @param object - Object whose state should be restorable on abort/undo
     */
    recordModify(object: AcDbObject): void;
    /**
     * Returns true when a modify entry exists for the given object ID.
     *
     * Used by {@link AcDbDatabaseTransactionManager.isOpenedForWriteInTransaction}
     * to determine whether a symbol table record was opened for write within the
     * active transaction stack.
     *
     * @param objectId - Object identifier to look up
     */
    hasModify(objectId: string): boolean;
    /**
     * Records insertion of an object into a database container.
     *
     * If a matching remove was recorded earlier in the same transaction,
     * the pair cancels and neither change is retained.
     *
     * @param container - Container that received the object
     * @param object - Object that was appended; stored as an identity-preserving clone
     */
    recordAppend(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records removal of an object from a database container.
     *
     * If a matching append was recorded earlier in the same transaction,
     * the pair cancels and neither change is retained.
     *
     * @param container - Container that owned the removed object
     * @param object - Object that was removed; stored as an identity-preserving clone
     */
    recordRemove(container: AcDbChangeContainer, object: AcDbObject): void;
    /**
     * Records the value of a system variable before mutation.
     *
     * Only the first sysvar entry per normalized name is kept.
     *
     * @param name - System variable name (case-insensitive)
     * @param before - Value observed before the mutation
     */
    recordSysvar(name: string, before: unknown): void;
    /**
     * Captures the post-change state for modify and sysvar entries at commit time.
     *
     * Append/remove entries are complete when recorded and do not require
     * finalization.
     *
     * @param database - Database used to read live post-commit values
     */
    finalize(database: AcDbDatabase): void;
    /**
     * Records or coalesces one append/remove change.
     *
     * When an opposite structural change for the same container and object ID
     * already exists in this transaction, both entries cancel and neither is kept.
     *
     * @param change - Append or remove entry to merge into the recorder
     */
    private recordStructuralChange;
    /**
     * Merges one change from a nested transaction into this recorder.
     *
     * Modify and sysvar entries deduplicate by object ID or variable name;
     * structural entries use the same cancel/coalesce rules as {@link recordAppend}.
     *
     * @param change - Change copied from a child transaction recorder
     */
    private mergeChange;
    /**
     * Finds the index of a structural change matching kind, container, and object ID.
     *
     * @param kind - Append or remove kind to search for
     * @param container - Container descriptor that must match exactly
     * @param objectId - Object identifier of the affected record
     * @returns Index in {@link changes}, or `-1` when no match exists
     */
    private findStructuralChangeIndex;
    /**
     * Reads the current value of a system variable from the database.
     *
     * @param database - Database passed to {@link AcDbSysVarManager.getVar}
     * @param name - Normalized system variable name
     * @returns Live variable value used to populate `after` during {@link finalize}
     */
    private getSysvarValue;
}
//# sourceMappingURL=AcDbChangeRecorder.d.ts.map