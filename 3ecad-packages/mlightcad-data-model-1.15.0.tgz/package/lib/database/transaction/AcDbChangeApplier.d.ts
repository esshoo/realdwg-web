import { AcDbObject } from '../../base';
import { AcDbEntity } from '../../entity/AcDbEntity';
import { AcDbDatabase, AcDbLayerModifiedEventArgs } from '../AcDbDatabase';
import { AcDbLayerTableRecord, AcDbLayerTableRecordAttrs } from '../AcDbLayerTableRecord';
import { AcDbDatabaseChange } from './AcDbDatabaseChange';
/**
 * Applies forward or inverse database changes for undo/redo operations.
 *
 * Structural changes (append/remove) and property snapshots (modify/sysvar)
 * are replayed against a live {@link AcDbDatabase} instance.
 */
export declare class AcDbChangeApplier {
    private readonly database;
    /**
     * Creates an applier bound to one database.
     *
     * @param database - Database whose containers and objects receive replayed changes
     */
    constructor(database: AcDbDatabase);
    /**
     * Replays changes in commit order.
     *
     * Used by redo and by applying the forward direction of an undo record.
     *
     * @param changes - Ordered list of changes recorded by {@link AcDbChangeRecorder}
     */
    applyForward(changes: AcDbDatabaseChange[]): void;
    /**
     * Replays the inverse of each change in reverse order.
     *
     * Used by undo and transaction abort to restore the prior database state.
     *
     * @param changes - Ordered list of changes recorded by {@link AcDbChangeRecorder}
     */
    applyInverse(changes: AcDbDatabaseChange[]): void;
    /**
     * Dispatches one recorded change in the requested direction.
     *
     * @param change - Single entry from a transaction or undo record
     * @param forward - When true, replay the original mutation; when false, apply its inverse
     */
    private applyChange;
    /**
     * Restores object property state from a modify snapshot.
     *
     * @param change - Modify entry with before/after clones
     * @param forward - When true, apply `after`; when false, apply `before`
     */
    private applyModify;
    /**
     * Restores a system variable from a sysvar snapshot.
     *
     * @param change - Sysvar entry with before/after values
     * @param forward - When true, apply `after`; when false, apply `before`
     */
    private applySysvar;
    /**
     * Re-inserts an object into the container described by `container`.
     *
     * @param container - Target block table record, symbol table, or dictionary entry
     * @param object - Object snapshot to append
     */
    private applyAppend;
    /**
     * Removes an object from the container described by `container`.
     *
     * @param container - Source block table record, symbol table, or dictionary entry
     * @param object - Object whose {@link AcDbObject.objectId} identifies the removal target
     */
    private applyRemove;
    /**
     * Resolves a symbol table instance from the stable name stored in undo records.
     *
     * @param tableName - Logical table name (for example, `"layerTable"`) or unknown fallback ID
     * @returns Matching table on this applier's database, or undefined when unrecognized
     */
    private getSymbolTable;
}
/**
 * Collects entities affected by changes for post-commit/undo/redo event dispatch.
 *
 * Only block-table-record append/remove operations contribute to the
 * appended and erased lists; modify entries always resolve through object IDs.
 *
 * @param database - Database used to resolve live entity references
 * @param changes - Changes produced by a transaction or undo record
 * @returns Entity buckets keyed by the kind of structural or property change
 */
export declare function acdbCollectChangeEntities(database: AcDbDatabase, changes: AcDbDatabaseChange[]): {
    /** Entities whose properties were modified */
    modified: AcDbEntity[];
    /** Entities appended to a block table record */
    appended: AcDbEntity[];
    /** Entities removed from a block table record */
    erased: AcDbEntity[];
};
/**
 * One dictionary entry referenced by an append or remove change.
 */
export interface AcDbDictionaryChangeEntry {
    /** Dictionary object that was set or erased */
    object: AcDbObject;
    /** Dictionary key associated with the object */
    key: string;
}
/**
 * Collects dictionary entries affected by changes for post-commit/undo/redo dispatch.
 *
 * @param database - Database used to resolve live object references after replay
 * @param changes - Changes produced by a transaction or undo record
 * @returns Dictionary entries grouped by set and erase operations
 */
export declare function acdbCollectDictionaryChanges(database: AcDbDatabase, changes: AcDbDatabaseChange[]): {
    /** Entries inserted or replaced in a dictionary */
    set: AcDbDictionaryChangeEntry[];
    /** Entries removed from a dictionary */
    erased: AcDbDictionaryChangeEntry[];
};
/**
 * Compares two layer table record snapshots and returns changed attribute values.
 *
 * @param before - State before modification
 * @param after - State after modification
 * @returns Changed attributes mapped to their values in `after`
 */
export declare function acdbDiffLayerTableRecordAttrs(before: AcDbLayerTableRecord, after: AcDbLayerTableRecord): Partial<AcDbLayerTableRecordAttrs>;
/**
 * Collects layer modification events from transaction or undo record changes.
 *
 * @param database - Database used to resolve live layer references
 * @param changes - Changes produced by a transaction or undo record
 * @param inverse - When true, compute diffs for undo replay
 * @returns Layer-modified event payloads for dispatch
 */
export declare function acdbCollectLayerModifications(database: AcDbDatabase, changes: AcDbDatabaseChange[], inverse?: boolean): AcDbLayerModifiedEventArgs[];
//# sourceMappingURL=AcDbChangeApplier.d.ts.map