import { AcCmTaskError } from '@mlightcad/common';
import type { AcDbDatabase } from './AcDbDatabase';
/**
 * Represents the different stages of DXF/DWG file conversion.
 *
 * These stages define the order and types of operations performed
 * during the conversion of a DXF or DWG file into an AcDbDatabase.
 */
export type AcDbConversionStage = 
/**
 * Start DXF/DWG file conversion
 */
'START'
/**
 * Parsing DXF/DWG file
 */
 | 'PARSE'
/**
 * Converting line types
 */
 | 'LTYPE'
/**
 * Converting text styles
 */
 | 'STYLE'
/**
 * Converting dimension styles
 */
 | 'DIMSTYLE'
/**
 * Converting layers
 */
 | 'LAYER'
/**
 * Converting viewports
 */
 | 'VPORT'
/**
 * Converting block table record
 */
 | 'BLOCK_RECORD'
/**
 * Converting file header
 */
 | 'HEADER'
/**
 * Converting blocks
 */
 | 'BLOCK'
/**
 * Converting entities in model space
 */
 | 'ENTITY'
/**
 * Converting objects such as nod
 */
 | 'OBJECT'
/**
 * Finish file conversion
 */
 | 'END';
/**
 * Represents the status of a stage.
 */
export type AcDbStageStatus = 'START' | 'END' | 'IN-PROGRESS' | 'ERROR';
/**
 * Callback function to update progress when parsing one file.
 *
 * This callback is called during the conversion process to provide
 * progress updates and stage information.
 *
 * @param percentage - Finish percentage (0-100)
 * @param stage - Name of the current stage
 * @param stageStatus - Status of the current stage
 * @param data - Store data associated with the current stage. Its meaning varies by stage:
 *   - 'PARSE' stage: statistics of parsing task
 *
 * @example
 * ```typescript
 * const progressCallback: AcDbConversionProgressCallback = async (
 *   percentage,
 *   stage,
 *   stageStatus,
 *   data
 * ) => {
 *   console.log(`Progress: ${percentage}% - Stage: ${stage} - Status: ${stageStatus}`);
 *   if (stage === 'PARSE' && data) {
 *     console.log('Parse stats:', data);
 *   }
 * };
 * ```
 */
export type AcDbConversionProgressCallback = (
/**
 * Finish percentage
 */
percentage: number, 
/**
 * Name of the current stage.
 */
stage: AcDbConversionStage, 
/**
 * Status of the current stage.
 */
stageStatus: AcDbStageStatus, 
/**
 * Store data associated with the current stage. Its meaning of different stages are as follows.
 * - 'PARSE' stage: statistics of parsing task
 *
 * Note: For now, 'PARSE' stages use this field only.
 */
data?: unknown, 
/**
 * Represents an error that occurred during task execution in the scheduler.
 */
error?: AcCmTaskError) => Promise<void>;
/**
 * Options for {@link AcDbDatabaseConverter.read}.
 *
 * Keeps the converter read API extensible without growing positional arguments.
 */
export interface AcDbDatabaseConverterReadOptions {
    /**
     * Minimum number of items in one processing chunk.
     *
     * Defaults to converter-specific behavior when omitted.
     */
    minimumChunkSize?: number;
    /**
     * Optional progress callback invoked as conversion stages advance.
     */
    progress?: AcDbConversionProgressCallback;
    /**
     * Timeout for parser web worker operations in milliseconds.
     */
    timeout?: number;
    /**
     * Override the text encoding used to decode strings in the source file.
     *
     * When omitted, converters auto-detect the encoding (DXF reads
     * `$DWGCODEPAGE`; DWG reads the header code page). When provided, it wins
     * over auto-detection — for example `'cp949'` (normalized to the supported
     * `'euc-kr'` `TextDecoder` label) for Korean drawings. Applies to
     * converters that read text in the main thread, such as the native DXF
     * converter; worker-based converters may ignore it.
     */
    encoding?: string;
    /**
     * System variables to override in the database after HEADER is processed.
     */
    sysVars?: Record<string, number | boolean | string>;
}
/**
 * Statistics of parsing task
 */
export interface AcDbParsingTaskStats {
    /**
     * The number of unknown types of entities (custom entities or entities not supported
     * by parser) in one drawing to parse
     */
    unknownEntityCount: number;
}
/**
 * Interface defining type of return value of parsing task.
 */
export interface AcDbParsingTaskResult<TModel> {
    model: TModel | undefined;
    data: AcDbParsingTaskStats;
}
/**
 * Interface defining performance data for database conversion.
 */
export interface AcDbConvertDatabasePerformanceData {
    [key: string]: number;
    total: number;
}
/**
 * Configuration options for database converters.
 *
 * This interface defines the configuration parameters that can be passed
 * to database converters to customize their behavior during the conversion
 * process.
 */
export interface AcDbDatabaseConverterConfig {
    /**
     * Optional URL for web worker scripts used in the conversion process.
     *
     * When provided, this URL points to a web worker script that can be used
     * for offloading computationally intensive parsing tasks to a background
     * thread, improving performance and preventing UI blocking.
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * };
     * ```
     */
    parserWorkerUrl?: string | URL;
    /**
     * Timeout for parser web worker operations in milliseconds.
     *
     * This applies only when parsing runs in a web worker.
     *
     * @default 30000
     */
    timeout?: number;
    /**
     * Whether to use web workers for parser execution.
     *
     * When set to `true`, the converter uses a web worker for parsing, which
     * keeps copyleft parser code out of the main bundle and avoids blocking
     * the UI thread.
     *
     * Copyleft converters (DXF/DWG) require worker parsing. Setting this to
     * `false` is only meaningful for converters that still support main-thread
     * parsing.
     *
     * @default true
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * };
     * ```
     */
    useWorker?: boolean;
    /**
     * Whether to convert entities grouped by type.
     *
     * When set to `true`, the converter will process entities one type
     * at a time (e.g., all lines, then all circles, then all polylines),
     * which can help optimize rendering performance or simplify debugging by
     * handling each entity type in isolation.
     *
     * When set to `false`, entities are converted in the order they
     * appear in the source file.
     *
     * @default false
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   convertByEntityType: true
     * };
     * ```
     */
    convertByEntityType?: boolean;
}
/**
 * Abstract base class for database converters.
 *
 * This class provides the foundation for converting various file formats
 * (such as DXF, DWG) into AcDbDatabase objects. It handles the conversion
 * process in stages and provides progress tracking capabilities.
 *
 * @template TModel - The type of the parsed model data
 *
 * @example
 * ```typescript
 * class MyConverter extends AcDbDatabaseConverter<MyModel> {
 *   protected parse(data: string | ArrayBuffer): MyModel {
 *     // Implementation for parsing data
 *   }
 *
 *   ......
 *
 *   protected processEntities(model: MyModel, db: AcDbDatabase) {
 *     // Implementation for processing entities
 *   }
 * }
 * ```
 */
export declare abstract class AcDbDatabaseConverter<TModel = unknown> {
    /** Optional progress callback for tracking conversion progress */
    progress?: AcDbConversionProgressCallback;
    /** Configuration for the converter */
    readonly config: AcDbDatabaseConverterConfig;
    /**
     * Creates a new instance of the database converter.
     *
     * @param config - Configuration options for the converter. This includes settings
     *                 such as worker URL for web workers used in the conversion process.
     *                 If not provided, an empty configuration object will be used.
     *
     * @example
     * ```typescript
     * // Create converter with default configuration
     * const converter = new AcDbDxfConverter();
     *
     * // Create converter with custom worker URL
     * const converter = new AcDbDxfConverter({
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * });
     * ```
     */
    constructor(config?: AcDbDatabaseConverterConfig);
    /**
     * Reads and converts data into an AcDbDatabase.
     *
     * This method orchestrates the entire conversion process, including
     * parsing, processing various components (linetypes, styles, etc.),
     * and building the final database.
     *
     * @param data - The input data to convert
     * @param db - The database to populate with converted data
     * @param options - Optional read options (chunk size, progress, etc.)
     * @returns Promise that resolves when conversion is complete
     *
     */
    read(data: ArrayBuffer, db: AcDbDatabase, options?: AcDbDatabaseConverterReadOptions): Promise<void>;
    protected onError(error: AcCmTaskError): boolean;
    protected onFinished(): void;
    /**
     * Resolves the parser worker timeout in milliseconds.
     *
     * Explicit timeout always takes precedence. Otherwise the timeout scales
     * linearly with file size at one extra second per MiB, clamped to the
     * range of 30 seconds to 2 minutes.
     */
    protected getParserWorkerTimeout(data: ArrayBuffer, timeout?: number): number;
    protected parse(_data: ArrayBuffer, _timeout?: number): Promise<AcDbParsingTaskResult<TModel>>;
    protected processLineTypes(_model: TModel, _db: AcDbDatabase): void;
    protected processTextStyles(_model: TModel, _db: AcDbDatabase): void;
    protected processDimStyles(_model: TModel, _db: AcDbDatabase): void;
    protected processLayers(_model: TModel, _db: AcDbDatabase): void;
    protected processViewports(_model: TModel, _db: AcDbDatabase): void;
    protected processHeader(_model: TModel, _db: AcDbDatabase): void;
    /**
     * Optional stage: CLASSES metadata only augments the database and older
     * converters predate it. A throwing default (like the mandatory stages
     * above) would break any converter compiled before this stage existed —
     * the HEADER task calls it unconditionally, so a data-model upgrade
     * without a matching converter upgrade aborted every file open with
     * "Error occurred in conversion stage HEADER" (mlightcad/cad-viewer#437).
     */
    protected processClasses(_model: TModel, _db: AcDbDatabase): void;
    protected processBlockTables(_model: TModel, _db: AcDbDatabase): void;
    protected processObjects(_model: TModel, _db: AcDbDatabase): void;
    protected processBlocks(_model: TModel, _db: AcDbDatabase): void;
    protected processEntities(_model: TModel, _db: AcDbDatabase, _minimumChunkSize: number, _percentage: {
        value: number;
    }, _progress?: AcDbConversionProgressCallback): void;
}
//# sourceMappingURL=AcDbDatabaseConverter.d.ts.map