import { AcGiTextStyle } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbSymbolTableRecord, AcDbSymbolTableRecordAttrs } from './AcDbSymbolTableRecord';
/**
 * Interface defining the attributes for text style table records.
 *
 * Merges {@link AcDbSymbolTableRecordAttrs} with {@link AcGiTextStyle} fields
 * (excluding the duplicate `name` property).
 */
export interface AcDbTextStyleTableRecordAttrs extends AcDbSymbolTableRecordAttrs, Omit<AcGiTextStyle, 'name'> {
}
/**
 * Represents a record in the text style table.
 *
 * This class represents the records that are found in the text style table (known as the "style"
 * table in DXF). Each of these records represents a specific set of text parameters such as font,
 * default size, relative x scaling, vertical or horizontal orientation, etc.
 *
 * @example
 * ```typescript
 * const record = new AcDbTextStyleTableRecord({
 *   name: 'MyStyle',
 *   font: 'Arial'
 * });
 * ```
 */
export declare class AcDbTextStyleTableRecord extends AcDbSymbolTableRecord<AcDbTextStyleTableRecordAttrs> {
    /**
     * Creates a new AcDbTextStyleTableRecord instance.
     *
     * Property `font` may be empty. When it contains a file extension, the extension is removed
     * during construction.
     *
     * @param attrs - Input attribute values for this text style table record
     * @param defaultAttrs - Default values for attributes of this text style table record
     *
     * @example
     * ```typescript
     * const record = new AcDbTextStyleTableRecord({
     *   name: 'MyStyle',
     *   font: 'Arial'
     * });
     * ```
     */
    constructor(attrs?: Partial<AcDbTextStyleTableRecordAttrs>, defaultAttrs?: Partial<AcDbTextStyleTableRecordAttrs>);
    /**
     * Gets or sets the obliquing angle.
     *
     * The obliquing angle is the angle from the text's vertical; that is, the
     * top of the text "slants" relative to the bottom. Positive angles slant
     * characters forward at their tops.
     *
     * @returns The obliquing angle in radians
     *
     * @example
     * ```typescript
     * record.obliquingAngle = Math.PI / 6; // 30 degrees
     * ```
     */
    get obliquingAngle(): number;
    set obliquingAngle(value: number);
    /**
     * Gets or sets the text height used for the last text created using this text style.
     *
     * This value is updated automatically by AutoCAD after the creation of any text object
     * that references this text style table record. If {@link textSize} is 0, then priorSize
     * is used as the default text height for the next text created using this text style.
     *
     * @returns The prior text size
     *
     * @example
     * ```typescript
     * record.priorSize = 12.0;
     * ```
     */
    get priorSize(): number;
    set priorSize(value: number);
    /**
     * Gets or sets the default size of the text drawn with this text style.
     *
     * If the text size is set to 0, AutoCAD prompts for a text height when creating text.
     * If textSize is non-zero, that fixed height is used instead.
     *
     * @returns The default text size
     *
     * @example
     * ```typescript
     * record.textSize = 10.0; // Fixed text height
     * ```
     */
    get textSize(): number;
    set textSize(value: number);
    /**
     * Gets or sets the width factor (also referred to as the relative X-scale factor) for the text style.
     *
     * The width factor is applied to the text's width independently of the height. For example,
     * a value of 0.8 draws text at 80% of its normal width.
     *
     * @returns The width factor
     *
     * @example
     * ```typescript
     * record.xScale = 0.8; // 80% width
     * ```
     */
    get xScale(): number;
    set xScale(value: number);
    /**
     * Gets or sets whether text drawn with this text style is drawn vertically.
     *
     * Maps to standard flag bit 4 in group code 70.
     *
     * @returns True if text is drawn vertically, false otherwise
     *
     * @example
     * ```typescript
     * record.isVertical = true;
     * ```
     */
    get isVertical(): boolean;
    set isVertical(value: boolean);
    /**
     * Gets or sets whether this entry describes a shape file definition rather than a text style.
     *
     * When true, the record represents a shape file definition in the STYLE table
     * (standard flag bit 1) and typically has an empty name.
     *
     * @returns True if this entry is a shape file definition, false otherwise
     *
     * @example
     * ```typescript
     * if (record.isShapeFile) {
     *   console.log('Shape file definition:', record.fileName);
     * }
     * ```
     */
    get isShapeFile(): boolean;
    set isShapeFile(value: boolean);
    /**
     * Gets or sets the name of the font file for this text style.
     *
     * @returns The font file name
     *
     * @example
     * ```typescript
     * record.fileName = 'Arial';
     * ```
     */
    get fileName(): string;
    set fileName(value: string);
    /**
     * Gets or sets the name of the big font file for this text style.
     *
     * Big font files are used for languages that require more than 256 characters,
     * such as Chinese, Japanese, and Korean.
     *
     * @returns The big font file name
     *
     * @example
     * ```typescript
     * record.bigFontFileName = 'bigfont.shx';
     * ```
     */
    get bigFontFileName(): string;
    set bigFontFileName(value: string);
    /**
     * Gets the text style information used by the renderer.
     *
     * Returns a snapshot assembled from stored attributes. Mutating the returned object
     * does not update this table record; use the dedicated setters instead.
     *
     * @returns The text style configuration assembled from stored attributes
     *
     * @example
     * ```typescript
     * const textStyle = record.textStyle;
     * console.log('Font:', textStyle.font);
     * ```
     */
    get textStyle(): AcGiTextStyle;
    /**
     * Removes the file extension from a file name.
     *
     * @param pathName - The file path or name
     * @returns The file name without extension
     */
    private getFileNameWithoutExtension;
    /**
     * Font file name as written to DXF group 3.
     *
     * Shape-file STYLE entries used by SHAPE entities need a `.shx` extension in
     * DXF (CadLib / AutoCAD); DWG often stores the bare base name.
     */
    private get dxfFontFileName();
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * TrueType styles often leave DXF group 3 empty and store the font name in
     * ACAD XData (`1001 ACAD` / `1000 SimSun`). Apply that as {@link extendedFont}
     * and fall back {@link fileName} when the primary font file is blank —
     * matching dxf-json's `extendedFont` field.
     */
    protected dxfInXData(filer: AcDbDxfFiler): void;
    private applyExtendedFontFromXData;
}
//# sourceMappingURL=AcDbTextStyleTableRecord.d.ts.map