import { AcCmColor, AcCmEventManager, AcCmTransparency } from '@mlightcad/common';
import { AcGePointLike } from '@mlightcad/geometry-engine';
import type { AcDbDatabase } from './AcDbDatabase';
/**
 * Supported AutoCAD system variable data type name.
 */
export type AcDbSysVarTypeName = 'string' | 'color' | 'number' | 'boolean' | 'point' | 'transparency' | 'unknown';
/**
 * Supported AutoCAD system variable data type name.
 */
export type AcDbSysVarType = string | number | boolean | AcGePointLike | AcCmColor | AcCmTransparency;
/**
 * Definition for a system variable in our registry.
 */
export interface AcDbSysVarDescriptor {
    /** System variable name, e.g., "CLAYER" */
    name: string;
    /** Expected variable type */
    type: AcDbSysVarTypeName;
    /** The flag to indicate whether it is one database-resident variable. */
    isDbVar: boolean;
    /** Optional description (documentation) */
    description?: string;
    /** Optional default value */
    defaultValue?: AcDbSysVarType;
    /** When true, the variable cannot be changed via setVar. */
    readOnly?: boolean;
}
/**
 * Event arguments for system variable related events.
 */
export interface AcDbSysVarEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The system variable name */
    name: string;
    /** The new value of system variable */
    newVal: AcDbSysVarType;
    /** The old value of system variable */
    oldVal?: AcDbSysVarType;
}
/**
 * Main manager responsible for:
 * - registry of known system variables
 * - caching values
 * - invoking backend getVar/setVar
 * - dispatching sysvar change events
 */
export declare class AcDbSysVarManager {
    private static _instance;
    /** Singleton accessor */
    static instance(): AcDbSysVarManager;
    /** Registered system variable metadata */
    private registry;
    /** Cached current values for non-database-resident variables. */
    private cache;
    /** System variable related events */
    readonly events: {
        /**
         * Fired after a system variable is changed directly through the SETVAR command or
         * by entering the variable name at the command line.
         */
        sysVarChanged: AcCmEventManager<AcDbSysVarEventArgs>;
    };
    /** Registers all known system variables in alphabetical order by name. */
    private constructor();
    /**
     * Register one system variable metadata entry.
     */
    registerVar(desc: AcDbSysVarDescriptor): void;
    /**
     * Register many system variables.
     */
    registerMany(vars: AcDbSysVarDescriptor[]): void;
    /**
     * Initializes the session {@link AcDbSystemVariables.LOGINNAME} value.
     *
     * {@link setVar} rejects writes because LOGINNAME is read-only for users;
     * host applications call this once at startup (for example after auth).
     *
     * @param value - Login / user display name.
     */
    setLoginName(value: string): void;
    /**
     * Get system variable value.
     */
    getVar(name: string, db: AcDbDatabase): AcDbSysVarType | undefined;
    /**
     * Get system variable default value.
     */
    getDefaultValue(name: string): AcDbSysVarType | undefined;
    /**
     * Applies one system variable mutation with shared transaction and event rules.
     *
     * Database-backed variables should mutate through {@link AcDbDatabase} property
     * setters or {@link setVar}. Non-database variables mutate through the cache.
     *
     * @param name - System variable name (normalized internally)
     * @param oldVal - Value before mutation; recorded for undo when a transaction is active
     * @param newVal - Value after mutation; used for change detection and event dispatch
     * @param db - Database whose transaction manager governs recording and strict mode
     * @param mutate - Callback that performs the actual value write
     */
    applyVarMutation<T>(name: string, oldVal: T, newVal: T, db: AcDbDatabase, mutate: () => void): void;
    /**
     * Set system variable value.
     */
    setVar(name: string, value: AcDbSysVarType, db: AcDbDatabase): void;
    /**
     * Get system variable metadata descriptor (if registered).
     */
    getDescriptor(name: string): AcDbSysVarDescriptor | undefined;
    /**
     * Get all registered system variable descriptors.
     */
    getAllDescriptors(): AcDbSysVarDescriptor[];
    /**
     * Parse one string as one boolean value with case-insensitive by ignoring extra spaces
     * - "true" / "false"
     * - "t" / "f"
     * - "1" / "0"
     * - "yes" / "no"
     * - "y" / "n"
     * @param value - One string
     * @returns - The parsed boolean value
     */
    private parseBoolean;
    private parseColorSysVar;
    private parseTransparency;
    /**
     * Check if sysvar value changed.
     */
    private hasValueChanged;
    /**
     * Normalize system variable name for internal storage and lookup.
     */
    private normalizeName;
}
//# sourceMappingURL=AcDbSysVarManager.d.ts.map