import { AcGiBaseLineStyle } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbSymbolTableRecord, AcDbSymbolTableRecordAttrs } from './AcDbSymbolTableRecord';
export interface AcDbLinetypePreviewSvgOptions {
    /**
     * Width of preview SVG.
     * @default 220
     */
    width?: number;
    /**
     * Height of preview SVG.
     * @default 36
     */
    height?: number;
    /**
     * Left/right horizontal padding in pixels.
     * @default 8
     */
    padding?: number;
    /**
     * Stroke width in pixels.
     * @default 2
     */
    strokeWidth?: number;
    /**
     * Stroke color.
     * @default 'currentColor'
     */
    stroke?: string;
    /**
     * How many pattern cycles to display in preview width.
     * @default 4
     */
    repeats?: number;
}
/**
 * Interface defining the attributes for linetype table records.
 *
 * Merges {@link AcDbSymbolTableRecordAttrs} with {@link AcGiBaseLineStyle} fields
 * (excluding the duplicate `name` property).
 */
export interface AcDbLinetypeTableRecordAttrs extends AcDbSymbolTableRecordAttrs, Omit<AcGiBaseLineStyle, 'name'> {
}
/**
 * Represents a record in the line type table within the AutoCAD drawing database.
 *
 * Each line type table record contains the information necessary to define a specific line type,
 * including its pattern, description, and rendering characteristics. Line types define how lines
 * are drawn, including patterns of dashes, dots, and spaces.
 *
 * Within the line type table record, the dashes (line segments that make up characteristics of the
 * linetype) are stored in a list with an index that is zero based. If the linetype is complex, then
 * embedded shapes or text strings are stored in the list at the same index as the dash that preceded
 * them in the linetype definition. So there will always be a dashLength for any valid index in the
 * list, even if there is a shape or text string sharing the same index. When the linetype is elaborated,
 * a shape's insertion point will coincide with the end of the dash that it shares an index with.
 */
export declare class AcDbLinetypeTableRecord extends AcDbSymbolTableRecord<AcDbLinetypeTableRecordAttrs> {
    /**
     * Creates a new line type table record.
     *
     * @param attrs - Input attribute values for this linetype table record
     * @param defaultAttrs - Default values for attributes of this linetype table record
     *
     * @example
     * ```typescript
     * const record = new AcDbLinetypeTableRecord({
     *   name: 'DASHED',
     *   description: 'Dashed',
     *   totalPatternLength: 1,
     *   pattern: [{ elementLength: 0.5, elementTypeFlag: 0 }]
     * });
     * ```
     */
    constructor(attrs?: Partial<AcDbLinetypeTableRecordAttrs>, defaultAttrs?: Partial<AcDbLinetypeTableRecordAttrs>);
    /**
     * Gets the number of dash elements in the line type pattern.
     *
     * This value represents the total count of dashes, spaces, dots, and other pattern elements
     * that make up the line type. It corresponds to DXF group code 73 in the AutoCAD file format.
     *
     * @returns The number of pattern elements in the line type
     */
    get numDashes(): any;
    /**
     * Gets the total pattern length in AutoCAD drawing units.
     *
     * The pattern length represents the total length of all dashes and spaces when the line type
     * scale is 1.0. This value is used to calculate how the pattern repeats along a line.
     *
     * Note: Embedded shapes or text strings do not add to the pattern length because they are
     * overlaid and do not interrupt the actual dash pattern.
     *
     * @returns The total length of the line type pattern in drawing units
     */
    get patternLength(): any;
    /**
     * Gets the description or comments associated with this line type.
     *
     * This property provides additional information about the line type, such as its intended
     * use or any special characteristics.
     *
     * @returns The description text for the line type
     */
    get comments(): any;
    /**
     * Gets the line type style object used by the renderer.
     *
     * Returns a snapshot assembled from stored attributes. Mutating the returned object
     * does not update this table record; use the dedicated setters instead.
     *
     * @returns The line type style object assembled from stored attributes
     */
    get linetype(): AcGiBaseLineStyle;
    /**
     * Gets the length of a specific dash element in the line type pattern.
     *
     * Each dash element in the pattern has a specific length that determines how it appears
     * when the line type is rendered. Positive values represent visible dashes, while negative
     * values represent spaces (pen up).
     *
     * @param index - Zero-based index of the dash element. Must be greater than or equal to zero,
     *                but less than the value of property 'numDashes'
     * @returns The length of the specified dash element in drawing units
     * @throws {Error} When the index is out of range
     */
    dashLengthAt(index: number): any;
    /**
     * Converts this linetype preview to an SVG string.
     *
     * The preview is rendered as a horizontal line centered in the SVG viewport.
     * Positive pattern elements are drawn as visible strokes, negative elements
     * are treated as gaps, and zero-length elements are rendered as dots.
     *
     * @param options - Preview rendering options
     * @returns SVG string for linetype preview
     */
    toPreviewSvgString(options?: AcDbLinetypePreviewSvgOptions): string;
    private buildSvgString;
    private escapeSvgAttribute;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbLinetypeTableRecord.d.ts.map