import { AcGeBox2d, AcGePoint2d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbAbstractViewTableRecord, AcDbAbstractViewTableRecordAttrs } from './AcDbAbstractViewTableRecord';
/**
 * Interface defining the attributes for viewport table records.
 */
export interface AcDbViewportTableRecordAttrs extends AcDbAbstractViewTableRecordAttrs {
    /** Number of sides used for circle tessellation */
    circleSides: number;
    /** Lower left corner of the viewport window */
    lowerLeftCorner: AcGePoint2d;
    /** Upper right corner of the viewport window */
    upperRightCorner: AcGePoint2d;
    /** Snap base point for the viewport */
    snapBase: AcGePoint2d;
    /** Snap angle for the viewport */
    snapAngle: number;
    /** Snap spacing for the viewport */
    snapSpacing: AcGePoint2d;
    /** Standard flags for the viewport */
    standardFlag: number;
    /** Grid spacing for the viewport */
    gridSpacing: AcGePoint2d;
    /** Grid major spacing for the viewport */
    gridMajor: number;
    /** Background object ID for the viewport */
    backgroundObjectId?: string;
    /** UCS elevation for the viewport (DXF group 146) */
    ucsElevation: number;
}
/**
 * Represents a viewport table record in AutoCAD.
 *
 * This class represents viewport arrangements in AutoCAD, which define how
 * the drawing is displayed in different areas of the screen or paper space.
 * Viewports can have their own zoom levels, pan positions, grid settings,
 * and other display properties.
 *
 * @example
 * ```typescript
 * const viewportRecord = new AcDbViewportTableRecord();
 * viewportRecord.name = ACTIVE_VPORT_NAME;
 * viewportRecord.circleSides = 100;
 * viewportRecord.lowerLeftCorner = new AcGePoint2d(0, 0);
 * viewportRecord.upperRightCorner = new AcGePoint2d(1, 1);
 * ```
 */
export declare class AcDbViewportTableRecord extends AcDbAbstractViewTableRecord<AcDbViewportTableRecordAttrs> {
    /**
     * Returns true if the specified name is the active viewport table record.
     *
     * AutoCAD stores the current model-space viewport configuration as `*Active`.
     * DXF/DWG sources may emit different casing (`*ACTIVE`, `*active`, etc.), but
     * the names compare case-insensitively.
     */
    static isActiveVportName(name: string): boolean;
    /**
     * Creates a new AcDbViewportTableRecord instance.
     *
     * @param attrs - Input attribute values for this viewport table record
     * @param defaultAttrs - Default values for attributes of this viewport table record
     */
    constructor(attrs?: Partial<AcDbViewportTableRecordAttrs>, defaultAttrs?: Partial<AcDbViewportTableRecordAttrs>);
    /**
     * Gets or sets the circle zoom percent.
     *
     * This controls the number of sides to the tessellation used when displaying
     * curves. The value can be between 1 and 20000, with higher settings using
     * more sides in the curve tessellation.
     *
     * @returns The number of sides used for circle tessellation
     *
     * @example
     * ```typescript
     * const sides = viewportRecord.circleSides;
     * viewportRecord.circleSides = 200; // Higher quality circles
     * ```
     */
    get circleSides(): number;
    set circleSides(value: number);
    /**
     * Gets the center point of the viewport.
     *
     * @returns The center point of the viewport
     *
     * @example
     * ```typescript
     * const center = viewportRecord.center;
     * ```
     */
    get center(): AcGePoint2d;
    set center(value: AcGePoint2d);
    /**
     * Gets or sets the lower left corner of the viewport window.
     *
     * The X and Y values of this point are expressed as a value between (0.0, 0.0)
     * for the lower left corner of the AutoCAD graphics area and (1.0, 1.0) for
     * the upper right corner of the AutoCAD graphics area. For example, a lower
     * left corner value of (0.5, 0.0) indicates that the viewport's lower left
     * corner is along the bottom of the AutoCAD graphics area, midway between
     * the left and right edges of the graphics area.
     *
     * @returns The lower left corner point
     *
     * @example
     * ```typescript
     * const corner = viewportRecord.lowerLeftCorner;
     * viewportRecord.lowerLeftCorner = new AcGePoint2d(0.25, 0.25);
     * ```
     */
    get lowerLeftCorner(): AcGePoint2d;
    set lowerLeftCorner(value: AcGePoint2d);
    /**
     * The upper right corner of the viewport window. The X and Y values of this point are expressed as
     * a value between (0.0, 0.0) for the lower left corner of the AutoCAD graphics area and (1.0, 1.0)
     * for upper right corner of the AutoCAD graphics area. For example, an upper right corner value of
     * (0.5, 1.0) indicates that the viewport's upper right corner is along the top of the AutoCAD
     * graphics area, midway between the left and right edges of the graphics area.
     */
    get upperRightCorner(): AcGePoint2d;
    set upperRightCorner(value: AcGePoint2d);
    /**
     * The snap basepoint (in UCS coordinates) for the viewport table record.
     */
    get snapBase(): AcGePoint2d;
    set snapBase(value: AcGePoint2d);
    /**
     * The snap angle setting (in radians) for the viewport table record. The snap angle is measured
     * within the UCS XY plane, with zero being the UCS X axis and positive angles going counterclockwise
     * when looking down the UCS Z axis towards the UCS origin.
     */
    get snapAngle(): number;
    set snapAngle(value: number);
    /**
     * An AcGePoint2d in which the X value represents the X spacing of the snap grid and the Y value
     * represents the Y spacing of the snap grid. Both values are in drawing units.
     */
    get snapIncrements(): AcGePoint2d;
    set snapIncrements(value: AcGePoint2d);
    /**
     * The number of minor grid lines between each major grid line in the viewport.
     */
    get gridMajor(): number;
    set gridMajor(value: number);
    /**
     * An AcGePoint2d in which the X value represents the X spacing (in drawing units) of the grid and
     * the Y value represents the Y spacing of the grid.
     */
    get gridIncrements(): AcGePoint2d;
    set gridIncrements(value: AcGePoint2d);
    get standardFlag(): number;
    set standardFlag(value: number);
    get snapEnabled(): boolean;
    /**
     * The object dD of the new background for the view.
     */
    get backgroundObjectId(): string | undefined;
    set backgroundObjectId(value: string | undefined);
    /**
     * The UCS elevation for this viewport (DXF group 146).
     */
    get ucsElevation(): number;
    set ucsElevation(value: number);
    /**
     * Builds the model-space WCS view rectangle from this VPORT record.
     *
     * AutoCAD stores:
     * - view center in groups 12/22 (mapped to `centerPoint`) — in DCS
     *   (display coordinate system), i.e. relative to the view target and
     *   rotated by the view twist angle, NOT in WCS
     * - view target in group 17 (`viewTarget`) — in WCS
     * - view twist angle in group 51 (`viewTwistAngle`)
     * - view height in group 40/45 (`viewHeight`)
     * - aspect ratio in group 41 (`gsView.aspectRatio`) ??the AutoCAD graphics
     *   window width/height at save time, not the model-space view on its own
     *
     * The WCS view center is therefore `target + rotate(center, twist)`.
     * Most drawings save a (0,0,0) target so the distinction is invisible,
     * but AutoCAD does persist non-zero targets (e.g. after DVIEW/3D orbit
     * round-trips); ignoring the target restores the view over empty space
     * arbitrarily far from the drawing.
     *
     * View width = view height ? aspect ratio. The viewer uses the current canvas
     * aspect ratio so DWG/DXF exports of the same drawing frame identically even
     * when group 41 differs.
     */
    modelViewBox(canvasAspectRatio: number): AcGeBox2d | undefined;
    /**
     * Returns whether a VPORT-derived view box is sane enough to frame the drawing
     * on open. Rejects stale saves that are zoomed far beyond the sheet (common
     * when `$EXTMIN`/`$EXTMAX` reflect the title block but `*ACTIVE` still stores
     * a huge `view height`) or panned to a corner with no real geometry.
     */
    static isModelViewBoxUsable(viewBox: AcGeBox2d, drawingExtents: AcGeBox2d): boolean;
    /**
     * Returns the model-space view box from this record when structurally valid
     * and plausible for the given drawing extents.
     */
    resolveModelViewBox(canvasAspectRatio: number, drawingExtents?: AcGeBox2d): AcGeBox2d | undefined;
    private static isModelViewBoxStructurallyValid;
    private static isModelViewBoxPlausibleWithoutExtents;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbViewportTableRecord.d.ts.map