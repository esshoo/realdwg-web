import { AcCmColor, AcCmEventManager, AcCmTransparency } from '@mlightcad/common';
import { AcDbObject, AcDbObjectId } from '../base/AcDbObject';
import { AcDbConverterType } from './AcDbDatabaseConverterManager';
import { AcDbEntity } from '../entity/AcDbEntity';
import { AcDbFormatter } from '../misc/AcDbFormatter';
import { AcDbDictionary } from '../object/AcDbDictionary';
import { AcDbGroup } from '../object/AcDbGroup';
import { AcDbLayerFilter } from '../object/AcDbLayerFilter';
import { AcDbLayerIndex } from '../object/AcDbLayerIndex';
import { AcDbMLeaderStyle } from '../object/AcDbMLeaderStyle';
import { AcDbMlineStyle } from '../object/AcDbMlineStyle';
import { AcDbRasterImageDef } from '../object/AcDbRasterImageDef';
import { AcDbSortentsTable } from '../object/AcDbSortentsTable';
import { AcDbXrecord } from '../object/AcDbXrecord';
import { AcLyLayerFilterTree } from '../ly/AcLyLayerFilterTree';
import { AcDbBlockTable } from './AcDbBlockTable';
import { AcDbConversionStage, AcDbStageStatus } from './AcDbDatabaseConverter';
import { AcDbOpenDatabaseError } from './AcDbOpenDatabaseError';
import { AcDbDimStyleTable } from './AcDbDimStyleTable';
import { AcDbLayerTable } from './AcDbLayerTable';
import { AcDbLayerTableRecord, AcDbLayerTableRecordAttrs } from './AcDbLayerTableRecord';
import { AcDbLinetypeTable } from './AcDbLinetypeTable';
import { AcDbTextStyleTable } from './AcDbTextStyleTable';
import { AcDbUcsTable } from './AcDbUcsTable';
import { AcDbViewTable } from './AcDbViewTable';
import { AcDbViewportTable } from './AcDbViewportTable';
import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbDwgVersion } from './AcDbDwgVersion';
import type { AcDbClass } from './AcDbClass';
import { AcGiLineWeight } from '@mlightcad/graphic-interface';
import { AcDbRegAppTable } from './AcDbRegAppTable';
import { AcDbLayoutDictionary } from '../object/layout/AcDbLayoutDictionary';
import { AcDbDatabaseTransactionManager } from './transaction/AcDbDatabaseTransactionManager';
/**
 * Event arguments for object events in the dictionary.
 */
export interface AcDbDictObjectEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The object (or objects) involved in the event */
    object: AcDbObject | AcDbObject[];
    /** The key name of the object */
    key: string;
}
/**
 * Event arguments for entity-related events.
 */
export interface AcDbEntityEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The entity (or entities) involved in the event */
    entity: AcDbEntity | AcDbEntity[];
}
/**
 * Event arguments for layer-related events.
 */
export interface AcDbLayerEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The layer involved in the event */
    layer: AcDbLayerTableRecord;
}
/**
 * Event arguments for layer modification events.
 */
export interface AcDbLayerModifiedEventArgs extends AcDbLayerEventArgs {
    /** The changes made to the layer */
    changes: Partial<AcDbLayerTableRecordAttrs>;
}
/**
 * The stage of opening one drawing file
 */
export type AcDbOpenFileStage = 'FETCH_FILE' | 'CONVERSION';
/**
 * Event arguments for progress events during database operations.
 */
export interface AcDbProgressdEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The progress percentage (0-100) */
    percentage: number;
    /** The current stage of opening one drawing file */
    stage: AcDbOpenFileStage;
    /** The current sub stage */
    subStage?: AcDbConversionStage;
    /** The status of the current sub stage */
    subStageStatus: AcDbStageStatus;
    /**
     * Store data associated with the current sub stage. Its meaning of different sub stages
     * are as follows.
     * - 'PARSE' stage: statistics of parsing task
     * - Any stage with {@link subStageStatus} `'ERROR'`: `{ code, message, stage? }`
     *
     * Note: For now, 'PARSE' sub stages use this field only, except on errors.
     */
    data?: unknown;
}
/**
 * Event arguments when opening a drawing database fails.
 */
export interface AcDbOpenFailedEventArgs {
    /** The database that failed to open */
    database: AcDbDatabase;
    /** Structured failure information */
    error: AcDbOpenDatabaseError;
}
/**
 * Options for reading a drawing database.
 *
 * These options control how a drawing database is opened and processed.
 */
export interface AcDbOpenDatabaseOptions {
    /**
     * Opens the drawing database in read-only mode.
     *
     * When true, the database will be opened in read-only mode, preventing
     * any modifications to the database content.
     */
    readOnly?: boolean;
    /**
     * The minimum number of items in one chunk.
     *
     * If this value is greater than the total number of entities in the
     * drawing database, the total number is used. This controls how the
     * database processing is broken into chunks for better performance.
     */
    minimumChunkSize?: number;
    /**
     * Timeout for web worker parsing in milliseconds.
     *
     * This option is used only when the selected converter parses the drawing
     * file in a web worker. If omitted, the converter-level timeout is used.
     */
    timeout?: number;
    /**
     * Override the text encoding used to decode text content (layer names,
     * annotations, text entities, block attributes, ...).
     *
     * When omitted, the encoding is auto-detected from the file (DXF reads
     * `$DWGCODEPAGE`; DWG reads the header code page). When provided, it wins
     * over auto-detection — for example `'cp949'` or `'euc-kr'` for Korean
     * drawings whose declared code page is missing or wrong.
     */
    encoding?: string;
    /**
     * System variables to override in the database.
     *
     * This allows overriding system variable values when opening a database.
     * For example, to disable line weight display regardless of the database's
     * stored value, set { 'lwdisplay': false }.
     *
     * The keys are system variable names (case-insensitive), and values can be
     * number, boolean, or string types.
     */
    sysVars?: Record<string, number | boolean | string>;
    /**
     * Whether entities on non-plottable ("no-plot") layers are drawn.
     *
     * - `true` (default): desktop AutoCAD editor semantics — no-plot layers remain
     *   visible on screen (Defpoints, viewport frames on `*-NPLT`, etc.).
     * - `false`: web/publish viewer semantics (e.g. BIM 360 / ACC) — entities on
     *   no-plot layers are omitted from display.
     */
    drawNoPlotLayers?: boolean;
    /**
     * Maximum number of segments used to tessellate a full circle when drawing.
     *
     * Lower values use less GPU memory and produce smaller HTML exports; higher
     * values look smoother on large arcs. Clamped to the DXF VPORT range
     * `[{@link AcGeCircArc2d.MIN_CIRCLE_SIDES}, {@link AcGeCircArc2d.MAX_CIRCLE_SIDES}]`.
     * When omitted, {@link ACDB_DRAW_CIRCLE_SIDES_DRAFT} (50) is used so
     * AutoCAD's common VIEWRES 1000 is not applied accidentally.
     *
     * Short arcs still use fewer segments than a full circle.
     */
    circleSides?: number;
    /**
     * File name of the drawing being opened, including extension (for example `Plan.dwg`).
     *
     * When provided, updates the read-only **DWGNAME** system variable for this database.
     */
    fileName?: string;
}
/**
 * Interface defining the tables available in a drawing database.
 *
 * This interface provides access to all the symbol tables in the database,
 * including block table, dimension style table, linetype table, text style table,
 * layer table, and viewport table.
 */
export interface AcDbTables {
    /** Registered application name table */
    readonly appIdTable: AcDbRegAppTable;
    /** Block table containing block definitions */
    readonly blockTable: AcDbBlockTable;
    /** Dimension style table containing dimension style definitions */
    readonly dimStyleTable: AcDbDimStyleTable;
    /** Linetype table containing linetype definitions */
    readonly linetypeTable: AcDbLinetypeTable;
    /** Text style table containing text style definitions */
    readonly textStyleTable: AcDbTextStyleTable;
    /** UCS table containing named user coordinate systems */
    readonly ucsTable: AcDbUcsTable;
    /** View table containing named view definitions */
    readonly viewTable: AcDbViewTable;
    /** Layer table containing layer definitions */
    readonly layerTable: AcDbLayerTable;
    /** Viewport table containing viewport definitions */
    readonly viewportTable: AcDbViewportTable;
}
/**
 * Options used to specify default data to create
 */
export interface AcDbCreateDefaultDataOptions {
    layer?: boolean;
    lineType?: boolean;
    textStyle?: boolean;
    dimStyle?: boolean;
    layout?: boolean;
}
/**
 * The AcDbDatabase class represents an AutoCAD drawing file.
 *
 * Each AcDbDatabase object contains the various header variables, symbol tables,
 * table records, entities, and objects that make up the drawing. The AcDbDatabase
 * class has member functions to allow access to all the symbol tables, to read
 * and write to DWG files, to get or set database defaults, to execute various
 * database-level operations, and to get or set all header variables.
 *
 * @example
 * ```typescript
 * const database = new AcDbDatabase();
 * await database.read(dxfData, { readOnly: true });
 * const entities = database.tables.blockTable.modelSpace.entities;
 * ```
 */
export declare class AcDbDatabase extends AcDbObject {
    /** Sequence counter for default unsaved drawing names (Drawing1.dwg, Drawing2.dwg, ...). */
    private static _unsavedDrawingSequence;
    /** Version of the database */
    private _version;
    /** Angle base for the database */
    private _angbase;
    /** Angle direction for the database */
    private _angdir;
    /** Angle units for the database */
    private _aunits;
    /** Angular display precision (AUPREC), used with {@link AcDbDatabase.aunits | AUNITS}. */
    private _auprec;
    /** Linear unit display format (LUNITS) for coordinates and distances. */
    private _lunits;
    /** Linear display precision (LUPREC), used with {@link lunits}. */
    private _luprec;
    /** Current entity color */
    private _cecolor;
    /** Current entity linetype scale */
    private _celtscale;
    /** Current entity linetype name */
    private _celtype;
    /** Current entity line weight value */
    private _celweight;
    /** Current entity transparency level */
    private _cetransparency;
    /** Current layer for the database */
    private _clayer;
    /** Current multiline style for newly created MLINE entities */
    private _cmlstyle;
    /** Current multiline scale for newly created MLINE entities */
    private _cmlscale;
    /** Current multileader style for newly created MLEADER entities */
    private _cmleaderstyle;
    /** Default background color for newly created hatch patterns */
    private _hpbackgroundcolor;
    /** Default color for newly created hatches */
    private _hpcolor;
    /** Default layer for newly created hatches and fills */
    private _hplayer;
    /** Default transparency for newly created hatches and fills */
    private _hptransparency;
    /** Current text style name for the database */
    private _textstyle;
    /** Current dimension style name for the database ($DIMSTYLE) */
    private _dimstyle;
    /** The extents of current Model Space */
    private _extents;
    /** Insertion units for the database */
    private _insunits;
    /** Feet-inch / fractional delimiter style (UNITMODE) */
    private _unitmode;
    /** Legacy metric vs imperial flag (MEASUREMENT) */
    private _measurement;
    /** Global linetype scale */
    private _ltscale;
    /** The flag whether to display line weight */
    private _lwdisplay;
    /** TILEMODE: true = model space active (1), false = paper space (0) */
    private _tilemode;
    /** PSLTSCALE: paper space linetype scaling */
    private _psltscale;
    /** Point display mode */
    private _pdmode;
    /** Point display size */
    private _pdsize;
    /** Running object snap mode bitmask */
    private _osmode;
    /** Orthogonal mode flag (ORTHOMODE): 0 = off, 1 = on */
    private _orthomode;
    /** COMPAREHATCH: whether hatch objects are included in drawing comparison */
    private _comparehatch;
    /** COMPARERCMARGIN: revision-cloud offset around comparison change sets */
    private _comparercmargin;
    /** COMPARETEXT: whether text objects are included in drawing comparison */
    private _comparetext;
    /** COMPARETOLERANCE: decimal-place geometric tolerance for drawing comparison */
    private _comparetolerance;
    /** Tables in the database */
    private _tables;
    /** Class definitions from DXF CLASSES / DWG class table (needed for proxy entities). */
    private _classes;
    /** Nongraphical objects in the database */
    private _objects;
    /** Current space (model space or paper space) */
    private _currentSpace?;
    /** The maximum handle value in the database, used for generating unique object IDs */
    private _maxHandle;
    /**
     * BigInt-tracked maximum handle. Engages once handles exceed
     * {@link Number.MAX_SAFE_INTEGER}; beyond that point float increments no
     * longer advance (`x + 1 === x`) and handle generation would spin forever.
     */
    private _maxHandleBig?;
    /** Global registry of committed object handles across all database-resident objects */
    private _handleRegistry;
    /** Lazily created formatter for lengths, angles, and coordinates */
    private _formatter?;
    /**
     * When false, entities on non-plottable layers are not drawn (viewer semantics).
     * Set from {@link AcDbOpenDatabaseOptions.drawNoPlotLayers} when opening a database.
     */
    private _drawNoPlotLayers;
    /**
     * Display tessellation side count for a full circle.
     * Set from {@link AcDbOpenDatabaseOptions.circleSides} when opening a database.
     */
    private _drawCircleSides;
    /** Current drawing file name (**DWGNAME**), including extension. */
    private _dwgname;
    /**
     * Drawing thumbnail preview image (DXF `THUMBNAILIMAGE` / DWG preview).
     * Raw image bytes (typically BMP/DIB or PNG), or `undefined` when absent.
     */
    private _thumbnailImage?;
    /**
     * Layer Properties Manager filter tree (`AcLy*` / .NET `LayerFilterTree`).
     * Distinct from {@link objects.layerFilter} (`AcDbLayerFilter` index objects).
     */
    private _layerFilters;
    /** Manages transactions and undo/redo for this database. */
    readonly transactionManager: AcDbDatabaseTransactionManager;
    private _eventBatchDepth;
    private _pendingEntityAppended;
    private _pendingEntityErased;
    private _pendingDictObjectSet;
    private _pendingDictObjectErased;
    private _lastOpenError;
    /**
     * Events that can be triggered by the database.
     *
     * These events allow applications to respond to various database operations
     * such as entity modifications, layer changes, and progress updates.
     */
    readonly events: {
        /** Fired when an object is set to the dictionary */
        dictObjetSet: AcCmEventManager<AcDbDictObjectEventArgs>;
        /** Fired when an object in the dictionary is removed */
        dictObjectErased: AcCmEventManager<AcDbDictObjectEventArgs>;
        /** Fired when an entity is appended to the database */
        entityAppended: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when an entity is modified in the database */
        entityModified: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when an entity is erased from the database */
        entityErased: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when a layer is appended to the database */
        layerAppended: AcCmEventManager<AcDbLayerEventArgs>;
        /** Fired when a layer is modified in the database */
        layerModified: AcCmEventManager<AcDbLayerModifiedEventArgs>;
        /** Fired when a layer is erased from the database */
        layerErased: AcCmEventManager<AcDbLayerEventArgs>;
        /** Fired during database opening operations to report progress */
        openProgress: AcCmEventManager<AcDbProgressdEventArgs>;
        /** Fired when {@link AcDbDatabase.read} or {@link AcDbDatabase.openUri} fails */
        openFailed: AcCmEventManager<AcDbOpenFailedEventArgs>;
    };
    /**
     * Creates a new AcDbDatabase instance.
     */
    constructor();
    /**
     * Gets all tables in this drawing database.
     *
     * @returns Object containing all the symbol tables in the database
     *
     * @example
     * ```typescript
     * const tables = database.tables;
     * const layers = tables.layerTable;
     * const blocks = tables.blockTable;
     * ```
     */
    get tables(): AcDbTables;
    /**
     * Gets or sets class definitions from the drawing (DXF CLASSES / DWG class table).
     *
     * Proxy entities resolve their application class ID (group code **91**)
     * against this list (IDs start at 500 for the first entry).
     */
    get classes(): readonly AcDbClass[];
    set classes(classes: readonly AcDbClass[]);
    /**
     * Gets all nongraphical objects in this drawing database.
     *
     * @returns Object containing all nongraphical objects in the database
     *
     * @example
     * ```typescript
     * const objects = database.objects;
     * const layout = objects.layout;
     * ```
     */
    get objects(): {
        readonly dictionary: AcDbDictionary<AcDbDictionary>;
        readonly group: AcDbDictionary<AcDbGroup>;
        readonly imageDefinition: AcDbDictionary<AcDbRasterImageDef>;
        readonly layerFilter: AcDbDictionary<AcDbLayerFilter>;
        readonly layerIndex: AcDbDictionary<AcDbLayerIndex>;
        readonly layout: AcDbLayoutDictionary;
        readonly mleaderStyle: AcDbDictionary<AcDbMLeaderStyle>;
        readonly mlineStyle: AcDbDictionary<AcDbMlineStyle>;
        readonly sortentsTable: AcDbDictionary<AcDbSortentsTable>;
        readonly xrecord: AcDbDictionary<AcDbXrecord>;
    };
    /**
     * Gets the Layer Properties Manager filter tree for this database.
     *
     * @remarks
     * Mirrors AutoCAD .NET `Database.LayerFilters` / ObjectARX `AcLy*` filters.
     * This is the property/group filter **tree**, not the flat
     * {@link objects.layerFilter} dictionary used by `AcDbLayerFilter` /
     * `AcDbLayerIndex`.
     *
     * Like AutoCAD, treat this value as retrieved by value: mutate the tree,
     * then assign it back via the setter if your workflow expects that pattern.
     *
     * @returns The current {@link AcLyLayerFilterTree}.
     *
     * @example
     * ```typescript
     * const tree = db.layerFilters;
     * const filter = new AcLyLayerFilter();
     * filter.name = 'Unlocked Layers';
     * filter.setFilterExpression('LOCKED=="False"');
     * tree.root.addNested(filter);
     * db.layerFilters = tree;
     * ```
     */
    get layerFilters(): AcLyLayerFilterTree;
    /**
     * Sets the Layer Properties Manager filter tree for this database.
     *
     * @param value - New filter tree.
     */
    set layerFilters(value: AcLyLayerFilterTree);
    /**
     * Looks up a database-resident object by its object ID.
     *
     * Uses the global handle registry maintained by {@link registerObjectHandle}.
     *
     * @param id - Object identifier to resolve
     * @param _openErased - Reserved for erased-object support
     * @returns The matching object, or undefined if not found
     */
    getObjectById(id: AcDbObjectId, _openErased?: boolean): AcDbObject | undefined;
    /**
     * Creates an extension dictionary for `owner` and registers it in this database.
     *
     * Used by {@link AcDbObject.createExtensionDictionary}. Returns the existing
     * dictionary id when one is already attached.
     */
    createExtensionDictionaryFor(owner: AcDbObject): AcDbObjectId | undefined;
    /**
     * Returns true when the transaction manager is actively recording changes.
     *
     * Shortcut for {@link AcDbDatabaseTransactionManager.isRecording}.
     */
    isUndoRecording(): boolean;
    /**
     * Opens a database object, preferring the active transaction when present.
     *
     * Editor shortcut: when a transaction is active, objects are opened through it
     * so mutations are tracked for undo. Otherwise falls back to {@link getObjectById}.
     */
    private openObject;
    /**
     * Opens a database object for read through the active transaction when present.
     *
     * Editor shortcut; see {@link openObject}.
     */
    openObjectForRead<T extends AcDbObject>(objectId: AcDbObjectId): T | undefined;
    /**
     * Opens a database object for write through the active transaction when present.
     *
     * Editor shortcut; see {@link openObject}.
     */
    openObjectForWrite<T extends AcDbObject>(objectId: AcDbObjectId): T | undefined;
    /**
     * Opens an entity for read through the active transaction when present.
     *
     * Editor shortcut; see {@link openObject}.
     */
    openEntityForRead(entityOrId: AcDbObjectId | AcDbEntity): AcDbEntity | undefined;
    /**
     * Opens an entity for write through the active transaction when present.
     *
     * Editor shortcut; see {@link openObject}.
     */
    openEntityForWrite(entityOrId: AcDbObjectId | AcDbEntity): AcDbEntity | undefined;
    /**
     * Runs a database mutation as one undoable operation.
     *
     * Editor shortcut: skips creating a new undo mark when the transaction manager
     * is already recording (nested editor operations). Otherwise wraps `fn` in
     * {@link AcDbDatabaseTransactionManager.runUndoable}.
     */
    runDatabaseEdit(label: string, fn: () => void): void;
    /**
     * Returns the top-level named object dictionaries owned by this database.
     */
    getRootDictionaries(): AcDbDictionary[];
    /**
     * Begins suppressing database events until {@link endEventBatch} is called.
     */
    beginEventBatch(): void;
    /**
     * Ends event batching and dispatches accumulated entity and layer events when the outermost batch closes.
     */
    endEventBatch(): void;
    /**
     * Ends the outermost event batch, flushing `entityAppended` notifications in
     * chunks so converters can report ENTITY progress while the viewer adds/renders.
     *
     * Nested batches still require matching {@link endEventBatch} /
     * {@link endEventBatchChunked} calls; only the outermost close flushes.
     *
     * @param chunkSize - Max entities per `entityAppended` dispatch
     * @param onChunk - Called after each chunk with `(flushed, total)`
     */
    endEventBatchChunked(chunkSize: number, onChunk?: (flushed: number, total: number) => void | Promise<void>): Promise<void>;
    /**
     * Returns true when database events are being batched.
     */
    isEventBatched(): boolean;
    /**
     * Dispatches or queues an entity-appended notification.
     *
     * @param entity - One entity or batch of entities added to model/paper space
     */
    notifyEntityAppended(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * Dispatches or queues an entity-erased notification.
     *
     * @param entity - One entity or batch of entities removed from model/paper space
     */
    notifyEntityErased(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * Dispatches or queues a dictionary-object-set notification.
     *
     * @param object - Object inserted or replaced in a named dictionary
     * @param key - Dictionary key under which the object is stored
     */
    notifyDictObjectSet(object: AcDbObject, key: string): void;
    /**
     * Dispatches or queues a dictionary-object-erased notification.
     *
     * @param object - Object removed from a named dictionary
     * @param key - Dictionary key that previously referenced the object
     */
    notifyDictObjectErased(object: AcDbObject, key: string): void;
    /**
     * Dispatches all notifications accumulated while event batching was active.
     *
     * Appended and erased entities are dispatched in batch arrays where applicable.
     */
    private flushEventBatch;
    /** Flushes non-append batch queues (erase / dictionary) after entity appends. */
    private flushEventBatchRemainder;
    /**
     * Formatter for linear distances, point coordinates, and angles using this database's
     * **LUNITS**, **AUNITS**, and related system variables.
     *
     * @example
     * ```typescript
     * database.formatter.formatLength(12.3456);
     * database.formatter.formatPoint3d(point);
     * database.formatter.formatAngle(angleRadians, { showUnits: true });
     * ```
     */
    get formatter(): AcDbFormatter;
    /**
     * Generates a new unique object ID (handle) for the database.
     * The handle is a hexadecimal string that increments from the current max handle.
     *
     * @returns A new unique object ID as a hexadecimal string
     *
     * @example
     * ```typescript
     * const newHandle = database.generateHandle();
     * console.log(`New handle: ${newHandle}`);
     * ```
     */
    generateHandle(): AcDbObjectId;
    /**
     * Generates a handle that is not already registered in this database.
     *
     * @internal
     */
    generateUniqueHandle(): AcDbObjectId;
    /**
     * Initializes {@link generateHandle} from a DXF/DWG `$HANDSEED` value.
     *
     * `$HANDSEED` is the next handle AutoCAD would assign; internal `_maxHandle`
     * is kept one below that value.
     *
     * @param seed - Hexadecimal handle seed from the drawing header
     */
    initializeHandleSeed(seed: string): void;
    /**
     * Adopts a handle from an external drawing when it is still available.
     *
     * When the preferred handle is already registered to another object, a new
     * unique handle is generated instead.
     *
     * @internal
     */
    adoptExternalHandle(object: AcDbObject, preferredId: AcDbObjectId): AcDbObjectId;
    /**
     * Registers an object's current {@link AcDbObject.objectId} in the global handle map.
     *
     * @internal
     */
    registerObjectHandle(object: AcDbObject): void;
    /**
     * Removes an object's handle from the global handle map.
     *
     * @internal
     */
    releaseObjectHandle(object: AcDbObject): void;
    /**
     * Returns true when a handle is already registered to another object.
     *
     * @internal
     */
    isHandleTaken(objectId: AcDbObjectId, except?: AcDbObject): boolean;
    /**
     * Registers bootstrap tables, dictionaries, and the database object itself.
     */
    private registerBootstrapHandles;
    /**
     * Assigns a freshly generated unique handle to an object.
     *
     * @internal
     */
    private assignGeneratedHandle;
    /**
     * Updates the maximum handle value if the provided handle is greater.
     * This is called when setting an object's objectId from external sources (e.g., reading DXF/DWG).
     *
     * @param handle - The handle to check and potentially update maxHandle with
     *
     * @example
     * ```typescript
     * database.updateMaxHandle('1A2B');
     * ```
     */
    updateMaxHandle(handle: string): void;
    /**
     * Records the maximum seen handle, staying float-precise below
     * {@link Number.MAX_SAFE_INTEGER} and switching to BigInt tracking above it.
     */
    private trackMaxHandle;
    /**
     * Commits an object's handle into the database.
     *
     * Generates a new handle when the object doesn't have one, when it is temporary,
     * or when a duplicate id exists in the target collection.
     *
     * @internal
     */
    commitObjectHandle(object: AcDbObject, hasId?: (id: AcDbObjectId) => boolean): void;
    /**
     * Returns true when an object already carries an explicit handle that should
     * be preserved over auto-generated registry occupants (typically DXF/DWG imports).
     */
    private shouldPreserveIncomingHandle;
    /**
     * Gets the object ID of the AcDbBlockTableRecord of the current space.
     *
     * The current space can be either model space or paper space.
     *
     * @returns The object ID of the current space
     *
     * @example
     * ```typescript
     * const currentSpaceId = database.currentSpaceId;
     * ```
     */
    get currentSpaceId(): AcDbObjectId;
    /**
     * Sets the current space by object ID.
     *
     * @param value - The object ID of the block table record to set as current space
     * @throws {Error} When the specified block table record ID doesn't exist
     *
     * @example
     * ```typescript
     * database.currentSpaceId = 'some-block-record-id';
     * ```
     */
    set currentSpaceId(value: AcDbObjectId);
    /**
     * Angular unit **display and entry** format for the drawing (AutoCAD system variable **AUNITS**).
     *
     * This does not change how angles are stored internally (radians in geometry); it controls how
     * angles are formatted in the UI and how numeric angle input is interpreted, together with
     * {@link angbase} (**ANGBASE**) and {@link angdir} (**ANGDIR**).
     *
     * @returns Integer code matching {@link AcDbAngleUnits}:
     *
     * | Value | Meaning |
     * |------:|---------|
     * | `0` | **Decimal degrees** ??e.g. `45.5` |
     * | `1` | **Degrees/minutes/seconds** ??e.g. `45d30'15"` |
     * | `2` | **Gradians** ??e.g. `50g` (400 grads = full circle) |
     * | `3` | **Radians** ??e.g. `0.785398...` |
     * | `4` | **Surveyor's units** ??quadrant bearing notation (e.g. `N 45d30'15" E`) |
     *
     * @remarks
     * Prefer assigning {@link AcDbAngleUnits} enum members for readability instead of raw integers.
     *
     * @see {@link AcDbAngleUnits} for the canonical enum used by this codebase.
     * @see {@link https://help.autodesk.com/view/ACD/2027/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-C7C0F6A5-7982-43DB-97F9-5B9B0044E9FA-htm.html | AutoCAD Help: AUNITS}
     *
     * @example
     * ```typescript
     * const angleUnits = database.aunits;
     * ```
     */
    get aunits(): number;
    /**
     * Sets **AUNITS** ??the angular unit display format (see {@link aunits} getter for value meanings).
     *
     * @param value - Integer `0`??4` per {@link AcDbAngleUnits}, or `undefined`/`null` coerced to `0` by the setter chain.
     *
     * @example
     * ```typescript
     * database.aunits = AcDbAngleUnits.DecimalDegrees;
     * ```
     */
    set aunits(value: number);
    /**
     * Angular display precision for the drawing (**AUPREC**): how many decimal places (or equivalent)
     * are used when showing angles, in conjunction with {@link aunits}.
     *
     * AutoCAD typically uses integers in the range **0??**; behavior for other values is
     * implementation-defined in this library (stored as-is).
     *
     * @see {@link https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-EE1ED20C-1096-4299-820F-83F1BC9B96F3 | AutoCAD Help: AUPREC}
     */
    get auprec(): number;
    /**
     * Sets **AUPREC** ??angular display precision (see {@link auprec} getter).
     */
    set auprec(value: number);
    /**
     * Linear unit **display and entry** format for coordinates and lengths (**LUNITS**).
     *
     * This does not set real-world drawing units for inserts (see {@link insunits}); it controls how
     * linear distances are shown and parsed (scientific, decimal, engineering, and so on).
     *
     * @returns Integer code matching {@link AcDbLinearUnits}:
     *
     * | Value | Meaning |
     * |------:|---------|
     * | `1` | **Scientific** |
     * | `2` | **Decimal** |
     * | `3` | **Engineering** (feet + decimal inches) |
     * | `4` | **Architectural** (feet + fractional inches) |
     * | `5` | **Fractional** |
     * | `6` | **Windows desktop** (processing / computational format) |
     *
     * @remarks
     * Prefer assigning {@link AcDbLinearUnits} enum members instead of raw integers.
     *
     * @see {@link AcDbLinearUnits}
     * @see {@link https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-D7C80D1F-B1C0-44A9-898E-B3100FF391CB | AutoCAD Help: LUNITS}
     */
    get lunits(): number;
    /**
     * Sets **LUNITS** ??linear display format (see {@link lunits} getter).
     *
     * @param value - Integer per {@link AcDbLinearUnits}, or coerced default {@link AcDbLinearUnits.Decimal} when `undefined`/`null`.
     */
    set lunits(value: number);
    /**
     * Linear display precision for the drawing (**LUPREC**): number of decimal places (or equivalent)
     * used when showing linear distances, together with {@link lunits}.
     *
     * AutoCAD typically uses integers in the range **0??**; initial value is commonly **4**.
     * Values outside that range are stored as-is by this library.
     *
     * @see {@link https://help.autodesk.com/view/ACD/2027/ENU/?guid=GUID-5FFF39D6-EFC7-49F5-B56A-6023EB5C0DE7 | AutoCAD Help: LUPREC}
     */
    get luprec(): number;
    /**
     * Sets **LUPREC** ??linear display precision (see {@link luprec} getter).
     */
    set luprec(value: number);
    /**
     * Gets the version of the database.
     *
     * @returns The version of the database
     *
     */
    get version(): AcDbDwgVersion;
    /**
     * Sets the version of the database.
     *
     * @param value - The version value of the database
     */
    set version(value: string | number);
    /**
     * Gets the drawing-units value for automatic scaling of blocks, images, or xrefs.
     *
     * This is the current INSUNITS value for the database.
     *
     * @returns The insertion units value
     *
     * @example
     * ```typescript
     * const insertionUnits = database.insunits;
     * ```
     */
    get insunits(): number;
    /**
     * Sets the drawing-units value for automatic scaling.
     *
     * @param value - The new insertion units value
     *
     * @example
     * ```typescript
     * database.insunits = AcDbUnitsValue.Millimeters;
     * ```
     */
    set insunits(value: number);
    /**
     * Controls how feet-inch and fractional linear values are delimited (**UNITMODE**).
     *
     * - `0`: Report format (for example `1'-3 1/2"`)
     * - `1`: Input format (for example `1'-3-1/2"`, fewer spaces)
     *
     * @see {@link https://help.autodesk.com/view/ACD/2027/ENU/?guid=GUID-C52134E8-10EB-4AE7-A0C0-8F798C68F823 | AutoCAD Help: UNITMODE}
     */
    get unitmode(): number;
    set unitmode(value: number);
    /**
     * Legacy drawing measurement system (**MEASUREMENT**): `0` = English, `1` = metric.
     *
     * When **INSUNITS** is unitless, this selects the default real-world unit family for labels.
     */
    get measurement(): number;
    set measurement(value: number);
    /**
     * Gets the line type scale factor.
     *
     * @returns The line type scale factor
     *
     * @example
     * ```typescript
     * const lineTypeScale = database.ltscale;
     * ```
     */
    get ltscale(): number;
    /**
     * Sets the line type scale factor.
     *
     * @param value - The new line type scale factor
     *
     * @example
     * ```typescript
     * database.ltscale = 2.0;
     * ```
     */
    set ltscale(value: number);
    /**
     * Gets the flag whether to display line weight.
     *
     * @returns The flag whether to display line weight.
     *
     * @example
     * ```typescript
     * const lineTypeScale = database.ltscale;
     * ```
     */
    get lwdisplay(): boolean;
    /**
     * Sets the flag whether to display line weight.
     *
     * @param value - The flag whether to display line weight.
     *
     * @example
     * ```typescript
     * database.lwdisplay = true;
     * ```
     */
    /**
     * Whether entities on non-plottable layers should be drawn.
     *
     * Configured via {@link AcDbOpenDatabaseOptions.drawNoPlotLayers} when the
     * database is opened. Defaults to `true`.
     */
    get drawNoPlotLayers(): boolean;
    /**
     * Display tessellation side count for a full circle.
     *
     * Configured via {@link AcDbOpenDatabaseOptions.circleSides} when the
     * database is opened. Defaults to {@link ACDB_DRAW_CIRCLE_SIDES_DRAFT}.
     */
    get drawCircleSides(): number;
    set drawCircleSides(value: number);
    /**
     * Name of the current drawing file (**DWGNAME**), including extension.
     *
     * Read-only through the system-variable API; updated when a drawing is opened
     * or via {@link setDwgName} after save.
     *
     * @see https://help.autodesk.com/view/ACD/2023/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-A89861EF-5F4F-46C6-A1DB-9D985A3858C9-htm.html
     */
    get dwgname(): string;
    /**
     * Updates **DWGNAME** after opening or saving a drawing.
     *
     * @param value - Drawing file name, including extension.
     */
    setDwgName(value: string): void;
    /**
     * Gets or sets the drawing thumbnail preview image.
     *
     * Corresponds to AutoCAD .NET `Database.ThumbnailBitmap`, DXF
     * `THUMBNAILIMAGE` section (group codes 90/310), and the DWG file preview.
     * Stored as raw image bytes (typically BMP/DIB or PNG).
     *
     * @returns Thumbnail image bytes, or `undefined` when none exist.
     */
    get thumbnailImage(): Uint8Array | undefined;
    set thumbnailImage(value: Uint8Array | undefined);
    /**
     * Returns whether entities on the given layer should be drawn under the
     * current {@link drawNoPlotLayers} setting.
     *
     * Layer off/freeze visibility is handled separately by the viewer; this only
     * reflects the no-plot policy.
     */
    isLayerDrawable(layerName: string): boolean;
    set lwdisplay(value: boolean);
    /** TILEMODE: true = model space (1), false = paper space (0). */
    get tilemode(): boolean;
    set tilemode(value: boolean);
    /** PSLTSCALE: paper space linetype scaling. */
    get psltscale(): boolean;
    set psltscale(value: boolean);
    /**
     * Gets the color of new objects as they are created.
     *
     * @returns The current entity color
     *
     * @example
     * ```typescript
     * const currentColor = database.cecolor;
     * ```
     */
    get cecolor(): AcCmColor;
    /**
     * Sets the color of new objects as they are created.
     *
     * @param value - The new current entity color
     *
     * @example
     * ```typescript
     * database.cecolor = new AcCmColor(0xFF0000);
     * ```
     */
    set cecolor(value: AcCmColor);
    /**
     * The line type scaling for new objects relative to the ltscale setting. A line created with
     * celtscale = 2 in a drawing with ltscale set to 0.5 would appear the same as a line created
     * with celtscale = 1 in a drawing with ltscale = 1.
     */
    get celtscale(): number;
    set celtscale(value: number);
    /**
     * The linetype of new objects as they are created.
     */
    get celtype(): string;
    set celtype(value: string);
    /**
     * The layer of new objects as they are created.
     */
    get celweight(): AcGiLineWeight;
    set celweight(value: AcGiLineWeight);
    /**
     * The transparency level of new objects as they are created.
     *
     * Can be ByLayer, ByBlock, or a value from 0 to 90 (percentage).
     */
    get cetransparency(): AcCmTransparency;
    set cetransparency(value: AcCmTransparency);
    /**
     * The layer of new objects as they are created.
     */
    get clayer(): string;
    set clayer(value: string);
    /**
     * The multiline style name used for newly created MLINE entities.
     */
    get cmlstyle(): string;
    set cmlstyle(value: string);
    /**
     * The multiline scale used for newly created MLINE entities.
     */
    get cmlscale(): number;
    set cmlscale(value: number);
    /**
     * The multileader style name used for newly created MLEADER entities.
     */
    get cmleaderstyle(): string;
    set cmleaderstyle(value: string);
    /**
     * The default hatch background color string.
     */
    get hpbackgroundcolor(): AcCmColor;
    set hpbackgroundcolor(value: AcCmColor);
    /**
     * The default color string used for newly created hatches.
     */
    get hpcolor(): AcCmColor;
    set hpcolor(value: AcCmColor);
    /**
     * The default layer used for newly created hatches and fills.
     */
    get hplayer(): string;
    set hplayer(value: string);
    /**
     * The default transparency string used for newly created hatches and fills.
     */
    get hptransparency(): AcCmTransparency;
    set hptransparency(value: AcCmTransparency);
    /**
     * The text style name for new text objects.
     */
    get textstyle(): string;
    set textstyle(value: string);
    /**
     * The dimension style name for new dimension objects (`$DIMSTYLE`).
     */
    get dimstyle(): string;
    set dimstyle(value: string);
    /**
     * The zero (0) base angle with respect to the current UCS in radians.
     */
    get angbase(): number;
    set angbase(value: number);
    /**
     * The direction of positive angles.
     * - 0: Counterclockwise
     * - 1: Clockwise
     */
    get angdir(): number;
    set angdir(value: number);
    /**
     * The current Model Space EXTMAX value
     */
    get extmax(): AcGePoint3d;
    set extmax(value: AcGePoint3dLike);
    /**
     * The current Model Space EXTMIN value
     */
    get extmin(): AcGePoint3d;
    set extmin(value: AcGePoint3dLike);
    /**
     * The extents of current Model Space
     */
    get extents(): AcGeBox3d;
    /**
     * Point display mode. Please get more details on value of this property from [this page](https://help.autodesk.com/view/ACDLT/2022/ENU/?guid=GUID-82F9BB52-D026-4D6A-ABA6-BF29641F459B).
     */
    get pdmode(): number;
    set pdmode(value: number);
    /**
     * Point display size.
     * - 0: Creates a point at 5 percent of the drawing area height
     * - > 0: Specifies an absolute size
     * - < 0: Specifies a percentage of the viewport size
     */
    get pdsize(): number;
    set pdsize(value: number);
    /**
     * Running Object Snap (OSNAP) mode bitmask.
     */
    get osmode(): number;
    set osmode(value: number);
    /**
     * Orthogonal mode flag (ORTHOMODE). When on, cursor movement is constrained
     * to horizontal or vertical relative to the current UCS.
     */
    get orthomode(): number;
    set orthomode(value: number);
    /**
     * Whether hatch objects are included in drawing comparison (**COMPAREHATCH**).
     *
     * - `0`: Hatch objects are excluded (AutoCAD default)
     * - `1`: Hatch objects are included
     *
     * @see https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-BBB5E4A0-B607-4898-9A6B-A65C51551EE5
     */
    get comparehatch(): number;
    set comparehatch(value: number);
    /**
     * Offset between a change-set boundary and the revision cloud
     * (**COMPARERCMARGIN**). AutoCAD range is **1–25**; default is **5**.
     *
     * @see https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-7A230058-048B-4EE6-949D-105AF6AC8E73
     */
    get comparercmargin(): number;
    set comparercmargin(value: number);
    /**
     * Whether text objects are included in drawing comparison (**COMPARETEXT**).
     *
     * - `0`: Text objects are excluded
     * - `1`: Text objects are included (AutoCAD default)
     *
     * @see https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-1BE58261-FA5F-4914-BAC6-C1DF7E3D1E9C
     */
    get comparetext(): number;
    set comparetext(value: number);
    /**
     * Decimal-place geometric tolerance used when comparing two drawings
     * (**COMPARETOLERANCE**). AutoCAD range is **0–14**; default is **6**.
     *
     * @see https://help.autodesk.com/view/ACD/2025/ENU/?guid=GUID-3131F7C8-7199-4EC5-9892-88C2D2A86F78
     */
    get comparetolerance(): number;
    set comparetolerance(value: number);
    /**
     * The most recent failure from {@link read} or {@link openUri}, or `null` after a successful open.
     *
     * Useful when a caller catches no exception (for example a viewer that returns `false`)
     * but still needs to distinguish worker out-of-memory from other parse failures.
     */
    get lastOpenError(): AcDbOpenDatabaseError | null;
    /**
     * Reads drawing data from a string or ArrayBuffer.
     *
     * This method parses the provided data and populates the database with
     * the resulting entities, tables, and objects. The method supports
     * both DXF and DWG file formats.
     *
     * @param data - The drawing data as a string or ArrayBuffer
     *   - For DXF files: Pass a string containing the DXF content
     *   - For DWG files: Pass an ArrayBuffer instance containing the binary DWG data
     * @param options - Options for reading the database
     * @param fileType - The type of file being read (defaults to DXF)
     *
     * @example
     * ```typescript
     * // Reading a DXF file (string)
     * const database = new AcDbDatabase();
     * await database.read(dxfString, { readOnly: true }, AcDbFileType.DXF);
     *
     * // Reading a DWG file (ArrayBuffer)
     * const database = new AcDbDatabase();
     * await database.read(dwgArrayBuffer, { readOnly: true }, AcDbFileType.DWG);
     * ```
     */
    read(data: ArrayBuffer, options: AcDbOpenDatabaseOptions, fileType?: AcDbConverterType): Promise<void>;
    private createConversionProgressHandler;
    /**
     * Read AutoCAD DXF or DWG drawing specified by the URL into the database object.
     * The method automatically detects the file type based on the URL extension:
     * - .dxf files are read as text using readAsText()
     * - .dwg files are read as binary data using readAsArrayBuffer()
     * @param url Input the URL linked to one AutoCAD DXF or DWG file
     * @param options Input options to read drawing data
     */
    openUri(url: string, options: AcDbOpenDatabaseOptions): Promise<void>;
    /**
     * Exports the current database into DXF (ASCII string or binary bytes).
     *
     * The `fileName` parameter is kept for ObjectARX API parity. In this web
     * implementation the method returns the DXF payload instead of writing the
     * filesystem directly.
     *
     * @param _fileName - Kept for ObjectARX parity. Ignored in this implementation.
     * @param precision - Numeric precision used by the DXF filer.
     * @param version - Target DXF/DWG version name or value.
     * @param optionsOrThumbnail - Legacy boolean thumbnail flag, or options with
     *   `saveThumbnailImage` and `format: 'ascii' | 'binary'`.
     * @returns ASCII DXF string, or `Uint8Array` when format is `'binary'`.
     */
    dxfOut(_fileName?: string, precision?: number, version?: AcDbDwgVersion | string | number, optionsOrThumbnail?: boolean | {
        saveThumbnailImage?: boolean;
        format?: 'ascii' | 'binary';
    }): string | Uint8Array;
    /**
     * Triggers xxxAppended events with data in the database to redraw the associated viewer.
     */
    regen(): Promise<void>;
    /**
     * Create default layer, line type, dimension type, text style and layout.
     * @param - Options to specify data to create
     */
    createDefaultData(options?: AcDbCreateDefaultDataOptions): void;
    /**
     * Ensures style dictionaries contain defaults required by one entity type.
     *
     * This is primarily used during entity append so newly created entities can
     * immediately resolve their style references.
     *
     * @internal
     */
    ensureEntityStyleDefaults(entity: AcDbEntity): void;
    /**
     * Ensures the default text style exists in the text style table.
     *
     * This is invoked while converting STYLE records and again after a drawing
     * is fully opened so TEXT/MTEXT entities can resolve a style during
     * progressive rendering.
     */
    ensureTextStyleDefaults(): void;
    private hasDefaultTextStyle;
    /**
     * Ensures required default database data exists.
     *
     * This is used after opening a file (or before exporting) to fill in any
     * missing defaults such as layers, linetypes, text styles, dim styles,
     * viewports, layouts, and registered application IDs.
     */
    private ensureDatabaseDefaults;
    /**
     * Ensures one MLINE style exists for the provided style name.
     */
    private ensureMLineStyle;
    /**
     * Ensures one MLEADER style exists for the provided style name.
     */
    private ensureMLeaderStyle;
    /**
     * Writes the HEADER section for the DXF export.
     *
     * @param filer - DXF output writer.
     */
    private writeDxfHeaderSection;
    /**
     * Writes the CLASSES section for the DXF export.
     *
     * Required for proxy entities whose group code **91** indexes into this
     * section. Skipped when no classes were loaded from the source drawing.
     *
     * @param filer - DXF output writer.
     */
    private writeDxfClassesSection;
    /**
     * Writes the TABLES section for the DXF export.
     *
     * @param filer - DXF output writer.
     * @param version - Target DXF/DWG version, used for conditional tables.
     */
    private writeDxfTablesSection;
    /**
     * Writes the BLOCKS section for the DXF export.
     *
     * @param filer - DXF output writer.
     */
    private writeDxfBlocksSection;
    /**
     * Writes the ENTITIES section for the DXF export.
     *
     * @param filer - DXF output writer.
     */
    private writeDxfEntitiesSection;
    /**
     * Writes the OBJECTS section for the DXF export.
     *
     * @param filer - DXF output writer.
     */
    private writeDxfObjectsSection;
    /**
     * Writes Layer Manager filter tree objects (`ACAD_LAYERFILTERS` /
     * `ACLYDICTIONARY` + XRecords) into the OBJECTS section and attaches an
     * extension dictionary to the Layer Table.
     *
     * @param filer - DXF output writer.
     */
    private writeAcLyLayerFilterObjects;
    /**
     * Writes a single TABLE and its records into the TABLES section.
     *
     * @param filer - DXF output writer.
     * @param tableName - DXF table name (e.g. LAYER, LTYPE).
     * @param table - The symbol table instance.
     * @param records - Records to serialize.
     * @param recordType - DXF record type name for each table record.
     */
    private writeDxfTable;
    /**
     * Writes a single entity record into the DXF stream.
     *
     * The entity is responsible for emitting any additional records (such as
     * VERTEX/SEQEND for polylines or ATTRIB/SEQEND for block references) inside
     * its own `dxfOut` override.
     *
     * @param filer - DXF output writer.
     * @param entity - Entity to serialize.
     */
    private writeDxfEntity;
    /**
     * Writes THUMBNAILIMAGE when preview bytes are present and export requested.
     */
    private writeDxfThumbnailImageSection;
    /**
     * Clears all data from the database.
     *
     * This method removes all entities, tables, and objects from the database,
     * effectively resetting it to an empty state.
     *
     * @example
     * ```typescript
     * database.clear();
     * ```
     */
    private clear;
    /**
     * Updates a sysvar value and dispatches the change event only when the value changed.
     */
    private updateSysVar;
    /**
     * Normalizes special linetype aliases to the internal canonical names.
     */
    private normalizeLinetypeName;
    /**
     * Triggers a system variable changed event with old/new values.
     */
    private triggerSysVarChangedEvent;
    /**
     * Extracts the file name from a URI.
     *
     * @param uri - The URI to extract the file name from
     * @returns The extracted file name, or empty string if extraction fails
     * @private
     */
    private getFileNameFromUri;
}
//# sourceMappingURL=AcDbDatabase.d.ts.map