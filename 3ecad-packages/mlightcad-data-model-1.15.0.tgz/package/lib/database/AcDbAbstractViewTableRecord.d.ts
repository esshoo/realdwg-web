import { AcGePoint2d, AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcGiDefaultLightingType, AcGiOrthographicType, AcGiRenderMode, AcGiView } from '@mlightcad/graphic-interface';
import { AcDbSymbolTableRecord, AcDbSymbolTableRecordAttrs } from './AcDbSymbolTableRecord';
/**
 * Interface defining the attributes for view-related symbol table records.
 */
export interface AcDbAbstractViewTableRecordAttrs extends AcDbSymbolTableRecordAttrs {
    /** Graphics system view configuration */
    gsView: AcGiView;
}
/**
 * Base class for view-related symbol table records.
 *
 * Both AcDbViewTableRecord and AcDbViewportTableRecord share the same
 * view/camera properties (center, target, direction, twist, etc.). This
 * abstract class centralizes those common fields.
 */
export declare abstract class AcDbAbstractViewTableRecord<ATTRS extends AcDbAbstractViewTableRecordAttrs = AcDbAbstractViewTableRecordAttrs> extends AcDbSymbolTableRecord<ATTRS> {
    /**
     * Creates a new AcDbAbstractViewTableRecord instance.
     *
     * @param attrs - Input attribute values for this view table record
     * @param defaultAttrs - Default values for attributes of this view table record
     */
    constructor(attrs?: Partial<ATTRS>, defaultAttrs?: Partial<ATTRS>);
    /**
     * Gets the AcGiView associated with this record.
     */
    get gsView(): AcGiView;
    /**
     * Gets or sets the view center point (DCS).
     */
    get centerPoint(): AcGePoint2d;
    set centerPoint(value: AcGePoint2d);
    /**
     * Gets or sets the view direction from target.
     */
    get viewDirectionFromTarget(): AcGePoint3d;
    set viewDirectionFromTarget(value: AcGePoint3d);
    /**
     * Gets or sets the view target.
     */
    get viewTarget(): AcGePoint3d;
    set viewTarget(value: AcGePoint3d);
    /**
     * Gets or sets the view height.
     */
    get viewHeight(): number;
    set viewHeight(value: number);
    /**
     * Gets or sets the view twist angle (radians).
     */
    get viewTwistAngle(): number;
    set viewTwistAngle(value: number);
    /**
     * Gets or sets the lens length.
     */
    get lensLength(): number;
    set lensLength(value: number);
    /**
     * Gets or sets the front clipping plane distance.
     */
    get frontClippingPlane(): number;
    set frontClippingPlane(value: number);
    /**
     * Gets or sets the back clipping plane distance.
     */
    get backClippingPlane(): number;
    set backClippingPlane(value: number);
    /**
     * Gets or sets the render mode.
     */
    get renderMode(): AcGiRenderMode;
    set renderMode(value: AcGiRenderMode);
    /**
     * Gets or sets the view mode.
     */
    get viewMode(): number;
    set viewMode(value: number);
    /**
     * Gets or sets the UCS icon setting.
     */
    get ucsIconSetting(): number;
    set ucsIconSetting(value: number);
    /**
     * Gets or sets the UCS origin.
     */
    get ucsOrigin(): AcGePoint3d;
    set ucsOrigin(value: AcGePoint3d);
    /**
     * Gets or sets the UCS X axis.
     */
    get ucsXAxis(): AcGePoint3d;
    set ucsXAxis(value: AcGePoint3d);
    /**
     * Gets or sets the UCS Y axis.
     */
    get ucsYAxis(): AcGePoint3d;
    set ucsYAxis(value: AcGePoint3d);
    /**
     * Gets or sets the orthographic type.
     */
    get orthographicType(): AcGiOrthographicType;
    set orthographicType(value: AcGiOrthographicType);
    /**
     * Gets or sets the shade plot setting.
     */
    get shadePlotSetting(): number;
    set shadePlotSetting(value: number);
    /**
     * Gets or sets the shade plot object ID.
     */
    get shadePlotObjectId(): string | undefined;
    set shadePlotObjectId(value: string | undefined);
    /**
     * Gets or sets the visual style object ID.
     */
    get visualStyleObjectId(): string | undefined;
    set visualStyleObjectId(value: string | undefined);
    /**
     * Gets or sets whether default lighting is on.
     */
    get isDefaultLightingOn(): boolean;
    set isDefaultLightingOn(value: boolean);
    /**
     * Gets or sets the default lighting type.
     */
    get defaultLightingType(): AcGiDefaultLightingType;
    set defaultLightingType(value: AcGiDefaultLightingType);
    /**
     * Gets or sets the brightness.
     */
    get brightness(): number;
    set brightness(value: number);
    /**
     * Gets or sets the contrast.
     */
    get contrast(): number;
    set contrast(value: number);
    /**
     * Gets or sets the ambient color.
     */
    get ambientColor(): number | undefined;
    set ambientColor(value: number | undefined);
    /**
     * Gets or sets the view aspect ratio (view width / view height).
     */
    get aspectRatio(): number | undefined;
    set aspectRatio(value: number | undefined);
}
//# sourceMappingURL=AcDbAbstractViewTableRecord.d.ts.map