import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbAbstractViewTableRecord, AcDbAbstractViewTableRecordAttrs } from './AcDbAbstractViewTableRecord';
/**
 * Interface defining the attributes for view table records.
 */
export interface AcDbViewTableRecordAttrs extends AcDbAbstractViewTableRecordAttrs {
    /** Standard flags for the view record */
    standardFlags: number;
    /** View width in DCS */
    viewWidth: number;
    /** Whether a UCS is associated with this view */
    ucsAssociated: boolean;
    /** Whether the camera is plottable */
    cameraPlottable: boolean;
    /** UCS elevation when a UCS is associated */
    ucsElevation: number;
    /** Named UCS object ID (optional) */
    ucsObjectId?: string;
    /** Base UCS object ID (optional) */
    ucsBaseObjectId?: string;
    /** Background object ID for the view */
    backgroundObjectId?: string;
    /** Live section object ID for the view */
    liveSectionObjectId?: string;
    /** Hard-pointer ID to the sun object bound to this view (DXF group 361) */
    sunObjectId?: string;
}
/**
 * Represents a view table record in AutoCAD.
 *
 * This class represents named views in AutoCAD, which store a camera-like
 * configuration including view direction, target, and display settings.
 *
 * @example
 * ```typescript
 * const viewRecord = new AcDbViewTableRecord();
 * viewRecord.name = 'Front';
 * viewRecord.viewWidth = 2000;
 * viewRecord.gsView.viewHeight = 1000;
 * ```
 */
export declare class AcDbViewTableRecord extends AcDbAbstractViewTableRecord<AcDbViewTableRecordAttrs> {
    /**
     * Creates a new AcDbViewTableRecord instance.
     *
     * @param attrs - Input attribute values for this view table record
     * @param defaultAttrs - Default values for attributes of this view table record
     */
    constructor(attrs?: Partial<AcDbViewTableRecordAttrs>, defaultAttrs?: Partial<AcDbViewTableRecordAttrs>);
    /**
     * Gets or sets the standard flags for this view record.
     */
    get standardFlags(): number;
    set standardFlags(value: number);
    /**
     * Gets or sets the view width in DCS.
     */
    get viewWidth(): number;
    set viewWidth(value: number);
    /**
     * Gets or sets whether a UCS is associated to this view.
     */
    get ucsAssociated(): boolean;
    set ucsAssociated(value: boolean);
    /**
     * Gets or sets whether the camera is plottable.
     */
    get cameraPlottable(): boolean;
    set cameraPlottable(value: boolean);
    /**
     * Gets or sets the UCS elevation when UCS is associated.
     */
    get ucsElevation(): number;
    set ucsElevation(value: number);
    /**
     * Gets or sets the named UCS object ID (optional).
     */
    get ucsObjectId(): string | undefined;
    set ucsObjectId(value: string | undefined);
    /**
     * Gets or sets the base UCS object ID (optional).
     */
    get ucsBaseObjectId(): string | undefined;
    set ucsBaseObjectId(value: string | undefined);
    /**
     * Gets or sets the background object ID (optional).
     */
    get backgroundObjectId(): string | undefined;
    set backgroundObjectId(value: string | undefined);
    /**
     * Gets or sets the live section object ID (optional).
     */
    get liveSectionObjectId(): string | undefined;
    set liveSectionObjectId(value: string | undefined);
    /**
     * Gets or sets the hard-pointer object ID to the sun bound to this view
     * (DXF group 361).
     */
    get sunObjectId(): string | undefined;
    set sunObjectId(value: string | undefined);
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbViewTableRecord.d.ts.map