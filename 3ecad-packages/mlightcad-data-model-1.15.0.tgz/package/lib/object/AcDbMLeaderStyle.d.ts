import { AcCmColor } from '@mlightcad/common';
import { AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject } from '../base/AcDbObject';
/**
 * Represents the nongraphical MLEADERSTYLE object.
 *
 * This class mirrors the core ObjectARX `AcDbMLeaderStyle` get/set API by
 * exposing equivalent TypeScript properties.
 */
export declare class AcDbMLeaderStyle extends AcDbObject {
    private _unknown1?;
    private _contentType;
    private _drawMLeaderOrderType;
    private _drawLeaderOrderType;
    private _bitFlags;
    private _maxLeaderSegmentsPoints;
    private _firstSegmentAngleConstraint;
    private _secondSegmentAngleConstraint;
    private _leaderLineType;
    private _leaderLineColor;
    private _leaderLineTypeId?;
    private _leaderLineWeight;
    private _enableLanding;
    private _landingGap;
    private _enableDogleg;
    private _doglegLength;
    private _description;
    private _arrowSymbolId?;
    private _arrowSize;
    private _defaultMTextContents;
    private _textStyleId?;
    private _textLeftAttachmentType;
    private _textAngleType;
    private _textAlignmentType;
    private _textRightAttachmentType;
    private _textColor;
    private _textHeight;
    private _enableFrameText;
    private _textAlignAlwaysLeft;
    private _alignSpace;
    private _blockId?;
    private _blockColor;
    private _blockScale;
    private _enableBlockScale;
    private _blockRotation;
    private _enableBlockRotation;
    private _blockConnectionType;
    private _scale;
    private _overwritePropChanged;
    private _annotative;
    private _breakSize;
    private _textAttachmentDirection;
    private _bottomTextAttachmentType;
    private _topTextAttachmentType;
    private _unknown2?;
    private _extendLeaderToText;
    /**
     * Creates an MLeader style with ObjectARX-compatible default values.
     */
    constructor();
    /**
     * Gets the first undocumented raw style value.
     */
    get unknown1(): number | undefined;
    set unknown1(value: number | undefined);
    /**
     * Gets the content type.
     */
    get contentType(): number;
    set contentType(value: number);
    /**
     * Gets the draw mleader order type.
     */
    get drawMLeaderOrderType(): number;
    set drawMLeaderOrderType(value: number);
    /**
     * Gets the draw leader order type.
     */
    get drawLeaderOrderType(): number;
    set drawLeaderOrderType(value: number);
    /**
     * Gets the bit flags.
     */
    get bitFlags(): number;
    set bitFlags(value: number);
    /**
     * Gets the max leader segments points.
     */
    get maxLeaderSegmentsPoints(): number;
    set maxLeaderSegmentsPoints(value: number);
    /**
     * Gets the legacy alias of `maxLeaderSegmentsPoints`.
     */
    get maxLeaderSegmentPoints(): number;
    set maxLeaderSegmentPoints(value: number);
    /**
     * Gets the first segment angle constraint.
     */
    get firstSegmentAngleConstraint(): number;
    set firstSegmentAngleConstraint(value: number);
    /**
     * Gets the second segment angle constraint.
     */
    get secondSegmentAngleConstraint(): number;
    set secondSegmentAngleConstraint(value: number);
    /**
     * Gets the leader line type.
     */
    get leaderLineType(): number;
    set leaderLineType(value: number);
    /**
     * Gets the leader line color.
     */
    get leaderLineColor(): AcCmColor;
    set leaderLineColor(value: AcCmColor);
    /**
     * Gets the leader line type id.
     */
    get leaderLineTypeId(): string | undefined;
    set leaderLineTypeId(value: string | undefined);
    /**
     * Gets the leader line weight.
     */
    get leaderLineWeight(): number;
    set leaderLineWeight(value: number);
    /**
     * Gets the enable landing.
     */
    get enableLanding(): boolean;
    set enableLanding(value: boolean);
    /**
     * Gets the alias of `enableLanding`.
     */
    get landingEnabled(): boolean;
    set landingEnabled(value: boolean);
    /**
     * Gets the landing gap.
     */
    get landingGap(): number;
    set landingGap(value: number);
    /**
     * Gets the enable dogleg.
     */
    get enableDogleg(): boolean;
    set enableDogleg(value: boolean);
    /**
     * Gets the alias of `enableDogleg`.
     */
    get doglegEnabled(): boolean;
    set doglegEnabled(value: boolean);
    /**
     * Gets the dogleg length.
     */
    get doglegLength(): number;
    set doglegLength(value: number);
    /**
     * Gets the description.
     */
    get description(): string;
    set description(value: string);
    /**
     * Gets the arrow symbol id.
     */
    get arrowSymbolId(): string | undefined;
    set arrowSymbolId(value: string | undefined);
    /**
     * Gets the alias of `arrowSymbolId`.
     */
    get arrowheadId(): string | undefined;
    set arrowheadId(value: string | undefined);
    /**
     * Gets the arrow size.
     */
    get arrowSize(): number;
    set arrowSize(value: number);
    /**
     * Gets the alias of `arrowSize`.
     */
    get arrowheadSize(): number;
    set arrowheadSize(value: number);
    /**
     * Gets the default mtext contents.
     */
    get defaultMTextContents(): string;
    set defaultMTextContents(value: string);
    /**
     * Gets the alias of `defaultMTextContents`.
     */
    get defaultMText(): string;
    set defaultMText(value: string);
    /**
     * Gets the alias of `defaultMTextContents`.
     */
    get textString(): string;
    set textString(value: string);
    /**
     * Gets the text style id.
     */
    get textStyleId(): string | undefined;
    set textStyleId(value: string | undefined);
    /**
     * Gets the alias of `textStyleId`.
     */
    get textStyle(): string | undefined;
    set textStyle(value: string | undefined);
    /**
     * Gets the text left attachment type.
     */
    get textLeftAttachmentType(): number;
    set textLeftAttachmentType(value: number);
    /**
     * Gets the text angle type.
     */
    get textAngleType(): number;
    set textAngleType(value: number);
    /**
     * Gets the text alignment type.
     */
    get textAlignmentType(): number;
    set textAlignmentType(value: number);
    /**
     * Gets the text right attachment type.
     */
    get textRightAttachmentType(): number;
    set textRightAttachmentType(value: number);
    /**
     * Gets the text color.
     */
    get textColor(): AcCmColor;
    set textColor(value: AcCmColor);
    /**
     * Gets the text height.
     */
    get textHeight(): number;
    set textHeight(value: number);
    /**
     * Gets the enable frame text.
     */
    get enableFrameText(): boolean;
    set enableFrameText(value: boolean);
    /**
     * Gets the alias of `enableFrameText`.
     */
    get textFrameEnabled(): boolean;
    set textFrameEnabled(value: boolean);
    /**
     * Gets the text align always left.
     */
    get textAlignAlwaysLeft(): boolean;
    set textAlignAlwaysLeft(value: boolean);
    /**
     * Gets the align space.
     */
    get alignSpace(): number;
    set alignSpace(value: number);
    /**
     * Gets the block id.
     */
    get blockId(): string | undefined;
    set blockId(value: string | undefined);
    /**
     * Gets the alias of `blockId`.
     */
    get blockContentId(): string | undefined;
    set blockContentId(value: string | undefined);
    /**
     * Gets the block color.
     */
    get blockColor(): AcCmColor;
    set blockColor(value: AcCmColor);
    /**
     * Gets the alias of `blockColor`.
     */
    get blockContentColor(): AcCmColor;
    set blockContentColor(value: AcCmColor);
    /**
     * Gets the block scale.
     */
    get blockScale(): AcGeVector3dLike;
    set blockScale(value: AcGeVector3dLike);
    /**
     * Gets the alias of `blockScale`.
     */
    get blockContentScale(): AcGeVector3dLike;
    set blockContentScale(value: AcGeVector3dLike);
    /**
     * Gets the enable block scale.
     */
    get enableBlockScale(): boolean;
    set enableBlockScale(value: boolean);
    /**
     * Gets the alias of `enableBlockScale`.
     */
    get blockContentScaleEnabled(): boolean;
    set blockContentScaleEnabled(value: boolean);
    /**
     * Gets the block rotation.
     */
    get blockRotation(): number;
    set blockRotation(value: number);
    /**
     * Gets the alias of `blockRotation`.
     */
    get blockContentRotation(): number;
    set blockContentRotation(value: number);
    /**
     * Gets the enable block rotation.
     */
    get enableBlockRotation(): boolean;
    set enableBlockRotation(value: boolean);
    /**
     * Gets the alias of `enableBlockRotation`.
     */
    get blockContentRotationEnabled(): boolean;
    set blockContentRotationEnabled(value: boolean);
    /**
     * Gets the block connection type.
     */
    get blockConnectionType(): number;
    set blockConnectionType(value: number);
    /**
     * Gets the alias of `blockConnectionType`.
     */
    get blockContentConnectionType(): number;
    set blockContentConnectionType(value: number);
    /**
     * Gets the scale.
     */
    get scale(): number;
    set scale(value: number);
    /**
     * Gets the alias of `scale`.
     */
    get scaleFactor(): number;
    set scaleFactor(value: number);
    /**
     * Gets the overwrite prop changed.
     */
    get overwritePropChanged(): boolean;
    set overwritePropChanged(value: boolean);
    /**
     * Gets the alias of `overwritePropChanged`.
     */
    get overwritePropertyValue(): boolean;
    set overwritePropertyValue(value: boolean);
    /**
     * Gets the annotative.
     */
    get annotative(): boolean;
    set annotative(value: boolean);
    /**
     * Gets the break size.
     */
    get breakSize(): number;
    set breakSize(value: number);
    /**
     * Gets the alias of `breakSize`.
     */
    get breakGapSize(): number;
    set breakGapSize(value: number);
    /**
     * Gets the text attachment direction.
     */
    get textAttachmentDirection(): number;
    set textAttachmentDirection(value: number);
    /**
     * Gets the bottom text attachment type.
     */
    get bottomTextAttachmentType(): number;
    set bottomTextAttachmentType(value: number);
    /**
     * Gets the alias of `bottomTextAttachmentType`.
     */
    get bottomTextAttachmentDirection(): number;
    set bottomTextAttachmentDirection(value: number);
    /**
     * Gets the top text attachment type.
     */
    get topTextAttachmentType(): number;
    set topTextAttachmentType(value: number);
    /**
     * Gets the alias of `topTextAttachmentType`.
     */
    get topTextAttachmentDirection(): number;
    set topTextAttachmentDirection(value: number);
    /**
     * Gets the extend leader to text.
     */
    get extendLeaderToText(): boolean;
    set extendLeaderToText(value: boolean);
    /**
     * Gets the second undocumented raw style value.
     */
    get unknown2(): boolean | undefined;
    set unknown2(value: boolean | undefined);
    /**
     * Writes this MLeaderStyle object to DXF fields.
     *
     * @param filer DXF filer that receives serialized group codes.
     * @returns The current style instance for chaining.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbMLeaderStyle.d.ts.map