import { AcGePoint2d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject } from '../base/AcDbObject';
/**
 * The AcDbRasterImageDef object (or "image definition object") works with the AcDbRasterImage entity
 * (or "image entity") to implement raster images inside AutoCAD.
 *
 * The relationship between these two classes is much like the relationship between an AutoCAD block
 * definition object and a block insert entity. The image definition object plays a behind-the-scenes
 * role like the block definition, maintaining links to the source image file and managing low-level
 * image processing operations required to display and plot images. Image definition objects are stored
 * in a special AcDbDictionary named ISM_RASTER_IMAGE_DICT.
 *
 * @example
 * ```typescript
 * const imageDef = new AcDbRasterImageDef();
 * imageDef.sourceFileName = '/path/to/image.jpg';
 * ```
 */
export declare class AcDbRasterImageDef extends AcDbObject {
    /** The path name of the externally referenced image file */
    private _sourceFileName;
    /** Class version of this image definition (DXF group 90). */
    private _classVersion;
    /** Image size in pixels, U and V values (DXF groups 10/20). */
    private _imageSize;
    /** Default size of one pixel in drawing units, U and V values (DXF groups 11/12). */
    private _pixelSize;
    /** Whether the image file is loaded (DXF group 280). */
    private _isLoaded;
    /**
     * Resolution units (DXF group 281):
     * 0 = none, 2 = centimeters, 5 = inches.
     */
    private _resolutionUnits;
    /**
     * Creates a new AcDbRasterImageDef instance.
     *
     * @example
     * ```typescript
     * const imageDef = new AcDbRasterImageDef();
     * ```
     */
    constructor();
    /**
     * Gets the path name of the externally referenced image file.
     *
     * @returns The source file name/path
     *
     * @example
     * ```typescript
     * const fileName = imageDef.sourceFileName;
     * console.log('Image file:', fileName);
     * ```
     */
    get sourceFileName(): string;
    /**
     * Sets the path name of the externally referenced image file.
     *
     * @param value - The new source file name/path
     *
     * @example
     * ```typescript
     * imageDef.sourceFileName = '/path/to/image.jpg';
     * ```
     */
    set sourceFileName(value: string);
    /**
     * Gets the class version of this image definition (DXF group 90).
     */
    get classVersion(): number;
    /**
     * Sets the class version of this image definition (DXF group 90).
     */
    set classVersion(value: number);
    /**
     * Gets the image size in pixels (U/V values, DXF groups 10/20).
     */
    get imageSize(): AcGePoint2d;
    /**
     * Sets the image size in pixels (U/V values, DXF groups 10/20).
     */
    set imageSize(value: AcGePoint2d);
    /**
     * Gets the default size of one pixel in drawing units (U/V values,
     * DXF groups 11/12).
     */
    get pixelSize(): AcGePoint2d;
    /**
     * Sets the default size of one pixel in drawing units (U/V values,
     * DXF groups 11/12).
     */
    set pixelSize(value: AcGePoint2d);
    /** Whether the image file is loaded (DXF group 280). */
    get isLoaded(): boolean;
    set isLoaded(value: boolean);
    /**
     * Resolution units (DXF group 281): 0 = none, 2 = centimeters, 5 = inches.
     */
    get resolutionUnits(): number;
    set resolutionUnits(value: number);
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbRasterImageDef.d.ts.map