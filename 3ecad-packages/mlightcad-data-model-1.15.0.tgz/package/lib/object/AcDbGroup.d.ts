import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject, type AcDbObjectId } from '../base/AcDbObject';
/**
 * Nongraphical GROUP object (DXF GROUP).
 *
 * Minimal fields: name, unnamed/selectable flags, and soft-pointers to
 * member entity handles.
 */
export declare class AcDbGroup extends AcDbObject {
    private _name;
    private _unnamed;
    private _selectable;
    private _entityIds;
    get name(): string;
    set name(value: string);
    get unnamed(): boolean;
    set unnamed(value: boolean);
    get selectable(): boolean;
    set selectable(value: boolean);
    get entityIds(): readonly AcDbObjectId[];
    set entityIds(value: readonly AcDbObjectId[]);
    addEntityId(id: AcDbObjectId): void;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbGroup.d.ts.map