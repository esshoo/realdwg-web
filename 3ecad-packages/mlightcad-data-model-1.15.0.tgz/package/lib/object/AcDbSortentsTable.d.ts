import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject, type AcDbObjectId } from '../base/AcDbObject';
/**
 * Nongraphical SORTENTSTABLE object (draw-order soft-pointers).
 */
export declare class AcDbSortentsTable extends AcDbObject {
    private _entityIds;
    get entityIds(): readonly AcDbObjectId[];
    set entityIds(value: readonly AcDbObjectId[]);
    addEntityId(id: AcDbObjectId): void;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbSortentsTable.d.ts.map