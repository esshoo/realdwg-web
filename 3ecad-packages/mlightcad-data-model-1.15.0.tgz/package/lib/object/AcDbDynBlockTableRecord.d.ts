import { AcDbObjectId } from '../base/AcDbObject';
import { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord';
/**
 * ObjectARX-style helper for a dynamic block table record (definition).
 *
 * Construct from an {@link AcDbBlockTableRecord} that owns `ACAD_ENHANCEDBLOCK`
 * (or is referenced by anonymous `*U` representations).
 */
export declare class AcDbDynBlockTableRecord {
    private readonly _btr;
    constructor(btr: AcDbBlockTableRecord);
    /**
     * Returns true when the block table record is a dynamic block definition.
     */
    isDynamicBlock(): boolean;
    /**
     * Object ids of anonymous (`*U`) block table records that represent this
     * dynamic definition.
     *
     * Matches ObjectARX `AcDbDynBlockTableRecord::getAnonymousBlockIds()`.
     */
    getAnonymousBlockIds(): AcDbObjectId[];
    private hasEnhancedBlockDictionary;
    private definitionIdFromBTag;
    private collectAnonymousIdsFromInserts;
    private normalizeId;
}
//# sourceMappingURL=AcDbDynBlockTableRecord.d.ts.map