import { AcDbObjectId } from '../base/AcDbObject';
import { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord';
import { AcDbDatabase } from '../database/AcDbDatabase';
import { AcDbBlockReference } from '../entity/AcDbBlockReference';
/**
 * ObjectARX-style helper for working with dynamic block references.
 *
 * This is not a database-resident object. Construct it from an
 * {@link AcDbBlockReference} (or its object id) and query the anonymous /
 * dynamic definition relationship used for correct display.
 *
 * @example
 * ```typescript
 * const dyn = new AcDbDynBlockReference(blockRef)
 * if (dyn.isDynamicBlock()) {
 *   const anonId = dyn.anonymousBlockTableRecord()
 *   const defId = dyn.dynamicBlockTableRecord()
 * }
 * ```
 */
export declare class AcDbDynBlockReference {
    private readonly _blockRef;
    private readonly _blockRefId;
    constructor(blockRefOrId: AcDbBlockReference | AcDbObjectId);
    /**
     * Returns true when the given block-reference object id is a dynamic block.
     */
    static isDynamicBlock(blockRefId: AcDbObjectId, db?: AcDbDatabase): boolean;
    /**
     * Returns the block table record that should be used to draw `blockRef`.
     *
     * Prefer the anonymous representation when this is a dynamic block instance;
     * otherwise return {@link AcDbBlockReference.blockTableRecord}.
     */
    static drawableBlockTableRecord(blockRef: AcDbBlockReference): AcDbBlockTableRecord | undefined;
    /**
     * Object id of the wrapped block reference.
     */
    blockId(): AcDbObjectId;
    /**
     * Returns true when this reference is (or points at) a dynamic block.
     */
    isDynamicBlock(db?: AcDbDatabase): boolean;
    /**
     * Object id of the anonymous block table record used to draw this reference,
     * or `undefined` when the reference does not use an anonymous representation.
     *
     * Matches ObjectARX `AcDbDynBlockReference::anonymousBlockTableRecord()`.
     */
    anonymousBlockTableRecord(db?: AcDbDatabase): AcDbObjectId | undefined;
    /**
     * Object id of the original dynamic block definition, or `undefined` when
     * this is not a dynamic block reference.
     *
     * Matches ObjectARX `AcDbDynBlockReference::dynamicBlockTableRecord()`.
     */
    dynamicBlockTableRecord(db?: AcDbDatabase): AcDbObjectId | undefined;
    private resolveBlockRef;
    private guessDatabase;
    private getExtensionDictionary;
    private hasRepresentationDictionary;
    private getRepresentationData;
    private asDictionary;
    private getDynamicDefinitionIdFromBTag;
    private blockTableRecordIsEnhanced;
}
//# sourceMappingURL=AcDbDynBlockReference.d.ts.map