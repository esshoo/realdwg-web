import { AcGeBox2d, AcGePoint2d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/AcDbDxfFiler';
import { AcDbObject, AcDbObjectId } from '../../base/AcDbObject';
/**
 * Paper margins for plot settings.
 *
 * Values are expressed in millimeters, matching ObjectARX semantics.
 */
export interface AcDbPlotPaperMargins {
    /** Unprintable margin on the left side of the paper (mm). */
    left: number;
    /** Unprintable margin on the right side of the paper (mm). */
    right: number;
    /** Unprintable margin on the top side of the paper (mm). */
    top: number;
    /** Unprintable margin on the bottom side of the paper (mm). */
    bottom: number;
}
/**
 * Plot scale represented as a ratio of paper units to drawing units.
 *
 * The numerator represents paperspace units, and the denominator represents
 * the physical media units (paper units).
 */
export interface AcDbPlotScale {
    /** Paperspace units (numerator). */
    numerator: number;
    /** Media units (denominator). */
    denominator: number;
}
/**
 * Enumeration of plot paper units used by the plot settings.
 */
export declare enum AcDbPlotPaperUnits {
    /** Paper units are inches. */
    kInches = 0,
    /** Paper units are millimeters. */
    kMillimeters = 1,
    /** Paper units are pixels (device units). */
    kPixels = 2
}
/**
 * Enumeration of plot rotations.
 */
export declare enum AcDbPlotRotation {
    /** 0 degrees rotation. */
    k0degrees = 0,
    /** 90 degrees rotation. */
    k90degrees = 1,
    /** 180 degrees rotation. */
    k180degrees = 2,
    /** 270 degrees rotation. */
    k270degrees = 3
}
/**
 * Enumeration of plot types that define which area to plot.
 */
export declare enum AcDbPlotType {
    /** Plot the current display. */
    kDisplay = 0,
    /** Plot the drawing extents. */
    kExtents = 1,
    /** Plot the drawing limits. */
    kLimits = 2,
    /** Plot a named view. */
    kView = 3,
    /** Plot a window area. */
    kWindow = 4,
    /** Plot the entire layout. */
    kLayout = 5
}
/**
 * Enumeration of shade plot resolution levels.
 */
export declare enum AcDbPlotShadePlotResLevel {
    /** Draft resolution (legacy wireframe behavior). */
    kDraft = 0,
    /** Preview resolution. */
    kPreview = 1,
    /** Normal resolution. */
    kNormal = 2,
    /** Presentation resolution. */
    kPresentation = 3,
    /** Maximum resolution. */
    kMaximum = 4,
    /** Custom resolution using shade plot custom DPI. */
    kCustom = 5
}
/**
 * Enumeration of shade plot types that control how viewports plot.
 */
export declare enum AcDbPlotShadePlotType {
    /** Plot the same way it is displayed. */
    kAsDisplayed = 0,
    /** Plot wireframe regardless of display. */
    kWireframe = 1,
    /** Plot hidden regardless of display. */
    kHidden = 2,
    /** Plot rendered regardless of display. */
    kRendered = 3,
    /** Plot using the referenced visual style. */
    kVisualStyle = 4,
    /** Plot using the referenced render preset. */
    kRenderPreset = 5
}
/**
 * Enumeration of standard plot scales.
 */
export declare enum AcDbPlotStdScaleType {
    /** Scale to fit the printable area. */
    kScaleToFit = 0,
    /** 1/128" = 1'-0" */
    k1_128in_1ft = 1,
    /** 1/64" = 1'-0" */
    k1_64in_1ft = 2,
    /** 1/32" = 1'-0" */
    k1_32in_1ft = 3,
    /** 1/16" = 1'-0" */
    k1_16in_1ft = 4,
    /** 3/32" = 1'-0" */
    k3_32in_1ft = 5,
    /** 1/8" = 1'-0" */
    k1_8in_1ft = 6,
    /** 3/16" = 1'-0" */
    k3_16in_1ft = 7,
    /** 1/4" = 1'-0" */
    k1_4in_1ft = 8,
    /** 3/8" = 1'-0" */
    k3_8in_1ft = 9,
    /** 1/2" = 1'-0" */
    k1_2in_1ft = 10,
    /** 3/4" = 1'-0" */
    k3_4in_1ft = 11,
    /** 1" = 1'-0" */
    k1in_1ft = 12,
    /** 3" = 1'-0" */
    k3in_1ft = 13,
    /** 6" = 1'-0" */
    k6in_1ft = 14,
    /** 1'-0" = 1'-0" */
    k1ft_1ft = 15,
    /** 1:1 */
    k1_1 = 16,
    /** 1:2 */
    k1_2 = 17,
    /** 1:4 */
    k1_4 = 18,
    /** 1:5 */
    k1_5 = 19,
    /** 1:8 */
    k1_8 = 20,
    /** 1:10 */
    k1_10 = 21,
    /** 1:16 */
    k1_16 = 22,
    /** 1:20 */
    k1_20 = 23,
    /** 1:30 */
    k1_30 = 24,
    /** 1:40 */
    k1_40 = 25,
    /** 1:50 */
    k1_50 = 26,
    /** 1:100 */
    k1_100 = 27,
    /** 2:1 */
    k2_1 = 28,
    /** 4:1 */
    k4_1 = 29,
    /** 8:1 */
    k8_1 = 30,
    /** 10:1 */
    k10_1 = 31,
    /** 100:1 */
    k100_1 = 32,
    /** 1000:1 */
    k1000_1 = 33,
    /** 1 1/2" = 1'-0" */
    k1and1_2in_1ft = 34
}
/**
 * Represents plot settings for a layout or named plot setup.
 *
 * This class mirrors the core responsibilities of ObjectARX `AcDbPlotSettings`,
 * encapsulating plot configuration, media selection, scale, and view settings.
 */
export declare class AcDbPlotSettings extends AcDbObject {
    /** Name of the plot settings (page setup name). */
    private _plotSettingsName;
    /** PC3 plot configuration name. */
    private _plotCfgName;
    /** Locale-independent canonical media name. */
    private _canonicalMediaName;
    /** Plot style table name (CTB/STB). */
    private _currentStyleSheet;
    /** Plot origin (paper offset) in paper units. */
    private _plotOrigin;
    /** Custom print scale as a ratio of paperspace to media units. */
    private _customPrintScale;
    /** Physical paper size in millimeters (width, height). */
    private _plotPaperSize;
    /** Unprintable paper margins in millimeters. */
    private _plotPaperMargins;
    /** Named view used when plot type is set to view. */
    private _plotViewName;
    /** Paper image origin offset in paper units (DXF groups 148/149). */
    private _paperImageOrigin;
    /** Plot window area used when plot type is set to window. */
    private _plotWindowArea;
    /** Whether this plot settings object is for model space. */
    private _modelType;
    /** Whether the plot should be centered on the paper. */
    private _plotCentered;
    /** Whether hidden line removal is enabled for paperspace objects. */
    private _plotHidden;
    /** Units used for plot paper. */
    private _plotPaperUnits;
    /** Whether plot styles are applied during plotting. */
    private _plotPlotStyles;
    /** Rotation applied to the plot on the paper. */
    private _plotRotation;
    /** Which portion of the layout to plot. */
    private _plotType;
    /** Whether viewport borders are plotted. */
    private _plotViewportBorders;
    /** Whether lineweights are printed. */
    private _printLineweights;
    /** Whether lineweights are scaled with plot scale. */
    private _scaleLineweights;
    /** Whether paperspace objects are plotted after viewports. */
    private _drawViewportsFirst;
    /** Whether plot styles are shown in layout display. */
    private _showPlotStyles;
    /** Shade plot type for viewports. */
    private _shadePlotType;
    /** Shade plot resolution level. */
    private _shadePlotResLevel;
    /** Shade plot custom DPI value (used with kCustom resolution). */
    private _shadePlotCustomDpi;
    /** Object ID for visual style or render preset referenced by shade plot. */
    private _shadePlotId?;
    /** Standard scale selection. */
    private _stdScaleType;
    /** Whether standard scale is used to compute the current plot scale. */
    private _useStandardScale;
    /**
     * Creates a new AcDbPlotSettings instance.
     *
     * @param modelType - True for model space plot settings; false for layout.
     *
     * @example
     * ```typescript
     * const plotSettings = new AcDbPlotSettings(false);
     * plotSettings.plotCfgName = 'DWG To PDF.pc3';
     * plotSettings.canonicalMediaName = 'ISO_A4_(210.00_x_297.00_MM)';
     * ```
     */
    constructor(modelType?: boolean);
    /**
     * Gets the plot settings name (page setup name).
     */
    get plotSettingsName(): string;
    /**
     * Sets the plot settings name (page setup name).
     */
    set plotSettingsName(value: string);
    /**
     * ObjectARX-style getter for the plot settings name.
     */
    getPlotSettingsName(): string;
    /**
     * ObjectARX-style setter for the plot settings name.
     */
    setPlotSettingsName(value: string): void;
    /**
     * Gets the plot configuration (PC3) name.
     */
    get plotCfgName(): string;
    /**
     * Sets the plot configuration (PC3) name.
     */
    set plotCfgName(value: string);
    /**
     * ObjectARX-style getter for the plot configuration name.
     */
    getPlotCfgName(): string;
    /**
     * Gets the canonical media name (locale-independent paper name).
     */
    get canonicalMediaName(): string;
    /**
     * Sets the canonical media name (locale-independent paper name).
     */
    set canonicalMediaName(value: string);
    /**
     * ObjectARX-style getter for the canonical media name.
     */
    getCanonicalMediaName(): string;
    /**
     * Gets the plot style table name (CTB/STB).
     */
    get currentStyleSheet(): string;
    /**
     * Sets the plot style table name (CTB/STB).
     */
    set currentStyleSheet(value: string);
    /**
     * ObjectARX-style getter for the current style sheet.
     */
    getCurrentStyleSheet(): string;
    /**
     * Gets the plot origin (paper offset).
     */
    get plotOrigin(): AcGePoint2d;
    /**
     * Sets the plot origin (paper offset).
     */
    set plotOrigin(value: AcGePoint2d);
    /**
     * ObjectARX-style getter for the plot origin.
     */
    getPlotOrigin(): AcGePoint2d;
    /**
     * Gets the custom print scale ratio.
     */
    get customPrintScale(): AcDbPlotScale;
    /**
     * Sets the custom print scale ratio.
     */
    set customPrintScale(value: AcDbPlotScale);
    /**
     * ObjectARX-style getter for the custom print scale.
     */
    getCustomPrintScale(): AcDbPlotScale;
    /**
     * Gets the plot paper size (physical size in millimeters).
     */
    get plotPaperSize(): AcGePoint2d;
    /**
     * Sets the plot paper size (physical size in millimeters).
     */
    set plotPaperSize(value: AcGePoint2d);
    /**
     * ObjectARX-style getter for the plot paper size.
     */
    getPlotPaperSize(): AcGePoint2d;
    /**
     * Gets the plot paper margins (unprintable area in millimeters).
     */
    get plotPaperMargins(): AcDbPlotPaperMargins;
    /**
     * Sets the plot paper margins (unprintable area in millimeters).
     */
    set plotPaperMargins(value: AcDbPlotPaperMargins);
    /**
     * ObjectARX-style getter for the plot paper margins.
     */
    getPlotPaperMargins(): AcDbPlotPaperMargins;
    /**
     * Gets the plot view name used when plot type is kView.
     */
    get plotViewName(): string;
    /**
     * Sets the plot view name used when plot type is kView.
     */
    set plotViewName(value: string);
    /**
     * ObjectARX-style getter for the plot view name.
     */
    getPlotViewName(): string;
    /**
     * Gets the paper image origin offset in paper units (DXF groups 148/149).
     */
    get paperImageOrigin(): AcGePoint2d;
    /**
     * Sets the paper image origin offset in paper units (DXF groups 148/149).
     */
    set paperImageOrigin(value: AcGePoint2d);
    /**
     * Gets the plot window area used when plot type is kWindow.
     */
    get plotWindowArea(): AcGeBox2d;
    /**
     * Sets the plot window area used when plot type is kWindow.
     */
    set plotWindowArea(value: AcGeBox2d);
    /**
     * ObjectARX-style getter for the plot window area.
     */
    getPlotWindowArea(): AcGeBox2d;
    /**
     * Gets whether this plot settings object is for model space.
     */
    get modelType(): boolean;
    /**
     * Sets whether this plot settings object is for model space.
     */
    set modelType(value: boolean);
    /**
     * ObjectARX-style getter for model type.
     */
    getModelType(): boolean;
    /**
     * ObjectARX-style setter for model type.
     */
    setModelType(value: boolean): void;
    /**
     * Gets whether viewports are plotted after paperspace objects.
     */
    get drawViewportsFirst(): boolean;
    /**
     * Sets whether viewports are plotted after paperspace objects.
     */
    set drawViewportsFirst(value: boolean);
    /**
     * ObjectARX-style setter for drawing viewports first.
     */
    setDrawViewportsFirst(value: boolean): void;
    /**
     * Gets whether the plot is centered on the paper.
     */
    get plotCentered(): boolean;
    /**
     * Sets whether the plot is centered on the paper.
     */
    set plotCentered(value: boolean);
    /**
     * ObjectARX-style setter for plot centered.
     */
    setPlotCentered(value: boolean): void;
    /**
     * Gets whether hidden line removal is applied to paperspace objects.
     */
    get plotHidden(): boolean;
    /**
     * Sets whether hidden line removal is applied to paperspace objects.
     */
    set plotHidden(value: boolean);
    /**
     * ObjectARX-style setter for plot hidden.
     */
    setPlotHidden(value: boolean): void;
    /**
     * Gets the plot paper units.
     */
    get plotPaperUnits(): AcDbPlotPaperUnits;
    /**
     * Sets the plot paper units.
     */
    set plotPaperUnits(value: AcDbPlotPaperUnits);
    /**
     * Gets whether plot styles are applied during plotting.
     */
    get plotPlotStyles(): boolean;
    /**
     * Sets whether plot styles are applied during plotting.
     */
    set plotPlotStyles(value: boolean);
    /**
     * ObjectARX-style setter for plot plot styles.
     */
    setPlotPlotStyles(value: boolean): void;
    /**
     * Gets the plot rotation.
     */
    get plotRotation(): AcDbPlotRotation;
    /**
     * Sets the plot rotation.
     */
    set plotRotation(value: AcDbPlotRotation);
    /**
     * Gets the plot type (display, extents, view, etc.).
     */
    get plotType(): AcDbPlotType;
    /**
     * Sets the plot type (display, extents, view, etc.).
     */
    set plotType(value: AcDbPlotType);
    /**
     * Gets whether viewport borders are plotted.
     */
    get plotViewportBorders(): boolean;
    /**
     * Sets whether viewport borders are plotted.
     */
    set plotViewportBorders(value: boolean);
    /**
     * ObjectARX-style setter for plot viewport borders.
     */
    setPlotViewportBorders(value: boolean): void;
    /**
     * Gets whether lineweights are printed.
     */
    get printLineweights(): boolean;
    /**
     * Sets whether lineweights are printed.
     */
    set printLineweights(value: boolean);
    /**
     * ObjectARX-style setter for print lineweights.
     */
    setPrintLineweights(value: boolean): void;
    /**
     * Gets whether lineweights are scaled by the plot scale.
     */
    get scaleLineweights(): boolean;
    /**
     * Sets whether lineweights are scaled by the plot scale.
     */
    set scaleLineweights(value: boolean);
    /**
     * ObjectARX-style setter for scale lineweights.
     */
    setScaleLineweights(value: boolean): void;
    /**
     * Gets whether plot styles are shown in layout mode.
     */
    get showPlotStyles(): boolean;
    /**
     * Sets whether plot styles are shown in layout mode.
     */
    set showPlotStyles(value: boolean);
    /**
     * ObjectARX-style setter for show plot styles.
     */
    setShowPlotStyles(value: boolean): void;
    /**
     * Gets the shade plot type for viewports.
     */
    get shadePlot(): AcDbPlotShadePlotType;
    /**
     * Sets the shade plot type for viewports.
     */
    set shadePlot(value: AcDbPlotShadePlotType);
    /**
     * ObjectARX-style setter for shade plot type.
     */
    setShadePlot(value: AcDbPlotShadePlotType): void;
    /**
     * Gets the shade plot resolution level.
     */
    get shadePlotResLevel(): AcDbPlotShadePlotResLevel;
    /**
     * Sets the shade plot resolution level.
     */
    set shadePlotResLevel(value: AcDbPlotShadePlotResLevel);
    /**
     * ObjectARX-style setter for shade plot resolution level.
     */
    setShadePlotResLevel(value: AcDbPlotShadePlotResLevel): void;
    /**
     * Gets the shade plot custom DPI (used with kCustom).
     */
    get shadePlotCustomDPI(): number;
    /**
     * Sets the shade plot custom DPI (used with kCustom).
     */
    set shadePlotCustomDPI(value: number);
    /**
     * ObjectARX-style setter for shade plot custom DPI.
     */
    setShadePlotCustomDPI(value: number): void;
    /**
     * Gets the shade plot ID (visual style or render preset object ID).
     */
    get shadePlotId(): AcDbObjectId | undefined;
    /**
     * Sets the shade plot ID (visual style or render preset object ID).
     */
    set shadePlotId(value: AcDbObjectId | undefined);
    /**
     * Gets whether viewports plot as wireframe based on shade plot settings.
     */
    get plotWireframe(): boolean;
    /**
     * Gets whether viewports plot as raster based on shade plot settings.
     */
    get plotAsRaster(): boolean;
    /**
     * Gets the standard scale selection.
     */
    get stdScaleType(): AcDbPlotStdScaleType;
    /**
     * Sets the standard scale selection.
     */
    set stdScaleType(value: AcDbPlotStdScaleType);
    /**
     * ObjectARX-style getter for the standard scale as a numeric ratio.
     */
    get stdScale(): number;
    /**
     * Gets whether the standard scale is used to compute the plot scale.
     */
    get useStandardScale(): boolean;
    /**
     * Sets whether the standard scale is used to compute the plot scale.
     */
    set useStandardScale(value: boolean);
    /**
     * Writes the plot settings DXF payload.
     *
     * This follows the PLOTSETTINGS group code specification and emits the
     * plot configuration, media, scale, and flag data for this settings object.
     *
     * @param filer - DXF filer that receives the group codes
     * @returns This plot settings instance for chaining
     */
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbPlotSettings.d.ts.map