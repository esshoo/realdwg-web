import { AcGeBox2d, AcGeBox3d, AcGePoint3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../../base/AcDbDxfFiler';
import { AcDbPlotSettings } from './AcDbPlotSettings';
/**
 * Represents the stored characteristics of each paperspace layout.
 *
 * Layout objects are stored in an AcDbDictionary object with an ACAD_LAYOUT key,
 * allowing easy iteration and indexing. Each layout represents a paperspace
 * configuration that can be used for printing or plotting.
 *
 * @example
 * ```typescript
 * const layout = new AcDbLayout();
 * layout.layoutName = 'A4 Landscape';
 * layout.tabOrder = 1;
 * layout.limits = new AcGeBox2d();
 * ```
 */
export declare class AcDbLayout extends AcDbPlotSettings {
    /** The user-friendly layout name displayed in the tab control */
    private _layoutName;
    /** The tab order field controlling the display order */
    private _tabOrder;
    /** Flag indicating whether the layout tab is selected */
    private _tabSelected;
    /** The associated block table record ID of this layout */
    private _blockTableRecordId;
    /** Limits for this layout (defined by LIMMAX while this layout is current) */
    private _limits;
    /** The current extents setting of the layout */
    private _extents;
    /** Object IDs for viewports in this layout (paperspace). */
    private _viewportArray;
    /**
     * ID/handle of the named `AcDbUCSTableRecord` for this layout, used when
     * `UCSORTHO` is 0 (DXF group 345).
     */
    private _namedUcsId?;
    /**
     * ID/handle of the base `AcDbUCSTableRecord` when the layout's UCS is
     * orthographic (DXF group 346).
     */
    private _orthographicUcsId?;
    /** Layout insertion base point (DXF group 12). */
    private _insertionPoint;
    /** UCS origin for this layout (DXF group 13). */
    private _ucsOrigin;
    /** UCS X axis (DXF group 16). */
    private _ucsXAxis;
    /** UCS Y axis (DXF group 17). */
    private _ucsYAxis;
    /** Elevation (DXF group 146). */
    private _elevation;
    /** Orthographic type of UCS (DXF group 76). */
    private _orthographicType;
    /**
     * Creates a new AcDbLayout instance.
     *
     * @example
     * ```typescript
     * const layout = new AcDbLayout();
     * ```
     */
    constructor();
    /**
     * Gets the user-friendly layout name that is displayed in the tab control.
     *
     * Currently there is no restriction on the name except that the length
     * is limited to 256 characters.
     *
     * @returns The layout name
     *
     * @example
     * ```typescript
     * const name = layout.layoutName;
     * console.log('Layout name:', name);
     * ```
     */
    get layoutName(): string;
    /**
     * Sets the user-friendly layout name that is displayed in the tab control.
     *
     * @param value - The new layout name (limited to 256 characters)
     *
     * @example
     * ```typescript
     * layout.layoutName = 'A4 Landscape';
     * ```
     */
    set layoutName(value: string);
    /**
     * Gets the tab order field, which controls the order in which layouts are displayed.
     *
     * The tab order should be unique and sequential for each layout in the database.
     *
     * @returns The tab order value
     *
     * @example
     * ```typescript
     * const order = layout.tabOrder;
     * ```
     */
    get tabOrder(): number;
    /**
     * Sets the tab order field, which controls the order in which layouts are displayed.
     *
     * @param value - The new tab order value
     *
     * @example
     * ```typescript
     * layout.tabOrder = 1;
     * ```
     */
    set tabOrder(value: number);
    /**
     * Gets whether the layout tab is included in the selection set for operations.
     *
     * This flag indicates whether the layout tab is included in the selection set
     * for operations that affect multiple tabs. The user can perform multiple
     * selection via the user interface using shift-click.
     *
     * @returns True if the tab is selected, false otherwise
     *
     * @example
     * ```typescript
     * const isSelected = layout.tabSelected;
     * ```
     */
    get tabSelected(): boolean;
    /**
     * Sets whether the layout tab is included in the selection set for operations.
     *
     * @param value - True to select the tab, false to deselect it
     *
     * @example
     * ```typescript
     * layout.tabSelected = true;
     * ```
     */
    set tabSelected(value: boolean);
    /**
     * Gets the associated block table record ID of this layout.
     *
     * @returns The block table record ID
     *
     * @example
     * ```typescript
     * const blockId = layout.blockTableRecordId;
     * ```
     */
    get blockTableRecordId(): string;
    /**
     * Sets the associated block table record ID of this layout.
     *
     * @param value - The new block table record ID
     *
     * @example
     * ```typescript
     * layout.blockTableRecordId = 'some-block-id';
     * ```
     */
    set blockTableRecordId(value: string);
    /**
     * Gets the limits for this layout.
     *
     * Limits are defined by LIMMAX while this layout is current.
     *
     * @returns The layout limits as a 2D bounding box
     *
     * @example
     * ```typescript
     * const limits = layout.limits;
     * console.log('Layout limits:', limits);
     * ```
     */
    get limits(): AcGeBox2d;
    /**
     * Sets the limits for this layout.
     *
     * @param value - The new layout limits as a 2D bounding box
     *
     * @example
     * ```typescript
     * layout.limits = new AcGeBox2d();
     * ```
     */
    set limits(value: AcGeBox2d);
    /**
     * Gets the current extents setting of the layout.
     *
     * This value may not be the actual extents of the geometry in the layout,
     * it is just the value last saved in the layout.
     *
     * @returns The layout extents as a 3D bounding box
     *
     * @example
     * ```typescript
     * const extents = layout.extents;
     * console.log('Layout extents:', extents);
     * ```
     */
    get extents(): AcGeBox3d;
    /**
     * Sets the current extents setting of the layout.
     *
     * @param value - The new layout extents as a 3D bounding box
     *
     * @example
     * ```typescript
     * layout.extents = new AcGeBox3d();
     * ```
     */
    set extents(value: AcGeBox3d);
    /**
     * Gets the paperspace viewport object IDs for this layout.
     */
    get viewportArray(): string[];
    /**
     * Sets the paperspace viewport object IDs for this layout.
     */
    set viewportArray(value: string[]);
    /**
     * Gets the named UCS object ID used when `UCSORTHO` is 0 (DXF group 345).
     */
    get namedUcsId(): string | undefined;
    /**
     * Sets the named UCS object ID used when `UCSORTHO` is 0 (DXF group 345).
     */
    set namedUcsId(value: string | undefined);
    /**
     * Gets the base UCS object ID used when the layout's UCS is orthographic
     * (DXF group 346).
     */
    get orthographicUcsId(): string | undefined;
    /**
     * Sets the base UCS object ID used when the layout's UCS is orthographic
     * (DXF group 346).
     */
    set orthographicUcsId(value: string | undefined);
    /** Layout insertion base point (DXF group 12). */
    get insertionPoint(): AcGePoint3d;
    set insertionPoint(value: AcGePoint3d);
    /** UCS origin for this layout (DXF group 13). */
    get ucsOrigin(): AcGePoint3d;
    set ucsOrigin(value: AcGePoint3d);
    /** UCS X axis (DXF group 16). */
    get ucsXAxis(): AcGeVector3dLike;
    set ucsXAxis(value: AcGeVector3dLike);
    /** UCS Y axis (DXF group 17). */
    get ucsYAxis(): AcGeVector3dLike;
    set ucsYAxis(value: AcGeVector3dLike);
    /** Elevation (DXF group 146). */
    get elevation(): number;
    set elevation(value: number);
    /** Orthographic type of UCS (DXF group 76). */
    get orthographicType(): number;
    set orthographicType(value: number);
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbLayout.d.ts.map