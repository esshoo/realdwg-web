import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject } from '../base/AcDbObject';
import { AcDbResultBuffer } from '../base/AcDbResultBuffer';
/**
 * Defines how duplicate records are handled when objects
 * are cloned into a destination database.
 *
 * @remarks
 * This enum mirrors AcDb::DuplicateRecordCloning in ObjectARX.
 */
export declare enum AcDbDuplicateRecordCloning {
    /** No special cloning behavior */
    NotApplicable = 0,
    /** Ignore the duplicate record */
    Ignore = 1,
    /** Replace the existing record */
    Replace = 2,
    /** Mangle the name when coming from an external reference */
    XrefMangleName = 3,
    /** Always mangle the name to avoid conflicts */
    MangleName = 4
}
/**
 * Represents an Xrecord object used to store arbitrary
 * application-defined data.
 *
 * @remarks
 * An Xrecord is typically stored in an extension dictionary
 * and contains an {@link AcDbResultBuffer}.
 */
export declare class AcDbXrecord extends AcDbObject {
    private _data;
    /** Duplicate-record cloning flag read from/written to DXF group 280. */
    private _cloningFlag?;
    /**
     * Gets or sets the data stored in this Xrecord.
     *
     * @remarks
     * Equivalent to the Xrecord.Data property in AutoCAD .NET.
     */
    get data(): AcDbResultBuffer | null;
    set data(value: AcDbResultBuffer | null);
    /**
     * Removes all data from this Xrecord.
     */
    clear(): void;
    /**
     * Creates a deep copy of this Xrecord.
     *
     * @remarks
     * The cloned Xrecord contains a cloned ResultBuffer.
     */
    clone(): this;
    /**
     * Returns the duplicate record cloning behavior for this Xrecord.
     *
     * @remarks
     * This method exists for API parity with ObjectARX.
     */
    getDuplicateRecordCloning(): AcDbDuplicateRecordCloning;
    /**
     * Sets the duplicate record cloning behavior for this Xrecord
     * (DXF group 280).
     */
    setDuplicateRecordCloning(value: AcDbDuplicateRecordCloning): void;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbXrecord.d.ts.map