import { AcCmColor } from '@mlightcad/common';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject } from '../base/AcDbObject';
/**
 * One element definition in an MLINE style.
 */
export interface AcDbMlineStyleElement {
    /**
     * Offset from the MLINE reference axis.
     */
    offset: number;
    /**
     * Color definition for this element.
     */
    color: AcCmColor;
    /**
     * Linetype name for this element.
     */
    lineType: string;
}
/**
 * Represents the nongraphical MLINESTYLE object.
 */
export declare class AcDbMlineStyle extends AcDbObject {
    private _styleName;
    private _flags;
    private _description;
    private _fillColor;
    private _startAngle;
    private _endAngle;
    private _elements;
    constructor();
    get styleName(): string;
    set styleName(value: string);
    get flags(): number;
    set flags(value: number);
    get description(): string;
    set description(value: string);
    get fillColor(): AcCmColor;
    set fillColor(value: AcCmColor);
    /**
     * Gets/sets start angle in DXF degree units.
     */
    get startAngle(): number;
    set startAngle(value: number);
    /**
     * Gets/sets end angle in DXF degree units.
     */
    get endAngle(): number;
    set endAngle(value: number);
    get elementCount(): number;
    get elements(): AcDbMlineStyleElement[];
    set elements(value: AcDbMlineStyleElement[]);
    addElement(element: AcDbMlineStyleElement): void;
    removeElementAt(index: number): void;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private finishMlineElements;
}
//# sourceMappingURL=AcDbMlineStyle.d.ts.map