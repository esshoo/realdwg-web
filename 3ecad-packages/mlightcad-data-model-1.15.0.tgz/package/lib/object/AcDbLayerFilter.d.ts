import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbFilter } from './AcDbFilter';
/**
 * Layer filter object used with the AutoCAD **index/filter** scheme
 * (`INDEXCTL` / block regeneration), not the Layer Properties Manager tree.
 *
 * An {@link AcDbLayerFilter} stores a flat list of layer names that participate
 * in a layer-based query against a block. It is the counterpart to
 * {@link AcDbLayerIndex}; {@link AcDbLayerFilter.indexClass} returns the layer
 * index class name.
 *
 * @remarks
 * Mirrors the ObjectARX `AcDbLayerFilter` class. For the Layer Manager
 * property/group filter **tree**, see {@link AcLyLayerFilter} /
 * {@link AcLyLayerGroup} under the ObjectARX `AcLy*` classes.
 *
 * In DXF this object is written as type `LAYER_FILTER` with subclass markers
 * `AcDbFilter` and `AcDbLayerFilter`, and repeated group code 8 entries for
 * layer names.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbLayerFilter
 *
 * @example
 * ```typescript
 * const filter = new AcDbLayerFilter();
 * filter.add('Walls');
 * filter.add('Doors');
 * console.log(filter.layerCount()); // 2
 * console.log(filter.getAt(0)); // 'Walls'
 * ```
 */
export declare class AcDbLayerFilter extends AcDbFilter {
    /** Layer names included in this filter (DXF group code 8, repeated). */
    private _layerNames;
    /**
     * Creates a new {@link AcDbLayerFilter} instance.
     *
     * @example
     * ```typescript
     * const filter = new AcDbLayerFilter();
     * ```
     */
    constructor();
    /**
     * Gets a copy of the layer names stored in this filter.
     *
     * @returns An array of layer names.
     */
    get layerNames(): readonly string[];
    /**
     * Replaces the layer names stored in this filter.
     *
     * @param value - The new list of layer names.
     */
    set layerNames(value: readonly string[]);
    /**
     * Adds a layer name to this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::add`. Duplicate names are ignored.
     *
     * @param layerName - Layer name to include in the filter.
     * @returns `true` if the name was added; `false` if it was empty or already present.
     *
     * @example
     * ```typescript
     * filter.add('0');
     * ```
     */
    add(layerName: string): boolean;
    /**
     * Gets the layer name at the specified index.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::getAt`.
     *
     * @param index - Zero-based index into the layer name list.
     * @returns The layer name at `index`.
     * @throws {Error} If `index` is out of range.
     *
     * @example
     * ```typescript
     * const name = filter.getAt(0);
     * ```
     */
    getAt(index: number): string;
    /**
     * Removes a layer name from this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::remove`.
     *
     * @param layerName - Layer name to remove.
     * @returns `true` if the name was removed; otherwise `false`.
     *
     * @example
     * ```typescript
     * filter.remove('Walls');
     * ```
     */
    remove(layerName: string): boolean;
    /**
     * Returns the number of layer names in this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::layerCount`.
     *
     * @returns The number of layer names.
     *
     * @example
     * ```typescript
     * const count = filter.layerCount();
     * ```
     */
    layerCount(): number;
    /**
     * Returns the index class name associated with this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::indexClass`, which returns
     * `AcDbLayerIndex::desc()`. This port returns the class name string.
     *
     * @returns Always `'AcDbLayerIndex'`.
     */
    indexClass(): string;
    /**
     * Returns whether this filter is considered valid.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerFilter::isValid`. A filter is valid when it
     * contains at least one non-empty layer name.
     *
     * @returns `true` if the filter is valid; otherwise `false`.
     */
    isValid(): boolean;
    /**
     * Writes DXF fields for this layer filter object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbLayerFilter.d.ts.map