import { AcGePoint2d, AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObject } from '../base/AcDbObject';
/**
 * Abstract base class for filter objects used with the AutoCAD index/filter
 * scheme.
 *
 * An {@link AcDbFilter} defines a query used when iterating block data through
 * filtered block iterators. The corresponding index class is obtained through
 * {@link AcDbFilter.indexClass}.
 *
 * @remarks
 * Mirrors the ObjectARX `AcDbFilter` class. Applications that provide a custom
 * indexing scheme typically also implement matching
 * {@link AcDbIndex} and filtered-block-iterator types.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbFilter
 *
 * @example
 * ```typescript
 * class MyFilter extends AcDbFilter {
 *   indexClass(): string {
 *     return 'MyIndex';
 *   }
 * }
 * ```
 */
export declare abstract class AcDbFilter extends AcDbObject {
    /**
     * Clip boundary vertices in OCS (SPATIAL_FILTER DXF groups 10/20).
     *
     * @remarks
     * These fields represent the generic clip-boundary data used by
     * `AcDbSpatialFilter` (DXF type `SPATIAL_FILTER`). No concrete spatial
     * filter class exists in this port yet (no `SPATIAL_FILTER` DXF reader
     * wiring), so this data is captured here for forward compatibility;
     * subclasses like {@link AcDbLayerFilter} simply never populate it.
     */
    private _boundaryVertices;
    /** Normal to the plane containing the clip boundary (DXF group 210). */
    private _clipBoundaryNormal?;
    /** Origin of the clip boundary's local coordinate system (DXF group 11). */
    private _clipBoundaryOrigin?;
    /** Whether the clip boundary is displayed (DXF group 71). */
    private _clipBoundaryDisplayEnabled;
    /** Whether front clipping is enabled (DXF group 72). */
    private _frontClippingEnabled;
    /** Front clipping plane distance, when enabled (DXF group 40). */
    private _frontClippingDistance?;
    /** Whether back clipping is enabled (DXF group 73). */
    private _backClippingEnabled;
    /** Back clipping plane distance, when enabled (DXF group 41). */
    private _backClippingDistance?;
    /**
     * Creates a new {@link AcDbFilter} instance.
     */
    constructor();
    /**
     * Gets the clip boundary vertices in OCS (SPATIAL_FILTER DXF groups 10/20).
     */
    get boundaryVertices(): readonly AcGePoint2d[];
    /**
     * Sets the clip boundary vertices in OCS (SPATIAL_FILTER DXF groups 10/20).
     */
    set boundaryVertices(value: readonly AcGePoint2d[]);
    /**
     * Gets the normal to the plane containing the clip boundary
     * (DXF group 210).
     */
    get clipBoundaryNormal(): AcGePoint3d | undefined;
    /**
     * Sets the normal to the plane containing the clip boundary
     * (DXF group 210).
     */
    set clipBoundaryNormal(value: AcGePoint3d | undefined);
    /**
     * Gets the origin of the clip boundary's local coordinate system
     * (DXF group 11).
     */
    get clipBoundaryOrigin(): AcGePoint3d | undefined;
    /**
     * Sets the origin of the clip boundary's local coordinate system
     * (DXF group 11).
     */
    set clipBoundaryOrigin(value: AcGePoint3d | undefined);
    /**
     * Gets whether the clip boundary is displayed (DXF group 71).
     */
    get clipBoundaryDisplayEnabled(): boolean;
    /**
     * Sets whether the clip boundary is displayed (DXF group 71).
     */
    set clipBoundaryDisplayEnabled(value: boolean);
    /**
     * Gets whether front clipping is enabled (DXF group 72).
     */
    get frontClippingEnabled(): boolean;
    /**
     * Sets whether front clipping is enabled (DXF group 72).
     */
    set frontClippingEnabled(value: boolean);
    /**
     * Gets the front clipping plane distance (DXF group 40).
     */
    get frontClippingDistance(): number | undefined;
    /**
     * Sets the front clipping plane distance (DXF group 40).
     */
    set frontClippingDistance(value: number | undefined);
    /**
     * Gets whether back clipping is enabled (DXF group 73).
     */
    get backClippingEnabled(): boolean;
    /**
     * Sets whether back clipping is enabled (DXF group 73).
     */
    set backClippingEnabled(value: boolean);
    /**
     * Gets the back clipping plane distance (DXF group 41).
     */
    get backClippingDistance(): number | undefined;
    /**
     * Sets the back clipping plane distance (DXF group 41).
     */
    set backClippingDistance(value: number | undefined);
    /**
     * Returns the class name of the {@link AcDbIndex}-derived type required to
     * process this filter.
     *
     * @remarks
     * In ObjectARX this method returns an `AcRxClass*`. This TypeScript port
     * returns the class name string instead.
     *
     * @returns The index class name associated with this filter.
     */
    abstract indexClass(): string;
    /**
     * Writes DXF fields for this filter object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbFilter.d.ts.map