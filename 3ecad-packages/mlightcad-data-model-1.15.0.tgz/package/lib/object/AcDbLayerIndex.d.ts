import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbObjectId } from '../base/AcDbObject';
import type { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord';
import type { AcDbLayerTable } from '../database/AcDbLayerTable';
import type { AcDbFilter } from './AcDbFilter';
import { AcDbBlockChangeIterator, AcDbFilteredBlockIterator, AcDbIndex, AcDbIndexUpdateData } from './AcDbIndex';
/**
 * Describes one layer entry stored in an {@link AcDbLayerIndex}.
 *
 * @remarks
 * LAYER_INDEX DXF objects store parallel arrays of layer names (group 8),
 * hard-owner IDBUFFER handles (group 360), and IDBUFFER entry counts
 * (group 90). This type groups those related values for convenience.
 */
export interface AcDbLayerIndexEntry {
    /** Layer name (DXF group code 8). */
    layerName: string;
    /** Hard-owner handle of the associated IDBUFFER object (DXF group code 360). */
    idBufferId: AcDbObjectId;
    /** Number of entries in the associated IDBUFFER (DXF group code 90). */
    idBufferEntryCount: number;
}
/**
 * Layer index object used with the AutoCAD index/filter scheme.
 *
 * An {@link AcDbLayerIndex} is an index implementation specialized for layers.
 * It is typically associated with a block table record and used together with
 * {@link AcDbLayerFilter} when regenerating xrefs and blocks under the
 * `INDEXCTL` system variable.
 *
 * @remarks
 * Mirrors the ObjectARX `AcDbLayerIndex` class. In DXF this object is written
 * as type `LAYER_INDEX` with subclass markers `AcDbIndex` and
 * `AcDbLayerIndex`.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbLayerIndex
 *
 * @example
 * ```typescript
 * const index = new AcDbLayerIndex();
 * index.lastUpdatedAt = 2451545.0;
 * index.layerNames = ['0', 'Walls'];
 * index.idBufferIds = ['1A', '1B'];
 * index.idBufferEntryCounts = [10, 4];
 * ```
 */
export declare class AcDbLayerIndex extends AcDbIndex {
    /** Layer names included in this index (DXF group code 8, repeated). */
    private _layerNames;
    /** Hard-owner handles to IDBUFFER objects (DXF group code 360, repeated). */
    private _idBufferIds;
    /** Entry counts for each IDBUFFER (DXF group code 90, repeated). */
    private _idBufferEntryCounts;
    /**
     * Creates a new {@link AcDbLayerIndex} instance.
     *
     * @example
     * ```typescript
     * const index = new AcDbLayerIndex();
     * ```
     */
    constructor();
    /**
     * Gets a copy of the layer names stored in this index.
     *
     * @returns An array of layer names.
     */
    get layerNames(): readonly string[];
    /**
     * Replaces the layer names stored in this index.
     *
     * @param value - The new list of layer names.
     */
    set layerNames(value: readonly string[]);
    /**
     * Gets a copy of the IDBUFFER object IDs referenced by this index.
     *
     * @returns An array of hard-owner IDBUFFER handles.
     */
    get idBufferIds(): readonly AcDbObjectId[];
    /**
     * Replaces the IDBUFFER object IDs referenced by this index.
     *
     * @param value - The new list of IDBUFFER handles.
     */
    set idBufferIds(value: readonly AcDbObjectId[]);
    /**
     * Gets a copy of the IDBUFFER entry counts stored in this index.
     *
     * @returns An array of IDBUFFER entry counts.
     */
    get idBufferEntryCounts(): readonly number[];
    /**
     * Replaces the IDBUFFER entry counts stored in this index.
     *
     * @param value - The new list of entry counts.
     */
    set idBufferEntryCounts(value: readonly number[]);
    /**
     * Returns grouped layer-index entries derived from the parallel DXF arrays.
     *
     * @returns An array of {@link AcDbLayerIndexEntry} values.
     */
    get entries(): AcDbLayerIndexEntry[];
    /**
     * Replaces this index from grouped layer-index entries.
     *
     * @param value - The entries to store.
     */
    set entries(value: readonly AcDbLayerIndexEntry[]);
    /**
     * Computes (rebuilds) this layer index from a layer table and block table
     * record.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerIndex::compute`. This port records layer names
     * present in `layerTable` and associates the index with `blockTableRecord`;
     * IDBUFFER population is not performed here.
     *
     * @param layerTable - Layer table used as the index source.
     * @param blockTableRecord - Block table record being indexed.
     * @returns `true` if the compute succeeded.
     */
    compute(layerTable?: AcDbLayerTable, blockTableRecord?: AcDbBlockTableRecord): boolean;
    /**
     * Creates a filtered block iterator for the given layer filter query.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerIndex::newIterator`. A full filtered iterator
     * is not yet implemented in this port.
     *
     * @param _filter - The filter defining the query (typically an
     *   {@link AcDbLayerFilter}).
     * @returns Always `null` until filtered iteration is implemented.
     */
    newIterator(_filter: AcDbFilter): AcDbFilteredBlockIterator | null;
    /**
     * Fully rebuilds this layer index.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerIndex::rebuildFull`.
     *
     * @param _updateData - Optional index update mapping data.
     * @returns `true` if the rebuild succeeded.
     */
    rebuildFull(_updateData?: AcDbIndexUpdateData): boolean;
    /**
     * Incrementally rebuilds this layer index for modified block contents.
     *
     * @remarks
     * Mirrors ObjectARX `AcDbLayerIndex::rebuildModified`.
     *
     * @param _changeIterator - Optional iterator over changed block entities.
     * @returns `true` if the rebuild succeeded.
     */
    protected rebuildModified(_changeIterator?: AcDbBlockChangeIterator): boolean;
    /**
     * Writes DXF fields for this layer index object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbLayerIndex.d.ts.map