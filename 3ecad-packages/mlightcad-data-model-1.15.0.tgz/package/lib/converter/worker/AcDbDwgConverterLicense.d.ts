/**
 * Shared helpers for classifying `@mlightcad/dwg-converter` license failures.
 *
 * Markers are kept in sync with the converter's user-facing license messages.
 */
/** Error name thrown by `@mlightcad/dwg-converter` for license failures. */
export declare const ACDB_DWG_CONVERTER_LICENSE_ERROR_NAME = "DwgConverterLicenseError";
/** Machine-readable license failure codes shared by worker and open-database errors. */
export type AcDbDwgConverterLicenseCode = 'license_expired' | 'license_invalid';
/**
 * Returns `true` when {@link code} is a DWG converter license failure code.
 */
export declare function acdbIsDwgConverterLicenseCode(code: unknown): code is AcDbDwgConverterLicenseCode;
/**
 * Classifies a license failure message into expired vs invalid.
 *
 * @returns The matching license code, or `undefined` when no marker matches
 */
export declare function acdbClassifyDwgConverterLicenseMessage(message: string): AcDbDwgConverterLicenseCode | undefined;
/**
 * Classifies a known license error message, defaulting unknown text to invalid.
 */
export declare function acdbClassifyDwgConverterLicenseMessageOrInvalid(message: string): AcDbDwgConverterLicenseCode;
//# sourceMappingURL=AcDbDwgConverterLicense.d.ts.map