import type { AcDbObjectId } from '../base/AcDbObject';
import type { AcDbLayerTableRecord } from '../database/AcDbLayerTableRecord';
import { AcLyBoolExpr } from './AcLyBoolExpr';
/**
 * Result returned by {@link AcLyLayerFilter.showEditor}.
 *
 * @remarks
 * Mirrors ObjectARX `AcLyLayerFilter::DialogResult`.
 */
export declare enum AcLyLayerFilterDialogResult {
    /** The editor was cancelled. */
    Cancel = 0,
    /** The editor completed successfully. */
    Ok = 1
}
/**
 * Main Layer Manager filter class (property filter).
 *
 * An {@link AcLyLayerFilter} allows clients to specify a filter expression and
 * nest other filters into a tree. This is the AutoCAD Layer Properties Manager
 * filter model (`AcLy*` classes), not the block-index {@link AcDbLayerFilter}.
 *
 * Nesting rules (AutoCAD Layer Manager behavior):
 * - The tree root may contain both group filters and property filters.
 * - A non-root property filter ({@link isIdFilter} = `false`) may contain
 *   other property filters, but may **not** contain a group filter.
 * - A group filter may contain both group filters and property filters.
 *
 * @remarks
 * Mirrors ObjectARX `AcLyLayerFilter` from `acly.h`.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcLy_Classes
 * @see https://help.autodesk.com/cloudhelp/2019/ENU/OARX-RefGuide/files/OREF-AcLyLayerFilter.html
 *
 * @example
 * ```typescript
 * const unlocked = new AcLyLayerFilter();
 * unlocked.name = 'Unlocked Layers';
 * unlocked.setFilterExpression('LOCKED=="False"');
 *
 * const root = new AcLyLayerFilter();
 * root.name = 'All';
 * root.addNested(unlocked);
 * ```
 */
export declare class AcLyLayerFilter {
    /** Display name of this filter. */
    private _name;
    /** Property-filter expression string (unused by group filters). */
    private _filterExpression;
    /** Nested child filters. */
    private readonly _nestedFilters;
    /** Parent filter in the tree, if any. */
    private _parent;
    /** Whether this filter may be deleted from the UI. */
    private _allowDelete;
    /** Whether this filter may be renamed from the UI. */
    private _allowRename;
    /** Whether this filter was generated dynamically by AutoCAD. */
    private _dynamicallyGenerated;
    /** Whether this filter is a proxy for an unknown custom filter type. */
    private _isProxy;
    /**
     * Creates a new {@link AcLyLayerFilter} instance (property filter).
     */
    constructor();
    /**
     * Gets the filter name.
     *
     * @returns The filter name.
     */
    get name(): string;
    /**
     * Sets the filter name.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::setName`.
     *
     * @param value - New filter name.
     * @returns `true` if the name was set.
     */
    setName(value: string): boolean;
    /**
     * Sets the filter name via property assignment.
     *
     * @param value - New filter name.
     */
    set name(value: string);
    /**
     * Gets the property-filter expression string.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::filterExpression`. Group filters do
     * not use expression strings and return an empty string.
     *
     * @returns The filter expression, or an empty string.
     */
    get filterExpression(): string;
    /**
     * Sets the property-filter expression string.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::setFilterExpression`.
     *
     * @param expression - Filter expression (for example `LOCKED=="False"`).
     * @returns `true` if the expression was accepted.
     */
    setFilterExpression(expression: string): boolean;
    /**
     * Sets the filter expression via property assignment.
     *
     * @param value - Filter expression string.
     */
    set filterExpression(value: string);
    /**
     * Returns a parsed expression-tree representation of the filter expression.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::filterExpressionTree`. Returns `null`
     * when no expression is set, or for ID/group filters.
     *
     * @returns An {@link AcLyBoolExpr}, or `null`.
     */
    filterExpressionTree(): AcLyBoolExpr | null;
    /**
     * Gets the nested child filters of this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::getNestedFilters`.
     *
     * @returns A read-only array of nested filters.
     */
    getNestedFilters(): readonly AcLyLayerFilter[];
    /**
     * Convenience accessor for nested filters (mirrors .NET `NestedFilters`).
     *
     * @returns A read-only array of nested filters.
     */
    get nestedFilters(): readonly AcLyLayerFilter[];
    /**
     * Gets the parent filter in the tree.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::parent`.
     *
     * @returns The parent filter, or `null` for the root.
     */
    parent(): AcLyLayerFilter | null;
    /**
     * Returns whether this filter is an ID/group filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::isIdFilter`. Property filters return
     * `false`; {@link AcLyLayerGroup} overrides this to return `true`.
     *
     * @returns `true` for group filters; otherwise `false`.
     */
    isIdFilter(): boolean;
    /**
     * Returns whether nested filters are allowed under this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::allowNested`. Both property and group
     * filters allow nesting by default.
     *
     * @returns `true` if nested filters are allowed.
     */
    allowNested(): boolean;
    /**
     * Returns whether this filter may be deleted.
     *
     * @returns `true` if deletion is allowed.
     */
    allowDelete(): boolean;
    /**
     * Sets whether this filter may be deleted.
     *
     * @param value - `true` to allow deletion.
     */
    setAllowDelete(value: boolean): void;
    /**
     * Returns whether this filter may be renamed.
     *
     * @returns `true` if renaming is allowed.
     */
    allowRename(): boolean;
    /**
     * Sets whether this filter may be renamed.
     *
     * @param value - `true` to allow renaming.
     */
    setAllowRename(value: boolean): void;
    /**
     * Returns whether this filter was generated dynamically.
     *
     * @returns `true` if dynamically generated.
     */
    dynamicallyGenerated(): boolean;
    /**
     * Sets whether this filter was generated dynamically.
     *
     * @param value - `true` if dynamically generated.
     */
    setDynamicallyGenerated(value: boolean): void;
    /**
     * Returns whether this filter is a proxy for an unknown custom type.
     *
     * @returns `true` if this is a proxy filter.
     */
    isProxy(): boolean;
    /**
     * Sets whether this filter is a proxy.
     *
     * @param value - `true` if this is a proxy filter.
     */
    setIsProxy(value: boolean): void;
    /**
     * Adds a nested child filter under this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::addNested`.
     *
     * Nesting rules:
     * - This filter must {@link allowNested}.
     * - The tree root may contain both group and property filters.
     * - A non-root property filter may not contain a group filter.
     * - A group filter may contain both group and property filters.
     *
     * @param filter - Child filter to add.
     * @returns `true` if the child was added.
     */
    addNested(filter: AcLyLayerFilter): boolean;
    /**
     * Removes a nested child filter from this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::removeNested`.
     *
     * @param filter - Child filter to remove.
     * @returns `true` if the child was removed.
     */
    removeNested(filter: AcLyLayerFilter): boolean;
    /**
     * Generates nested filters from this filter's expression, when supported.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::generateNested`. Not implemented beyond
     * API parity; returns `false`.
     *
     * @returns `true` if nested filters were generated.
     */
    generateNested(): boolean;
    /**
     * Compares this filter to another filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::compareTo`.
     *
     * @param other - Filter to compare against.
     * @returns `true` if the filters are considered equal.
     */
    compareTo(other: AcLyLayerFilter | null | undefined): boolean;
    /**
     * Tests whether the given layer table record passes this filter.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::filter`. Property filters evaluate
     * {@link filterExpression}; group filters override this method.
     *
     * @param layer - Layer table record to test.
     * @returns `true` if the layer is accepted by this filter.
     */
    filter(layer: AcDbLayerTableRecord): boolean;
    /**
     * Shows the filter editor UI.
     *
     * @remarks
     * Mirrors ObjectARX `AcLyLayerFilter::showEditor`. No UI is available in
     * this port; always returns {@link AcLyLayerFilterDialogResult.Cancel}.
     *
     * @returns Dialog result.
     */
    showEditor(): AcLyLayerFilterDialogResult;
}
/**
 * Type alias used by group filters for layer object IDs.
 */
export type AcLyLayerId = AcDbObjectId;
//# sourceMappingURL=AcLyLayerFilter.d.ts.map