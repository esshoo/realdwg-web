import { AcDbResultBuffer } from '../base/AcDbResultBuffer';
import { AcLyLayerFilter } from './AcLyLayerFilter';
import { AcLyLayerFilterTree } from './AcLyLayerFilterTree';
/**
 * Dictionary name for the legacy (pre-2005) layer-filter store.
 *
 * @remarks
 * Lives in the Layer Table extension dictionary. Typically holds only
 * top-level filter heads; nested filters are stored under
 * {@link ACLY_DICTIONARY_NAME}.
 *
 * @see https://blog.autodesk.io/delete-layer-filters-using-objectarx/
 */
export declare const ACAD_LAYERFILTERS_NAME = "ACAD_LAYERFILTERS";
/**
 * Dictionary name for the modern nested layer-filter store (AutoCAD 2005+).
 *
 * @remarks
 * Lives in the Layer Table extension dictionary. Nested filters are reached
 * through child `ACLYDICTIONARY` dictionaries owned by parent filter
 * XRecords (via each XRecord's extension dictionary).
 *
 * @see https://forums.autodesk.com/t5/vba-forum/lost-in-acad-layerfilters-dictionnary/td-p/1841031
 */
export declare const ACLY_DICTIONARY_NAME = "ACLYDICTIONARY";
/**
 * A DXF/DWG group-code pair used when reading or writing filter XRecords.
 */
export interface AcDbLayerFilterGroup {
    /** DXF group code. */
    code: number;
    /** Group value. */
    value: unknown;
}
/**
 * Minimal dictionary shape used when reconstructing the filter tree.
 */
export interface AcDbPersistDictionary {
    /** Object handle. */
    handle: string;
    /** Owner object handle, when known. */
    ownerObjectId?: string;
    /** Extension dictionary handle, when known. */
    extensionDictionaryId?: string;
    /** Named entries mapping to soft/hard-owned object handles. */
    entries: Record<string, string>;
}
/**
 * Minimal XRecord shape used when reconstructing the filter tree.
 */
export interface AcDbPersistXRecord {
    /** Object handle. */
    handle: string;
    /** Owner object handle, when known. */
    ownerObjectId?: string;
    /** Extension dictionary handle, when known. */
    extensionDictionaryId?: string;
    /** XRecord payload as DXF group pairs. */
    data: AcDbLayerFilterGroup[];
}
/**
 * Lookup tables used to rebuild an {@link AcLyLayerFilterTree} from drawing
 * objects.
 */
export interface AcDbLayerFilterPersistSource {
    /** Dictionaries keyed by handle. */
    dictionaries: Map<string, AcDbPersistDictionary>;
    /** XRecords keyed by handle. */
    xrecords: Map<string, AcDbPersistXRecord>;
}
/**
 * One serialized filter node produced by {@link acdbSerializeLayerFilterTree}.
 */
export interface AcDbSerializedFilterNode {
    /** Dictionary entry key / filter identity. */
    key: string;
    /** Whether this node is a group (ID) filter. */
    isIdFilter: boolean;
    /** XRecord payload groups. */
    data: AcDbLayerFilterGroup[];
    /** Nested child nodes. */
    children: AcDbSerializedFilterNode[];
}
/**
 * Serialized Layer Manager filter tree ready to be written as dictionaries
 * and XRecords under the Layer Table extension dictionary.
 */
export interface AcDbSerializedFilterTree {
    /** Root nested filters (excluding the synthetic `All` root itself). */
    nodes: AcDbSerializedFilterNode[];
}
/**
 * Reads an {@link AcLyLayerFilterTree} from Layer Table extension-dictionary
 * objects (`ACAD_LAYERFILTERS` / `ACLYDICTIONARY` + XRecords).
 *
 * @remarks
 * Prefer {@link ACLY_DICTIONARY_NAME} when present (supports nesting). Fall
 * back to the legacy flat {@link ACAD_LAYERFILTERS_NAME} dictionary.
 *
 * Legacy property-filter XRecord layout (documented VBA samples):
 * `(1 name) (1 expression) (1 colorPat) (1 linetypePat) (70 flags) (1 ...) (1 ...)`
 * Group filters additionally store layer object IDs as soft/hard pointers
 * (group codes 330 / 340 / 350 / 360).
 *
 * @param source - Dictionaries and XRecords from the drawing.
 * @returns The reconstructed filter tree.
 */
export declare function acdbReadLayerFilterTree(source: AcDbLayerFilterPersistSource): AcLyLayerFilterTree;
/**
 * Serializes an {@link AcLyLayerFilterTree} into dictionary/XRecord payloads.
 *
 * @param tree - Filter tree to serialize.
 * @returns Serialized nodes for `ACAD_LAYERFILTERS` / `ACLYDICTIONARY`.
 */
export declare function acdbSerializeLayerFilterTree(tree: AcLyLayerFilterTree): AcDbSerializedFilterTree;
/**
 * Converts typed XRecord groups into an {@link AcDbResultBuffer}.
 *
 * @param groups - DXF group pairs.
 * @returns Result buffer suitable for {@link AcDbXrecord.data}.
 */
export declare function acdbLayerGroupsToResultBuffer(groups: readonly AcDbLayerFilterGroup[]): AcDbResultBuffer;
/**
 * Converts an {@link AcDbResultBuffer} into DXF group pairs.
 *
 * @param buffer - Source result buffer.
 * @returns DXF group pairs.
 */
export declare function acdbResultBufferToLayerGroups(buffer: AcDbResultBuffer | null | undefined): AcDbLayerFilterGroup[];
/**
 * Parsed fields from one filter XRecord payload.
 */
export interface AcDbParsedFilterXRecord {
    name: string;
    filterExpression: string;
    flags: number;
    layerIds: string[];
    isIdFilter: boolean;
}
/**
 * Parses legacy / modern filter XRecord group codes into structured fields.
 *
 * @param data - XRecord groups.
 * @param fallbackName - Name used when group code 1 is missing.
 * @returns Parsed filter fields.
 */
export declare function acdbParseFilterXRecordData(data: readonly AcDbLayerFilterGroup[], fallbackName?: string): AcDbParsedFilterXRecord;
/**
 * Writes filter fields to the legacy-compatible XRecord group layout.
 *
 * @param filter - Filter to write.
 * @returns DXF group pairs.
 */
export declare function acdbWriteFilterXRecordData(filter: AcLyLayerFilter): AcDbLayerFilterGroup[];
//# sourceMappingURL=AcLyLayerFilterIO.d.ts.map