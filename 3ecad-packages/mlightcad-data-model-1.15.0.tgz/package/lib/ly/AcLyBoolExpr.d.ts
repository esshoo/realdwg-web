/**
 * Opaque placeholder for a parsed layer-filter boolean expression tree.
 *
 * @remarks
 * Mirrors ObjectARX `AcLyBoolExpr`. A full expression-AST implementation is
 * not required to support the {@link AcLyLayerFilter} nesting API; property
 * filters currently evaluate {@link AcLyLayerFilter.filterExpression} as a
 * string.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcLy_Classes
 */
export declare class AcLyBoolExpr {
    /** Original filter expression text. */
    private readonly _expression;
    /**
     * Creates a new {@link AcLyBoolExpr} instance.
     *
     * @param expression - Source filter expression string.
     */
    constructor(expression: string);
    /**
     * Gets the original filter expression text.
     *
     * @returns The filter expression string.
     */
    get expression(): string;
}
//# sourceMappingURL=AcLyBoolExpr.d.ts.map