/**
 * Maps a DXF group code to the value type it carries.
 *
 * Constant across DXF versions (AC1009 → AC1032+). Reference: AutoCAD DXF
 * Reference "Group Codes in Numerical Order"; ezdxf `lldxf/types.py`.
 */
export type AcDbDxfValueType = 'string' | 'int' | 'long' | 'double' | 'bool' | 'handle' | 'binary';
export type AcDbDxfValueTypeOrComment = AcDbDxfValueType | 'comment';
export declare function acdbDxfValueType(code: number): AcDbDxfValueTypeOrComment;
/** True iff binary DXF stores this code as int32 (otherwise int16 for `'int'`). */
export declare function acdbDxfIsInt32Code(code: number): boolean;
//# sourceMappingURL=AcDbDxfGroupCodeTypes.d.ts.map