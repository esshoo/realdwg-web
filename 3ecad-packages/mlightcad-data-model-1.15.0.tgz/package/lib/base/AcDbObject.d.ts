import { AcCmAttributes, AcCmObject, AcCmStringKey } from '@mlightcad/common';
import type { AcDbDatabase } from '../database/AcDbDatabase';
import { AcDbDxfFiler } from './AcDbDxfFiler';
import { AcDbResultBuffer } from './AcDbResultBuffer';
/** Type alias for object ID as string */
export type AcDbObjectId = string;
/** Prefix for temporary object IDs that are not yet committed to the database */
export declare const TEMP_OBJECT_ID_PREFIX = "TEMP_";
export declare function acdbSetHostApplicationServicesProvider(provider: () => {
    workingDatabase: AcDbDatabase;
}): void;
/**
 * Assigns the host working database when the services provider is registered.
 *
 * No-op when the provider has not been installed yet (e.g. HostApplicationServices
 * module not loaded). Used by {@link AcDbDatabase.read} so import paths that
 * touch unbound objects still see a current database.
 */
export declare function acdbAssignWorkingDatabase(database: AcDbDatabase): void;
export declare function acdbGetWorkingDatabase(): AcDbDatabase;
/**
 * Interface defining the attributes that can be associated with an AcDbObject.
 *
 * Extends the base AcCmAttributes interface and adds object-specific attributes
 * like objectId and ownerId.
 */
export interface AcDbObjectAttrs extends AcCmAttributes {
    /** Unique identifier for the object */
    objectId?: AcDbObjectId;
    /** Identifier of the object that owns this object */
    ownerId?: AcDbObjectId;
    /**
     * The objectId of the extension dictionary owned by the object. If the object does
     * not own an extension dictionary, then the returned objectId is set to undefined.
     */
    extensionDictionary?: AcDbObjectId;
}
/**
 * The base class for all objects that reside in a drawing database.
 *
 * This class provides the fundamental functionality for all database objects,
 * including attribute management, object identification, and database association.
 * It serves as the foundation for entities, tables, and other database objects.
 *
 * @template ATTRS - The type of attributes this object can have
 *
 * @example
 * ```typescript
 * class MyEntity extends AcDbObject<MyEntityAttrs> {
 *   constructor(attrs?: Partial<MyEntityAttrs>) {
 *     super(attrs);
 *   }
 * }
 * ```
 */
export declare class AcDbObject<ATTRS extends AcDbObjectAttrs = AcDbObjectAttrs> {
    /** Reference to the database this object belongs to */
    private _database?;
    /** The attributes object that stores all object properties */
    private _attrs;
    /** XData attached to this object */
    private _xDataMap?;
    /**
     * Imported DWG XData kept as flat primitive code/value pairs:
     * [1001, appId, code, value, ..., 1001, nextAppId, ...].
     *
     * The traditional Map/ResultBuffer graph is created only for an AppId that
     * is actually accessed or mutated through the public XData API.
     */
    private _importedXData?;
    /**
     * Creates a new AcDbObject instance.
     *
     * @param attrs - Input attribute values for this object
     * @param defaultAttrs - Default values for attributes of this object
     *
     * @example
     * ```typescript
     * const obj = new AcDbObject({ objectId: '123' });
     * ```
     */
    constructor(attrs?: Partial<ATTRS>, defaultAttrs?: Partial<ATTRS>);
    /**
     * Generates a temporary handle when database is not available
     * This is a fallback and will be replaced when the object is added to a database
     * @returns A temporary hexadecimal string
     */
    private generateTemporaryHandle;
    /**
     * Gets the attributes object for this AcDbObject.
     *
     * @returns The AcCmObject instance containing all attributes
     *
     * @example
     * ```typescript
     * const attrs = obj.attrs;
     * const value = attrs.get('someAttribute');
     * ```
     */
    get attrs(): AcCmObject<ATTRS>;
    /**
     * Gets the value of the specified attribute.
     *
     * This method will throw an exception if the specified attribute doesn't exist.
     * Use getAttrWithoutException() if you want to handle missing attributes gracefully.
     *
     * @param attrName - The name of the attribute to retrieve
     * @returns The value of the specified attribute
     * @throws {Error} When the specified attribute doesn't exist
     *
     * @example
     * ```typescript
     * try {
     *   const value = obj.getAttr('objectId');
     * } catch (error) {
     *   console.error('Attribute not found');
     * }
     * ```
     */
    getAttr(attrName: AcCmStringKey<ATTRS>): ATTRS[AcCmStringKey<ATTRS>] & ({} | null);
    /**
     * Gets the value of the specified attribute without throwing an exception.
     *
     * This method returns undefined if the specified attribute doesn't exist,
     * making it safer for optional attributes.
     *
     * @param attrName - The name of the attribute to retrieve
     * @returns The value of the specified attribute, or undefined if it doesn't exist
     *
     * @example
     * ```typescript
     * const value = obj.getAttrWithoutException('optionalAttribute');
     * if (value !== undefined) {
     *   // Use the value
     * }
     * ```
     */
    getAttrWithoutException(attrName: AcCmStringKey<ATTRS>): ATTRS[AcCmStringKey<ATTRS>] | undefined;
    /**
     * Sets the value of an attribute.
     *
     * @param attrName - The name of the attribute to set
     * @param val - The value to assign to the attribute
     *
     * @example
     * ```typescript
     * obj.setAttr('objectId', 'new-id-123');
     * ```
     */
    setAttr<A extends AcCmStringKey<ATTRS>>(attrName: A, val?: ATTRS[A]): void;
    /**
     * Gets the object ID.
     *
     * AutoCAD uses 64-bit integers to represent handles, which exceed the maximum
     * integer value of JavaScript. Therefore, strings are used to represent object handles.
     *
     * @returns The object ID as a string
     *
     * @example
     * ```typescript
     * const id = obj.objectId;
     * console.log(`Object ID: ${id}`);
     * ```
     */
    get objectId(): AcDbObjectId;
    /**
     * Sets the object ID.
     *
     * @param value - The new object ID
     *
     * @example
     * ```typescript
     * obj.objectId = 'new-object-id';
     * ```
     */
    set objectId(value: AcDbObjectId);
    /**
     * Returns true if this object is temporary and not yet committed to the database.
     *
     * A temporary object is identified by its objectId starting with the TEMP prefix.
     */
    get isTemp(): any;
    /**
     * Gets the object ID of the owner of this object.
     *
     * @returns The owner object ID
     *
     * @example
     * ```typescript
     * const ownerId = obj.ownerId;
     * ```
     */
    get ownerId(): AcDbObjectId;
    /**
     * Sets the object ID of the owner of this object.
     *
     * @param value - The new owner object ID
     *
     * @example
     * ```typescript
     * obj.ownerId = 'parent-object-id';
     * ```
     */
    set ownerId(value: AcDbObjectId);
    /**
     * Gets the objectId of the extension dictionary owned by this object.
     *
     * If the object does not have an extension dictionary, this returns `undefined`.
     *
     * In ObjectARX terms, this is equivalent to `AcDbObject::extensionDictionary()`.
     *
     * @returns The extension dictionary objectId, or undefined
     *
     * @example
     * ```typescript
     * const dictId = obj.extensionDictionary
     * if (dictId) {
     *   console.log('Has extension dictionary:', dictId)
     * }
     * ```
     */
    get extensionDictionary(): AcDbObjectId | undefined;
    /**
     * Sets the objectId of the extension dictionary owned by this object.
     *
     * This does not create or delete the dictionary object itself ??it only
     * establishes or clears the ownership relationship.
     *
     * Passing `undefined` removes the association.
     *
     * @param value - The extension dictionary objectId, or undefined
     *
     * @example
     * ```typescript
     * obj.extensionDictionary = dict.objectId
     * ```
     */
    set extensionDictionary(value: AcDbObjectId | undefined);
    /**
     * Gets the database in which this object is resident.
     *
     * When an object isn't added to a database, this property returns the current
     * working database. After it is added to a database, it will be set automatically.
     * You should never set this value manually.
     *
     * @returns The database this object belongs to
     *
     * @example
     * ```typescript
     * const db = obj.database;
     * ```
     */
    get database(): AcDbDatabase;
    /**
     * Sets the database for this object.
     *
     * This is typically set automatically when the object is added to a database.
     * Manual setting should be avoided unless you know what you're doing.
     *
     * @param db - The database to associate with this object
     *
     * @example
     * ```typescript
     * obj.database = myDatabase;
     * ```
     */
    set database(db: AcDbDatabase);
    /**
     * Associates this object with a database. Subclasses may override {@link database}
     * and call this helper to avoid `super` setter restrictions.
     */
    protected assignDatabase(db: AcDbDatabase): void;
    /**
     * Finds one imported compact XData block.
     *
     * @returns [start, end) indices into _importedXData, or undefined.
     */
    private findImportedXDataRange;
    private removeImportedXData;
    private importedXDataValues;
    /**
     * Lossless parser/import fast path.
     *
     * Imported XData stays compact until callers explicitly request that AppId.
     * Existing getXData/setXData/removeXData behavior remains authoritative.
     */
    setImportedXData(values: Iterable<{
        code: number;
        value: string | number;
    }>): void;
    /**
     * Retrieves the XData associated with this object for a given application ID.
     *
     * Extended Entity Data (XData) allows applications to attach arbitrary,
     * application-specific data to an AcDbObject. Each XData entry is identified
     * by a registered application name (AppId) and stored as an AcDbResultBuffer.
     *
     * This method is conceptually equivalent to `AcDbObject::xData()` in ObjectARX,
     * but simplified to return the entire result buffer for the specified AppId.
     *
     * @param appId - The application ID (registered AppId name) that owns the XData
     * @returns The AcDbResultBuffer associated with the AppId, or `undefined`
     *          if no XData exists for that AppId
     *
     * @example
     * ```typescript
     * const xdata = obj.getXData('MY_APP')
     * if (xdata) {
     *   // Read values from the result buffer
     * }
     * ```
     */
    getXData(appId: string): AcDbResultBuffer | undefined;
    /**
     * Attaches or replaces XData for this object.
     *
     * If XData already exists for the given AppId, it is replaced by the provided
     * AcDbResultBuffer. The caller is responsible for ensuring that:
     *
     * - The AppId is registered in the database's AppId table
     * - The result buffer follows valid DXF/XData conventions (e.g. starts with
     *   a 1001 group code for the AppId)
     *
     * This method is conceptually similar to `AcDbObject::setXData()` in ObjectARX.
     *
     * @param resbuf - The result buffer containing the XData to attach
     *
     * @example
     * ```typescript
     * const rb = new AcDbResultBuffer([
     *   { code: AcDbDxfCode.ExtendedDataRegAppName, value: 'MY_APP' },
     *   { code: AcDbDxfCode.ExtendedDataAsciiString, value: 'custom value' }
     * ])
     *
     * obj.setXData('MY_APP', rb)
     * ```
     */
    setXData(resbuf: AcDbResultBuffer): void;
    /**
     * Removes the XData associated with the specified application ID.
     *
     * After removal, calls to getXData() for the same AppId will return `undefined`.
     * If no XData exists for the given AppId, this method has no effect.
     *
     * This mirrors the behavior of clearing XData for a specific application
     * in ObjectARX rather than removing all XData from the object.
     *
     * @param appId - The application ID whose XData should be removed
     *
     * @example
     * ```typescript
     * obj.removeXData('MY_APP')
     * ```
     */
    removeXData(appId: string): void;
    /**
     * Creates the extension dictionary for this object if it does not already exist.
     *
     * This method closely mirrors the behavior of
     * `AcDbObject::createExtensionDictionary()` in ObjectARX.
     *
     * - If the object already owns an extension dictionary, no new dictionary
     *   is created and the existing dictionary's objectId is returned.
     * - Otherwise, a new AcDbDictionary is created, added to the same database,
     *   owned by this object, and its objectId is stored on this object.
     *
     * @returns The objectId of the extension dictionary
     *
     * @example
     * ```typescript
     * const dictId = obj.createExtensionDictionary()
     * ```
     */
    createExtensionDictionary(): AcDbObjectId | undefined;
    /**
     * Closes the object.
     *
     * All changes made to the object since it was opened are committed to the database,
     * and a "closed" notification is sent. This method can be overridden by subclasses
     * to provide specific cleanup behavior.
     *
     * @example
     * ```typescript
     * obj.close();
     * ```
     */
    close(): void;
    /** Own-property keys omitted from clone/restore snapshots (database back-references). */
    private static readonly SNAPSHOT_EXCLUDED_KEYS;
    /** Own-property keys restored through dedicated attribute/xdata helpers instead of generic copy. */
    private static readonly SNAPSHOT_INTERNAL_KEYS;
    /**
     * Returns own string property names that participate in generic snapshot copy.
     *
     * Excludes {@link SNAPSHOT_EXCLUDED_KEYS} so database and transaction-manager
     * references are never duplicated onto clones.
     */
    private getOwnSnapshotKeys;
    /**
     * Deep-clones attribute storage into a new {@link AcCmObject} instance.
     *
     * @param source - Attribute container to copy
     * @returns Detached attribute object with the same values as `source`
     */
    private cloneAttrs;
    /**
     * Replaces this object's attributes from a snapshot, removing keys absent in the source.
     *
     * Updates are applied silently so restore does not trigger attribute observers.
     *
     * @param source - Attribute container captured before modification
     */
    private restoreAttrsFrom;
    /**
     * Replaces extended-data entries from a snapshot map.
     *
     * @param source - Deep-cloned xdata map from a snapshot object
     */
    private restoreXDataMapFrom;
    /**
     * Copies cloneable internal state from this instance onto `target`.
     *
     * Used by {@link clone} and {@link clonePreservingIdentity} to populate a
     * freshly allocated object of the same runtime type.
     *
     * @param target - Newly created instance receiving the copied state
     */
    private copySnapshotStateTo;
    /**
     * Creates a deep clone of this object.
     *
     * The cloned object is a detached in-memory object:
     * - It has a new temporary objectId
     * - It is not attached to any database instance
     */
    clone(): this;
    /**
     * Creates a deep clone that preserves database identity fields.
     *
     * Used for undo/redo snapshots where {@link objectId}, {@link ownerId},
     * and {@link database} must match the live object after restore.
     */
    clonePreservingIdentity(): this;
    /**
     * Restores internal state from a detached clone while preserving identity fields.
     *
     * @param snapshot - Clone produced by {@link clone} or {@link clonePreservingIdentity}.
     */
    restoreFrom(snapshot: this): void;
    /**
     * Deep clones one internal field value while preserving known class types.
     */
    private cloneValue;
    /**
     * Writes the common DXF wrapper for this object and then delegates the
     * object-specific payload to {@link dxfOutFields}.
     *
     * @param filer - DXF output writer.
     * @param allXdata - When true, emits all XData attached to this object.
     * @returns The object instance (for chaining).
     */
    /**
     * Writes this object to the DXF output.
     *
     * @returns The instance (for chaining).
     */
    dxfOut(...args: unknown[]): unknown;
    /** Emit all attached XData buffers (DXF groups 1000–1071). */
    protected dxfOutXData(filer: AcDbDxfFiler): void;
    /**
     * Writes object-specific DXF fields.
     *
     * Subclasses should override this method and call `super.dxfOutFields(filer)`
     * first so the subclass markers remain consistent.
     *
     * @param _filer - DXF output writer.
     * @returns The object instance (for chaining).
     */
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(_filer: AcDbDxfFiler): this;
    /**
     * Reads this object from a DXF filer (ObjectARX `dxfIn`).
     *
     * Reads common handle/owner fields, then delegates to {@link dxfInFields}.
     * XData (group 1001+) is consumed when present after object fields.
     *
     * Group-102 control strings (`{ACAD_XDICTIONARY`, `{ACAD_REACTORS`, …) are
     * consumed here so subclass readers still see handle/owner/subclass markers
     * that follow them. Many real DXF writers emit these blocks on LAYER and
     * entity records; skipping them would leave `name`/`layer` unset.
     */
    dxfIn(filer: AcDbDxfFiler): this;
    /**
     * Consumes a DXF group-102 control-string block that was already opened
     * (the opening `102` value is `startValue`, typically `{ACAD_XDICTIONARY`
     * or `{ACAD_REACTORS`).
     *
     * For `{ACAD_XDICTIONARY`, the first soft-owner handle (360) is stored as
     * {@link extensionDictionary}. Other control strings are skipped until the
     * matching closing `102` / `}`.
     */
    protected dxfInControlString(filer: AcDbDxfFiler, startValue: string): void;
    /**
     * Reads object-specific DXF fields (ObjectARX `dxfInFields`).
     *
     * Subclasses should override, call `super.dxfInFields(filer)` first when
     * appropriate, then consume their subclass marker and fields in an
     * order-independent loop.
     *
     * Per the AutoCAD DXF specification, readers must **ignore undefined group
     * codes** and must not assume field order. Within a subclass loop the
     * correct unknown-code behavior is `break` (skip and continue). Use
     * `pushBackItem` only to hand a group-100 subclass marker (or XData) to
     * another reader — never to abort on an unrecognized optional code.
     */
    dxfInFields(_filer: AcDbDxfFiler): this;
    /** Consume XData pairs starting at group 1001 until end of object. */
    protected dxfInXData(filer: AcDbDxfFiler): void;
}
//# sourceMappingURL=AcDbObject.d.ts.map