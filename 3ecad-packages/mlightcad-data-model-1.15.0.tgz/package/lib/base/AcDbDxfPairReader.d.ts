import { AcDbDwgVersion } from '../database/AcDbDwgVersion';
import type { AcDbDxfPair } from './AcDbDxfPair';
/**
 * Stream of typed DXF group-code/value pairs.
 *
 * Comment pairs (code 999) are filtered — neither `peek` nor `next` returns them.
 * Implementations must not materialize the whole file as a `string[]` of lines.
 */
export interface AcDbDxfPairReader {
    readonly kind: 'ascii' | 'binary';
    next(): AcDbDxfPair | undefined;
    peek(): AcDbDxfPair | undefined;
    position(): {
        line?: number;
        byteOffset: number;
    };
}
export interface AcDbDxfHeaderInfo {
    version: AcDbDwgVersion | null;
    encoding: string | null;
}
export declare function acdbIsBinaryDxf(data: Uint8Array): boolean;
/**
 * Peek `$ACADVER` / `$DWGCODEPAGE` from the HEADER section without decoding
 * the whole file. Uses 64 KiB UTF-8 chunks (same strategy as AcDbDxfParser).
 */
export declare function acdbPeekDxfHeaderInfo(buffer: ArrayBuffer): AcDbDxfHeaderInfo;
/**
 * ASCII pair reader over a decoded DXF string.
 *
 * Scans with a character cursor (no full-file `string[]` of lines).
 */
export declare function acdbMakeAsciiDxfPairReader(text: string): AcDbDxfPairReader;
/**
 * Bytes decoded per `TextDecoder` call in {@link acdbMakeUtf8AsciiDxfPairReader}.
 *
 * Sized as a compromise: large enough that a multi-MB DXF costs hundreds of
 * decode calls rather than one per line, small enough that windows still holding
 * a retained value slice do not pin much memory.
 */
/**
 * ASCII pair reader that decodes UTF-8 bytes one line-aligned window at a time,
 * instead of allocating a full-file decoded string (peak memory ≈ input bytes
 * plus one window).
 *
 * Non-UTF-8 code pages still go through {@link acdbMakeAsciiDxfPairReader}
 * after a full `TextDecoder` pass.
 */
export declare function acdbMakeUtf8AsciiDxfPairReader(bytes: Uint8Array): AcDbDxfPairReader;
/**
 * Binary DXF pair reader. Skips the 22-byte magic prefix.
 *
 * @param legacyR12 - AC1009 uses 1-byte group codes (0xFF escape for >255).
 */
export declare function acdbMakeBinaryDxfPairReader(data: Uint8Array, options?: {
    encoding?: string;
    legacyR12?: boolean;
}): AcDbDxfPairReader;
export interface AcDbCreateDxfPairReaderOptions {
    /**
     * Override text encoding for ASCII DXF.
     *
     * When omitted, the encoding is chosen automatically: bytes that validate
     * as UTF-8 decode as UTF-8; otherwise a declared pre-2007 `$DWGCODEPAGE`
     * is honored (see {@link acdbCreateDxfPairReader}). When provided, it wins
     * over detection — use it to force e.g. `'cp949'` for Korean drawings whose
     * header lies. Common non-WHATWG aliases such as `'cp949'` are normalized
     * to a supported `TextDecoder` label (`'euc-kr'`).
     */
    encoding?: string;
    /** Force R12 1-byte group codes for binary DXF. */
    legacyR12?: boolean;
}
/**
 * Create a pair reader from DXF bytes (ASCII or binary).
 *
 * ASCII path encoding strategy (hybrid of byte-trust and header sniffing):
 *
 * 1. An explicit `options.encoding` always wins — the caller asserts the
 *    encoding, no sniffing contradicts it.
 * 2. Otherwise the bytes are strictly validated as UTF-8. Valid UTF-8
 *    (including pure ASCII) decodes correctly regardless of any stale
 *    `$DWGCODEPAGE`, so the header is never consulted — modern files skip
 *    the header pre-scan entirely and stream straight from bytes.
 * 3. Invalid UTF-8 means the file is not a spec-conformant modern DXF. The
 *    HEADER is then peeked for `$ACADVER`/`$DWGCODEPAGE`: pre-2007 drawings
 *    with a declared code page decode through it (matching AutoCAD), while
 *    R2007+ or headerless files fall back to UTF-8 (replacement chars mark
 *    the broken bytes).
 */
export declare function acdbCreateDxfPairReader(data: ArrayBuffer | Uint8Array, options?: AcDbCreateDxfPairReaderOptions): AcDbDxfPairReader;
//# sourceMappingURL=AcDbDxfPairReader.d.ts.map