/**
 * AutoCAD DXF string / binary chunk limits from the DXF Reference.
 *
 * - MTEXT (and embedded MTEXT in multiline ATTRIB/ATTDEF): content longer than
 *   250 **characters** is split into group-3 chunks of 250, with the remainder
 *   in a final group 1.
 * - XData group 1000: each ASCII string is at most 255 **bytes** (plus NUL).
 * - XData group 1004: each binary chunk is at most 127 **bytes**.
 *
 * Ordinary TEXT / ATTRIB default value / DIMENSION text / TOLERANCE (FCF) do
 * **not** use group-3 continuation — in those entities group 3 already means
 * something else (prompt, dimstyle name, etc.). R2000+ allows longer single
 * group-1 strings (up to 2049 bytes) for those cases.
 */
/** MTEXT content chunk size in characters (AutoCAD DXF Reference). */
export declare const ACDB_DXF_MTEXT_CHUNK_CHARS = 250;
/** XData group-1000 ASCII string max bytes per tag. */
export declare const ACDB_DXF_XDATA_STRING_MAX_BYTES = 255;
/** XData group-1004 binary chunk max bytes. */
export declare const ACDB_DXF_XDATA_BINARY_MAX_BYTES = 127;
export type AcDbDxfMTextContentChunk = {
    code: 1 | 3;
    value: string;
};
/**
 * Split MTEXT (or embedded-MTEXT) contents into DXF group 3 / group 1 pairs.
 *
 * Spec order: full 250-char group-3 chunks first, then a final group 1 with the
 * remainder (or the whole string when length ≤ 250).
 */
export declare function acdbChunkDxfMTextContents(text: string): AcDbDxfMTextContentChunk[];
/**
 * Split a Unicode string into pieces whose UTF-8 byte length is ≤ `maxBytes`.
 * Used for XData group 1000 (255-byte limit).
 */
export declare function acdbChunkUtf8ByMaxBytes(text: string, maxBytes: number): string[];
/**
 * Split binary payload into ≤ `maxBytes` chunks (XData group 1004 / DXF 310).
 */
export declare function acdbChunkBinaryByMaxBytes(bytes: Uint8Array, maxBytes: number): Uint8Array[];
//# sourceMappingURL=AcDbDxfStringChunks.d.ts.map