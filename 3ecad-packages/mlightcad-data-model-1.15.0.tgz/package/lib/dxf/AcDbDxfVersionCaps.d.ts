import { AcDbDwgVersion, type AcDbDxfVersionCapabilities } from '../database/AcDbDwgVersion';
export type { AcDbDxfVersionCapabilities };
/**
 * Resolve DXF dialect capabilities for a version name, numeric value,
 * {@link AcDbDwgVersion}, or capabilities object.
 */
export declare function acdbDxfVersionCaps(version?: AcDbDwgVersion | AcDbDxfVersionCapabilities | string | number | null): AcDbDxfVersionCapabilities;
//# sourceMappingURL=AcDbDxfVersionCaps.d.ts.map