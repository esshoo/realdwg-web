import type { AcDbDatabase } from '../database/AcDbDatabase';
import { AcDbDatabaseConverter, type AcDbDatabaseConverterConfig, type AcDbDatabaseConverterReadOptions } from '../database/AcDbDatabaseConverter';
/**
 * Native DXF → database converter.
 *
 * Streams DXF pairs through {@link AcDbDxfFiler} / {@link AcDbDxfDocumentReader}
 * directly into {@link AcDbDatabase}, avoiding the ParsedDxf JSON intermediate
 * used by `@mlightcad/dxf-json-converter`.
 *
 * Conversion stages: `START → PARSE → ENTITY → END`. The reader fills the
 * database quietly (entity-appended events batched); then the batch flushes so
 * the first draw happens after parse completes. Fonts are loaded on demand by
 * the mtext renderer when a font is first needed.
 *
 * Mid-PARSE byte progress, chunked ENTITY flush, and time-budgeted UI yields
 * keep the status bar / spinner responsive without stalling large files on
 * per-chunk `requestAnimationFrame` waits.
 */
export declare class AcDbNativeDxfConverter extends AcDbDatabaseConverter<null> {
    constructor(config?: AcDbDatabaseConverterConfig);
    read(data: ArrayBuffer, db: AcDbDatabase, options?: AcDbDatabaseConverterReadOptions): Promise<void>;
    protected parse(_data: ArrayBuffer): Promise<{
        model: null;
        data: {
            unknownEntityCount: number;
        };
    }>;
}
//# sourceMappingURL=AcDbNativeDxfConverter.d.ts.map