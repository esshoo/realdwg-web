import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbEntity } from '../entity/AcDbEntity';
/**
 * Creates an empty entity instance for the given DXF type name, ready for dxfIn.
 * Returns null for unsupported types (caller should skip to next code 0).
 */
export declare function acdbCreateEntityForDxfIn(typeName: string): AcDbEntity | null;
/**
 * Create entity from the current filer position.
 * Expects the filer to be at (or just past) the type name pair (0, TYPENAME).
 * When `typeName` is omitted, reads the next (0, name) pair.
 */
export declare function acdbDxfInEntity(filer: AcDbDxfFiler, typeName?: string): AcDbEntity | null;
//# sourceMappingURL=AcDbDxfEntityFactory.d.ts.map