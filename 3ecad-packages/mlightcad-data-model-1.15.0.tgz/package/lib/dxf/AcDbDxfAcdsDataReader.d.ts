import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
/** Parsed ACDSDATA section (R2013+ binary ASM payloads linked to entities). */
export interface AcDbAcdsDataSection {
    /** ASM_Data payloads keyed by owner entity handle (uppercase, trimmed). */
    byOwnerHandle: Record<string, Uint8Array>;
}
/** Normalizes a DXF handle for cross-section lookups (uppercase, trimmed). */
export declare function acdbNormalizeDxfHandle(handle: string): string;
/**
 * Looks up an ASM_Data payload by owner handle with normalized matching.
 *
 * @param section - Parsed ACDSDATA section.
 * @param ownerHandle - Owning entity handle (group 5 / ACDS group 320).
 */
export declare function acdbGetAcdsDataByOwnerHandle(section: AcDbAcdsDataSection, ownerHandle: string): Uint8Array | undefined;
/**
 * Parses the DXF `ACDSDATA` section and indexes `ASM_Data` binary payloads by
 * the owning entity handle (group 320).
 *
 * Caller must have already consumed the `(0, SECTION)` / `(2, ACDSDATA)` header.
 *
 * @param filer - DXF reader positioned at the first pair inside ACDSDATA.
 */
export declare function acdbDxfInAcdsData(filer: AcDbDxfFiler): AcDbAcdsDataSection;
//# sourceMappingURL=AcDbDxfAcdsDataReader.d.ts.map