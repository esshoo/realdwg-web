import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbDatabase } from '../database/AcDbDatabase';
/**
 * Stream HEADER section variables into {@link AcDbDatabase}.
 * Expects the filer to be positioned after `(0,SECTION)/(2,HEADER)`.
 * Stops at `(0,ENDSEC)` without consuming pairs belonging to the next section.
 */
export declare function acdbDxfInHeader(filer: AcDbDxfFiler, db: AcDbDatabase): void;
//# sourceMappingURL=AcDbDxfHeaderReader.d.ts.map