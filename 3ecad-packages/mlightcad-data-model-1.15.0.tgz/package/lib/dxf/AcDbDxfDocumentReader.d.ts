import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbDatabase } from '../database/AcDbDatabase';
export interface AcDbDxfDocumentReaderOptions {
    /**
     * How often to check parse progress / UI yield while streaming entities
     * (entity count). Actual yields are time-budgeted via {@link yieldBudgetMs}.
     */
    entityBatchSize?: number;
    /**
     * Minimum wall time between cooperative UI yields during parse.
     * Defaults to {@link ACCM_DEFAULT_UI_YIELD_BUDGET_MS}.
     */
    yieldBudgetMs?: number;
    /**
     * Called with approximate parse completion in `[0, 1]` based on byte
     * offset. Used by the native converter to emit mid-PARSE progress.
     */
    onProgress?: (ratio: number) => void | Promise<void>;
    /** Total DXF byte length for {@link onProgress}. */
    totalBytes?: number;
}
export interface AcDbDxfDocumentReaderResult {
    unknownEntityCount: number;
    /** OBJECTS-section types that were skipped (no native reader yet). */
    unknownObjectCount: number;
}
/**
 * Single-pass streaming DXF document reader.
 *
 * Walks HEADER → CLASSES → TABLES → BLOCKS → ENTITIES → OBJECTS in file
 * order and writes directly into {@link AcDbDatabase}. Does not buffer the
 * whole file as tag groups.
 */
export declare class AcDbDxfDocumentReader {
    private readonly _db;
    private readonly _options;
    private _unknownEntityCount;
    private _unknownObjectCount;
    /** ATTRIB entities waiting for their owning INSERT (keyed by INSERT objectId). */
    private readonly _attributeMap;
    private readonly _yieldGate;
    constructor(_db: AcDbDatabase, _options?: AcDbDxfDocumentReaderOptions);
    get unknownEntityCount(): number;
    get unknownObjectCount(): number;
    read(filer: AcDbDxfFiler): Promise<AcDbDxfDocumentReaderResult>;
    private readSectionName;
    private readSection;
    /**
     * Attaches ACDSDATA `ASM_Data` SAB payloads to matching {@link AcDb3dSolid}
     * entities (keyed by entity handle / group 5).
     *
     * Modern DXF files often store 3DSOLID geometry only in ACDSDATA rather than
     * inline encrypted SAT groups 1/3 — without this step solids render empty.
     */
    private applyAcdsDataToSolids;
    private readThumbnailImageSection;
    private readClassesSection;
    private readClassRecord;
    private readTablesSection;
    private readTableName;
    private readTable;
    private readNamedTable;
    private readBlockRecordTable;
    private skipUntilEndTab;
    private readBlocksSection;
    /**
     * Reads one BLOCK … ENDBLK definition: sync BTR metadata, then stream entities.
     * @returns Updated sinceYield counter for batching.
     */
    private readBlockDefinition;
    /**
     * Block definitions may own entities; *Model_Space / *Paper_Space contents
     * are streamed from the ENTITIES section in modern DXF.
     */
    private shouldAcceptBlockEntity;
    /** Consume a SEQEND object after its `(0, SEQEND)` pair was already read. */
    private consumeSeqend;
    private readBlockBeginFields;
    private ensureBlockTableRecord;
    private readEntitiesSection;
    /**
     * Chooses model vs paper space BTR for an ENTITIES-section entity.
     * Prefers ownerId (330) when it names a space BTR; falls back to DXF group 67.
     */
    private resolveEntityOwner;
    /**
     * Appends an entity (or links ATTRIB → INSERT).
     */
    private acceptEntity;
    private linkOrDeferAttribute;
    private flushRemainingAttributes;
    private skipUntilEndSec;
    private reportParseProgress;
    private yieldAndReportProgress;
}
//# sourceMappingURL=AcDbDxfDocumentReader.d.ts.map