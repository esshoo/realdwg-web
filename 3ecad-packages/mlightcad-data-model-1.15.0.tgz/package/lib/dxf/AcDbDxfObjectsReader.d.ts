import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbDatabase } from '../database/AcDbDatabase';
/**
 * Streams the DXF OBJECTS section into {@link AcDbDatabase} dictionaries.
 *
 * Known object types are written immediately. DICTIONARY / XRECORD payloads
 * are also buffered as lightweight persist maps for the Layer Manager filter
 * tree, then discarded after {@link acdbReadLayerFilterTree}.
 */
export declare class AcDbDxfObjectsReader {
    private readonly _db;
    private readonly _dictionaries;
    private readonly _xrecords;
    private _unknownObjectCount;
    constructor(_db: AcDbDatabase);
    /** Count of OBJECTS types skipped because no native reader exists yet. */
    get unknownObjectCount(): number;
    /**
     * Reads OBJECTS until ENDSEC. Caller must have already consumed the
     * `(0, SECTION)` / `(2, OBJECTS)` header pairs.
     */
    read(filer: AcDbDxfFiler): void;
    private readObject;
    /**
     * Wire the root named-object dictionary and known child dictionaries
     * (ACAD_LAYOUT / ACAD_GROUP / …) from buffered DICTIONARY persist maps.
     */
    private finishNamedObjectDictionaries;
    private collectLoadedObjectsByHandle;
    private readPersistDictionary;
    private finishLayerFilterTree;
    /**
     * Cross-links LAYOUT objects with BLOCK_RECORD layoutId / blockTableRecordId,
     * matching {@link AcDbObjectConverter.convertLayout} resolution rules.
     */
    private linkLayoutsToBlockTableRecords;
}
//# sourceMappingURL=AcDbDxfObjectsReader.d.ts.map