import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbEntity } from '../entity/AcDbEntity';
/**
 * Reads a POLYLINE header + following VERTEX entities until SEQEND and builds
 * the matching AcDb 2d/3d/mesh/polyface polyline (parity with
 * `AcDbEntityConverter.convertPolyline`).
 *
 * Expects the filer positioned just after the `(0, POLYLINE)` pair.
 */
export declare function acdbDxfInPolyline(filer: AcDbDxfFiler): AcDbEntity | null;
//# sourceMappingURL=AcDbDxfPolylineAssembler.d.ts.map