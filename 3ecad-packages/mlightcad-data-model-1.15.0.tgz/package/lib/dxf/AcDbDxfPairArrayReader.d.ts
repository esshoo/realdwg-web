import type { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbDxfPair } from '../base/AcDbDxfPair';
import type { AcDbDxfPairReader } from '../base/AcDbDxfPairReader';
import type { AcDbTypedValue } from '../base/AcDbTypedValue';
/**
 * In-memory pair reader used to replay one object's tags (e.g. DIMENSION
 * subclass selection) without buffering the whole DXF file.
 */
export declare class AcDbDxfPairArrayReader implements AcDbDxfPairReader {
    private readonly _pairs;
    readonly kind: 'ascii' | 'binary';
    private _index;
    constructor(_pairs: readonly AcDbDxfPair[]);
    next(): AcDbDxfPair | undefined;
    peek(): AcDbDxfPair | undefined;
    position(): {
        byteOffset: number;
    };
}
/** Build a typed {@link AcDbDxfPair} from a filer item. */
export declare function acdbTypedValueToDxfPair(item: AcDbTypedValue): AcDbDxfPair;
/**
 * Drain pairs from the current object (until code 0), excluding XData so
 * {@link AcDbObject.dxfIn} can still consume it afterward.
 */
export declare function acdbDrainDxfObjectPairs(filer: AcDbDxfFiler): AcDbDxfPair[];
//# sourceMappingURL=AcDbDxfPairArrayReader.d.ts.map