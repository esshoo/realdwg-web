import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import type { AcDbDatabase } from '../../database/AcDbDatabase';
/**
 * Maximum number of bytes written to each DXF group code **310** chunk when
 * exporting proxy graphics.
 *
 * AutoCAD splits large binary payloads into 127-byte hexadecimal records.
 */
export declare const ACDB_PROXY_GRAPHIC_CHUNK_SIZE = 127;
/**
 * Proxy-graphic command type codes defined by ODA and used by ezdxf.
 *
 * Each record in a proxy-graphic stream begins with an 8-byte header
 * `(size, type)` followed by a type-specific payload. Attribute commands affect
 * subsequent geometry; matrix commands push and pop a transform stack.
 */
export declare enum AcDbProxyGraphicType {
    /** Axis-aligned bounding box extents (type code 1). */
    Extents = 1,
    /** Circle defined by center, radius, and normal (type code 2). */
    Circle = 2,
    /** Circle defined by three points (type code 3). */
    Circle3P = 3,
    /** Circular arc defined by center, radius, normal, start vector, and sweep (type code 4). */
    CircularArc = 4,
    /** Circular arc defined by three points (type code 5). */
    CircularArc3P = 5,
    /** Open polyline or single-point entity (type code 6). */
    Polyline = 6,
    /** Closed polygon, optionally filled (type code 7). */
    Polygon = 7,
    /** Triangle mesh (type code 8). Not currently rendered. */
    Mesh = 8,
    /** Faceted shell rendered as edge segments (type code 9). */
    Shell = 9,
    /** Single-byte text primitive (type code 10). */
    Text = 10,
    /** Extended single-byte text primitive (type code 11). */
    Text2 = 11,
    /** Construction line through two points (type code 12). */
    Xline = 12,
    /** Ray from a base point through a second point (type code 13). */
    Ray = 13,
    /** Sets the ACI color index for subsequent geometry (type code 14). */
    AttributeColor = 14,
    /** Sets the layer by table index for subsequent geometry (type code 16). */
    AttributeLayer = 16,
    /** Sets the linetype by table index for subsequent geometry (type code 18). */
    AttributeLinetype = 18,
    /** Marker attribute reserved by the format (type code 19). */
    AttributeMarker = 19,
    /** Enables or disables solid fill for the next polygon (type code 20). */
    AttributeFill = 20,
    /** Sets true-color or special color encoding (type code 22). */
    AttributeTrueColor = 22,
    /** Sets lineweight for subsequent geometry (type code 23). */
    AttributeLineweight = 23,
    /** Sets linetype scale for subsequent geometry (type code 24). */
    AttributeLtscale = 24,
    /** Sets thickness for subsequent geometry (type code 25). */
    AttributeThickness = 25,
    /** Pushes a 4×4 transform matrix onto the matrix stack (type code 29). */
    PushMatrix = 29,
    /** Pops the top transform matrix off the matrix stack (type code 31). */
    PopMatrix = 31,
    /** Polyline with an appended normal vector (type code 32). */
    PolylineWithNormals = 32,
    /** Lightweight polyline encoded with DWG bit fields (type code 33). */
    LwPolyline = 33,
    /** Unicode text primitive (type code 36). */
    UnicodeText = 36,
    /** Extended Unicode text primitive (type code 38). */
    UnicodeText2 = 38,
    /** Elliptical arc primitive (type code 44). */
    EllipticArc = 44
}
/**
 * Options that configure proxy-graphic decoding and rendering context.
 */
interface AcDbProxyGraphicOptions {
    /**
     * Database used to resolve layer and linetype indices and to obtain point
     * display settings (`pdmode`, `pdsize`).
     */
    database?: AcDbDatabase;
    /**
     * Drawing version string that selects version-specific field layouts.
     *
     * Example: `'AC1015'`, `'AC1024'`.
     */
    dxfversion?: string;
    /**
     * Character encoding for embedded single-byte text commands.
     *
     * When omitted, `'windows-1252'` is used for versions before `'AC1024'`,
     * otherwise `'utf-8'`.
     */
    encoding?: string;
    /** Default layer name applied before any {@link AcDbProxyGraphicType.AttributeLayer} command. */
    defaultLayer?: string;
}
/**
 * Decodes AutoCAD proxy-entity graphics binary data and renders primitives
 * through {@link AcGiRenderer}.
 *
 * A proxy-graphic buffer is a sequence of length-prefixed chunks. Each chunk
 * begins with a little-endian header `(size, type)` where `size` includes the
 * 8-byte header itself. Geometry commands emit drawable entities; attribute
 * commands update a lightweight graphics-state machine (color, layer, linetype,
 * fill, and so on).
 *
 * The implementation follows the ODA proxy-graphic format used by ezdxf's
 * `ProxyGraphic` module.
 *
 * @see {@link AcDbProxyEntity.subWorldDraw}
 */
export declare class AcDbProxyGraphic {
    /** Full proxy-graphic byte stream including the 8-byte stream prefix. */
    private readonly _buffer;
    /** Index of the first chunk header. Skips the 8-byte stream prefix. */
    private _index;
    /** Optional drawing database used for symbol-table lookups. */
    private readonly _database?;
    /** Drawing version string passed to bit-stream readers. */
    private readonly _dxfversion;
    /** Text encoding used for single-byte text commands. */
    private _encoding;
    /** Current ACI color index for subsequent geometry. `256` means ByLayer. */
    private _colorIndex;
    /** Current 24-bit RGB color when set by a true-color attribute. */
    private _rgbColor?;
    /** Current layer name for subsequent geometry. */
    private _layer;
    /** Current linetype name for subsequent geometry. */
    private _linetype;
    /** Current lineweight for subsequent geometry. */
    private _lineweight;
    /** Current linetype scale for subsequent geometry. */
    private _ltscale;
    /** Current thickness for subsequent geometry. */
    private _thickness;
    /** When `true`, the next {@link AcDbProxyGraphicType.Polygon} is filled. */
    private _fill;
    /** Layer names indexed by {@link AcDbProxyGraphicType.AttributeLayer} values. */
    private readonly _layers;
    /** Linetype names indexed by {@link AcDbProxyGraphicType.AttributeLinetype} values. */
    private readonly _linetypes;
    /** Active transform stack applied to decoded points and vectors. */
    private readonly _matrices;
    /** Most recently parsed extents corners, when an EXTENTS chunk was seen. */
    private _extents?;
    /**
     * Creates a proxy-graphic parser over the given byte stream.
     *
     * When a {@link AcDbDatabase} is supplied, layer and linetype tables are
     * cached so attribute commands can resolve table indices to names.
     *
     * @param data - Raw proxy-graphic bytes from a proxy entity.
     * @param options - Optional decoding and rendering context.
     */
    constructor(data: Uint8Array, options?: AcDbProxyGraphicOptions);
    /**
     * Gets the most recently parsed extents corners.
     *
     * @returns Minimum and maximum corners from the last EXTENTS chunk, or
     *   `undefined` when no extents chunk has been read.
     */
    get extents(): AcGePoint3d[] | undefined;
    /**
     * Scans the buffer for an {@link AcDbProxyGraphicType.Extents} chunk without
     * rendering geometry.
     *
     * @returns The minimum and maximum corners when an EXTENTS chunk is found,
     *   otherwise `undefined`.
     */
    scanExtents(): [AcGePoint3d, AcGePoint3d] | undefined;
    /**
     * Parses the full proxy-graphic stream and renders drawable primitives.
     *
     * Renderer sub-entity traits are saved before parsing and restored afterward
     * so attribute commands do not leak state to the caller.
     *
     * @param renderer - Target graphics renderer.
     * @returns A grouped {@link AcGiEntity} when at least one primitive was
     *   emitted, otherwise `undefined`.
     */
    worldDraw(renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Dispatches a single proxy-graphic chunk to the appropriate handler.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param type - Chunk type code from {@link AcDbProxyGraphicType}.
     * @param data - Chunk payload bytes excluding the 8-byte header.
     */
    private dispatchChunk;
    /**
     * Applies the current proxy-graphic graphics state to renderer traits.
     *
     * @param renderer - Target graphics renderer whose {@link AcGiRenderer.subEntityTraits}
     *   are updated in place.
     */
    private applyTraits;
    /**
     * Maps the current linetype name to a renderer style-type enum value.
     *
     * @returns `'ByLayer'`, `'ByBlock'`, or `'UserSpecified'`.
     */
    private resolveLineStyleType;
    /**
     * Applies the active matrix stack to a point.
     *
     * @param point - Source point in proxy-graphic coordinates.
     * @returns The transformed {@link AcGePoint3d}.
     */
    private transformPoint;
    /**
     * Applies the active matrix stack to a direction vector and normalizes it.
     *
     * @param vector - Source vector in proxy-graphic coordinates.
     * @returns The transformed unit vector.
     */
    private transformVector;
    /**
     * Appends a drawable entity to the output list when defined.
     *
     * @param entities - Accumulator for emitted drawable entities.
     * @param entity - Entity returned by the renderer, if any.
     */
    private pushEntity;
    /**
     * Parses an {@link AcDbProxyGraphicType.Extents} chunk.
     *
     * @param data - Chunk payload containing minimum and maximum vertices.
     */
    private readExtents;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeColor} chunk.
     *
     * @param data - Chunk payload containing a 32-bit ACI color index.
     */
    private readAttributeColor;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeLayer} chunk.
     *
     * @param data - Chunk payload containing a layer-table index.
     */
    private readAttributeLayer;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeLinetype} chunk.
     *
     * @param data - Chunk payload containing a linetype-table index.
     */
    private readAttributeLinetype;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeFill} chunk.
     *
     * @param data - Chunk payload where any non-zero value enables fill.
     */
    private readAttributeFill;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeTrueColor} chunk.
     *
     * @param data - Chunk payload containing a packed true-color dword.
     */
    private readAttributeTrueColor;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeLineweight} chunk.
     *
     * @param data - Chunk payload containing a raw lineweight value.
     */
    private readAttributeLineweight;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeLtscale} chunk.
     *
     * @param data - Chunk payload containing a little-endian double.
     */
    private readAttributeLtscale;
    /**
     * Parses an {@link AcDbProxyGraphicType.AttributeThickness} chunk.
     *
     * @param data - Chunk payload containing a little-endian double.
     */
    private readAttributeThickness;
    /**
     * Parses a {@link AcDbProxyGraphicType.PushMatrix} chunk and pushes the
     * decoded matrix onto the transform stack.
     *
     * @param data - Chunk payload containing 16 little-endian doubles.
     */
    private pushMatrix;
    /**
     * Pops the top matrix from the transform stack when the stack is non-empty.
     */
    private popMatrix;
    /**
     * Reads a vertex list from a polyline-style chunk.
     *
     * @param data - Chunk payload beginning with a vertex count.
     * @param loadNormal - When `true`, the final vertex is interpreted as a normal vector.
     * @returns Decoded vertices and the extracted normal (defaults to Z axis).
     */
    private loadVertices;
    /**
     * Renders an {@link AcDbProxyGraphicType.Circle} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     */
    private drawCircle;
    /**
     * Renders an {@link AcDbProxyGraphicType.Circle3P} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload containing three perimeter points.
     */
    private drawCircle3P;
    /**
     * Renders an {@link AcDbProxyGraphicType.CircularArc} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     */
    private drawCircularArc;
    /**
     * Renders an {@link AcDbProxyGraphicType.CircularArc3P} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload containing start, middle, and end points.
     */
    private drawCircularArc3P;
    /**
     * Renders an {@link AcDbProxyGraphicType.EllipticArc} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     */
    private drawEllipticArc;
    /**
     * Renders an {@link AcDbProxyGraphicType.Polyline} or
     * {@link AcDbProxyGraphicType.PolylineWithNormals} chunk.
     *
     * A single vertex is rendered as a point entity using database `pdmode` and
     * `pdsize` settings when available.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     * @param _loadNormal - When `true`, the final vertex stores the polyline normal.
     */
    private drawPolyline;
    /**
     * Renders an {@link AcDbProxyGraphicType.Polygon} chunk.
     *
     * When {@link AcDbProxyGraphicType.AttributeFill} was set for this polygon, a
     * solid filled area is emitted; otherwise the polygon outline is drawn as a
     * closed polyline.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     */
    private drawPolygon;
    /**
     * Renders an {@link AcDbProxyGraphicType.LwPolyline} chunk.
     *
     * Bulge values are consumed but arc segments are not yet expanded; the result
     * is a vertex polyline in the current transform stack.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Bit-packed chunk payload.
     */
    private drawLwPolyline;
    /**
     * Renders an {@link AcDbProxyGraphicType.Shell} chunk as face edge segments.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload containing vertices and face index lists.
     */
    private drawShell;
    /**
     * Renders an {@link AcDbProxyGraphicType.Text} or
     * {@link AcDbProxyGraphicType.UnicodeText} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload.
     * @param unicode - When `true`, text is decoded as UTF-16LE.
     */
    private drawText;
    /**
     * Renders an {@link AcDbProxyGraphicType.Text2} or
     * {@link AcDbProxyGraphicType.UnicodeText2} chunk.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload with extended text header fields.
     * @param unicode - When `true`, text is decoded as UTF-16LE.
     */
    private drawText2;
    /**
     * Emits a proxy-graphic text command as an {@link AcGiRenderer.mtext} entity.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param options - Parsed text placement and formatting values.
     */
    private drawTextPrimitive;
    /**
     * Renders an {@link AcDbProxyGraphicType.Xline} or
     * {@link AcDbProxyGraphicType.Ray} chunk as a long screen-space segment.
     *
     * @param renderer - Target graphics renderer.
     * @param entities - Accumulator for emitted drawable entities.
     * @param data - Chunk payload containing two defining points.
     * @param isRay - When `true`, the line starts at the first point; otherwise it
     *   extends infinitely in both directions.
     */
    private drawXline;
}
/**
 * Loads proxy-graphic bytes from DXF group codes **160** and **310**.
 *
 * Chunks are concatenated in order (hex strings and/or `Uint8Array`) and
 * optionally truncated to the declared byte length from group code **160**.
 *
 * @param length - Expected byte length from group code **160**.
 * @param chunks - One or more hexadecimal strings or binary chunks from
 *   group code **310**.
 * @returns Decoded bytes, or `undefined` when no chunks are supplied.
 */
export declare function acdbLoadProxyGraphicFromDxf(length?: number, chunks?: Array<string | Uint8Array>): Uint8Array | undefined;
export {};
//# sourceMappingURL=AcDbProxyGraphic.d.ts.map