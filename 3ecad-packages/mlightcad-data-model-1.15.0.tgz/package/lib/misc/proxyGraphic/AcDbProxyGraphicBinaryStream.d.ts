/**
 * Little-endian binary readers for AutoCAD proxy-entity graphics.
 *
 * Proxy-entity graphics combine aligned byte records and DWG-style bit-packed
 * fields. These stream helpers decode both representations and are based on the
 * format documented by ODA and implemented in ezdxf's `ProxyGraphic`.
 */
/**
 * Error thrown when a proxy-graphic reader reaches the end of its buffer
 * unexpectedly or cannot locate a required terminator.
 */
export declare class AcDbProxyGraphicEndOfBufferError extends Error {
    /**
     * Creates a new end-of-buffer error.
     *
     * @param message - Human-readable error description.
     */
    constructor(message?: string);
}
/** Supported input buffer types for proxy-graphic stream readers. */
type Bytes = Uint8Array | ArrayBuffer;
/**
 * Sequential little-endian byte reader for aligned proxy-graphic records.
 *
 * Reads fixed-size numeric fields and null-terminated strings from a chunk
 * payload. After each multi-byte read the cursor is advanced to the next
 * 4-byte-aligned offset, matching the ODA proxy-graphic layout.
 */
export declare class AcDbProxyGraphicByteStream {
    /** Backing byte buffer. */
    private readonly _buffer;
    /** Current read cursor in bytes. */
    private _index;
    /** Alignment boundary applied after each struct read. */
    private readonly _align;
    /**
     * Creates a byte stream over the given buffer.
     *
     * @param buffer - Chunk payload bytes.
     * @param align - Alignment size in bytes. Defaults to `4`.
     */
    constructor(buffer: Bytes, align?: number);
    /**
     * Gets the current read cursor in bytes.
     */
    get index(): number;
    /**
     * Indicates whether unread bytes remain in the buffer.
     */
    get hasData(): boolean;
    /**
     * Rounds a byte index up to the configured alignment boundary.
     *
     * @param index - Raw byte index.
     * @returns The aligned index.
     */
    private alignIndex;
    /**
     * Reads a composite struct of little-endian numeric fields.
     *
     * Supported field sizes are `4` (uint32) and `8` (float64).
     *
     * @typeParam T - Tuple type describing the returned numeric array.
     * @param sizes - Byte width of each field in order.
     * @returns The decoded numeric values.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When the buffer ends
     *   before the struct can be read.
     * @throws {Error} When an unsupported field size is requested.
     */
    readStruct<T extends number[]>(sizes: number[]): T;
    /**
     * Reads one little-endian 64-bit floating-point value.
     *
     * @returns The decoded double.
     */
    readFloat(): number;
    /**
     * Reads one little-endian 32-bit unsigned integer.
     *
     * @returns The decoded unsigned long.
     */
    readLong(): number;
    /**
     * Reads one little-endian 32-bit signed integer.
     *
     * @returns The decoded signed long.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When the buffer ends
     *   before four bytes are available.
     */
    readSignedLong(): number;
    /**
     * Reads one 3D vertex as three little-endian doubles `(x, y, z)`.
     *
     * @returns The decoded vertex tuple in WCS order.
     */
    readVertex(): [number, number, number];
    /**
     * Reads a null-terminated single-byte string and advances to the next
     * aligned offset.
     *
     * @param encoding - TextDecoder label for the string bytes. Defaults to
     *   `'utf-8'`.
     * @returns The decoded string without the terminating zero byte.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When no zero terminator
     *   is found.
     */
    readPaddedString(encoding?: string): string;
    /**
     * Reads a null-terminated UTF-16LE string and advances to the next aligned
     * offset.
     *
     * @returns The decoded Unicode string without the terminating `0x0000`
     *   code unit pair.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When no zero terminator
     *   is found.
     */
    readPaddedUnicodeString(): string;
}
/**
 * DWG-style bit-stream reader for compact proxy-graphic payloads.
 *
 * Implements the AutoCAD bit-packing scheme used by lightweight polyline and
 * other compressed proxy-graphic records, including optional default-value
 * doubles and version-dependent fields.
 */
export declare class AcDbProxyGraphicBitStream {
    /** Backing byte buffer. */
    private readonly _buffer;
    /** Current read cursor in bits. */
    private _bitIndex;
    /**
     * Drawing version string used to gate version-specific fields.
     *
     * Example: `'AC1015'`, `'AC1024'`.
     */
    readonly dxfversion: string;
    /**
     * Character encoding used when reading embedded single-byte text.
     *
     * Example: `'cp1252'`, `'utf-8'`.
     */
    readonly encoding: string;
    /**
     * Creates a bit stream over the given buffer.
     *
     * @param buffer - Chunk payload bytes.
     * @param dxfversion - Drawing version string. Defaults to `'AC1015'`.
     * @param encoding - Single-byte text encoding. Defaults to `'cp1252'`.
     */
    constructor(buffer: Bytes, dxfversion?: string, encoding?: string);
    /**
     * Indicates whether unread bits remain in the buffer.
     */
    get hasData(): boolean;
    /**
     * Reads a single bit from the stream.
     *
     * @returns `1` when the bit is set, otherwise `0`.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When no byte is available.
     */
    readBit(): 0 | 1;
    /**
     * Reads the next `count` bits as an unsigned integer, MSB first within the
     * field.
     *
     * @param count - Number of bits to read.
     * @returns The assembled unsigned value.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When the read would pass
     *   the end of the buffer.
     */
    readBits(count: number): number;
    /**
     * Reads one unsigned 8-bit value from the bit stream.
     *
     * @returns The decoded byte in the range `0..255`.
     */
    readUnsignedByte(): number;
    /**
     * Reads one signed 8-bit value from the bit stream.
     *
     * @returns The decoded signed byte.
     */
    readSignedByte(): number;
    /**
     * Reads `count` whole bytes from the stream, aligning the bit cursor first
     * when currently mid-byte.
     *
     * @param count - Number of bytes to read.
     * @returns A subarray view over the consumed bytes.
     * @throws {@link AcDbProxyGraphicEndOfBufferError} When the read would pass
     *   the end of the buffer.
     */
    readAlignedBytes(count: number): Uint8Array;
    /**
     * Reads one little-endian unsigned 16-bit integer.
     *
     * @returns The decoded unsigned short.
     */
    readUnsignedShort(): number;
    /**
     * Reads one little-endian signed 16-bit integer.
     *
     * @returns The decoded signed short.
     */
    readSignedShort(): number;
    /**
     * Reads one little-endian unsigned 32-bit integer.
     *
     * @returns The decoded unsigned long.
     */
    readUnsignedLong(): number;
    /**
     * Reads one little-endian signed 32-bit integer.
     *
     * @returns The decoded signed long.
     */
    readSignedLong(): number;
    /**
     * Reads one little-endian 64-bit floating-point value.
     *
     * @returns The decoded double.
     */
    readFloat(): number;
    /**
     * Reads one or more raw little-endian doubles without bit-short compression.
     *
     * @param count - Number of doubles to read. Defaults to `1`.
     * @returns A single number when `count === 1`, otherwise an array of doubles.
     */
    readRawDouble(count?: number): number | number[];
    /**
     * Reads one or more DWG **bit-short** values.
     *
     * The 2-bit prefix selects between a full short, a single byte, zero, or the
     * sentinel value `256`.
     *
     * @param count - Number of values to read. Defaults to `1`.
     * @returns A single value or an array of values.
     */
    readBitShort(count?: number): number | number[];
    /**
     * Reads one or more DWG **bit-long** values.
     *
     * @param count - Number of values to read. Defaults to `1`.
     * @returns A single value or an array of values.
     */
    readBitLong(count?: number): number | number[];
    /**
     * Reads one or more DWG **bit-double** values.
     *
     * @param count - Number of values to read. Defaults to `1`.
     * @returns A single value or an array of values.
     */
    readBitDouble(count?: number): number | number[];
    /**
     * Reads one or more DWG **default bit-double** values.
     *
     * When the prefix indicates "default", `defaultValue` is returned unchanged.
     * Otherwise a partial or full double is reconstructed from the stream.
     *
     * @param count - Number of values to read. Defaults to `1`.
     * @param defaultValue - Fallback double used for default-encoded values.
     * @returns A single value or an array of values.
     */
    readBitDoubleDefault(count?: number, defaultValue?: number): number | number[];
}
/**
 * Converts a byte array to an upper-case hexadecimal string.
 *
 * Used when writing proxy graphics to DXF group code **310** chunks.
 *
 * @param data - Bytes to encode.
 * @returns A contiguous hex string with two digits per byte.
 */
export declare function acdbBytesToHexString(data: Uint8Array): string;
/**
 * Decodes one or more hexadecimal strings into a single byte array.
 *
 * Non-hex characters are not filtered; each pair of characters is parsed with
 * `parseInt(..., 16)`.
 *
 * @param chunks - Hex strings, typically from DXF group code **310**.
 * @returns Concatenated decoded bytes.
 */
export declare function acdbHexStringsToBytes(chunks: string[]): Uint8Array;
/**
 * Combines DXF group-code **310** payload chunks that may arrive either as
 * hexadecimal strings (ASCII DXF readers that leave hex raw) or as already
 * decoded binary (`Uint8Array` from typed/binary pair readers).
 *
 * Calling `String(Uint8Array)` corrupts the payload (comma-separated decimals),
 * so callers must use this helper instead of treating every chunk as hex text.
 *
 * @param chunks - Ordered group **310** values from DXF.
 * @returns Concatenated bytes in chunk order.
 */
export declare function acdbCombineDxfBinaryChunks(chunks: Array<string | Uint8Array>): Uint8Array;
export {};
//# sourceMappingURL=AcDbProxyGraphicBinaryStream.d.ts.map