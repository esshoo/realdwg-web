/**
 * Shared MIME types and byte-signature helpers for OLE metafile payloads.
 */
/** MIME type used when an OLE presentation stores a Windows Metafile (WMF). */
export declare const ACDB_OLE_METAFILE_WMF_MIME = "image/wmf";
/** MIME type used when an OLE presentation stores an Enhanced Metafile (EMF). */
export declare const ACDB_OLE_METAFILE_EMF_MIME = "image/emf";
/**
 * Returns true when `mime` identifies a WMF/EMF blob produced by the OLE
 * image extractor.
 */
export declare function acdbIsOleMetafileMimeType(mime?: string | null): boolean;
/**
 * Detects a standard or Aldus-placeable WMF header at the start of `data`.
 */
export declare function acdbLooksLikeWmf(data: Uint8Array): boolean;
/**
 * Detects an EMF (`EMR_HEADER` with the `" EMF"` signature) somewhere near the
 * start of `data` (including after a short WMF / METAFILEPICT preamble).
 */
export declare function acdbLooksLikeEmf(data: Uint8Array): boolean;
/**
 * Reassembles a contiguous EMF from a WMF that embeds it via
 * `META_ESCAPE_ENHANCED_METAFILE` ("WMFC") records.
 *
 * Excel OLE `CF_ENHMETAFILE` presentations are frequently stored as such a
 * WMF wrapper. Taking a contiguous `nBytes` slice starting at the first
 * embedded `EMR_HEADER` pulls WMF escape framing into the EMF stream and
 * corrupts later EMR records — converters then only replay the first ~screen
 * of GDI text (e.g. 8 Excel rows) while the canvas stays mostly blank.
 *
 * @returns The concatenated EMF bytes, or `undefined` when no WMFC chunks are found.
 * @see https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-wmf/cfc88064-d86d-4b52-9374-3ce27d456179
 */
export declare function acdbReassembleEmfFromWmfEscapes(data: Uint8Array): Uint8Array | undefined;
/**
 * Locates the first plausible `EMR_HEADER` in `data`.
 *
 * @returns Byte offset of the header, or `-1` when none is found.
 */
export declare function findEmfHeaderOffset(data: Uint8Array): number;
/**
 * Returns true when `data[offset…]` is a plausible EMF header.
 */
export declare function isEmfHeaderAt(data: Uint8Array, offset: number): boolean;
//# sourceMappingURL=AcDbOleMetafileDetect.d.ts.map