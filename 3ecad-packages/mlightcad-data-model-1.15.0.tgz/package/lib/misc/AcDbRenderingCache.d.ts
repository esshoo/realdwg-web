import { AcCmColor } from '@mlightcad/common';
import { AcGeMatrix3d, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord';
/**
 * Optional timing counters for one cache-miss block build during
 * {@link AcDbRenderingCache.draw}. Enable with
 * {@link AcDbRenderingCache.profiling} = true.
 */
export interface AcDbRenderingCacheBlockMissProfile {
    /** Block table record name (or `'(unnamed)'`). */
    blockName: string;
    /** Entity `worldDraw` + `group` time in ms (excludes compact). */
    buildMs: number;
    /** `compactForInstancing` time in ms. */
    compactMs: number;
    /** Time spent cloning the template in {@link AcDbRenderingCache.set}. */
    setCloneMs: number;
}
/**
 * Accumulated timing counters for {@link AcDbRenderingCache}.
 * Only updated while {@link AcDbRenderingCache.profiling} is true.
 */
export interface AcDbRenderingCacheProfileStats {
    /** Cache hit count (template already built). */
    hits: number;
    /** Cache miss count (template built on this call). */
    misses: number;
    /** Total time spent on hit path before apply/attribs (includes clone). */
    hitMs: number;
    /** Miss path: entity worldDraw + group, excluding compact. */
    missBuildMs: number;
    /** Miss path: compactForInstancing. */
    missCompactMs: number;
    /** Time spent in get() → fastDeepClone (hit clones). */
    cloneMs: number;
    /** Time spent in set() → fastDeepClone (store template). */
    setCloneMs: number;
    /** applyMatrix + attribute attach after template ready. */
    applyMs: number;
    /**
     * Same counters as above but only for outermost `draw()` calls
     * (excludes nested INSERT draws while building a parent template).
     */
    topLevel: {
        /** Top-level cache hits. */
        hits: number;
        /** Top-level cache misses. */
        misses: number;
        /** Top-level hit-path time in ms. */
        hitMs: number;
        /** Top-level miss build time in ms. */
        missBuildMs: number;
        /** Top-level compact time in ms. */
        missCompactMs: number;
        /** Top-level hit-clone time in ms. */
        cloneMs: number;
        /** Top-level set-clone time in ms. */
        setCloneMs: number;
        /** Top-level apply/attribute time in ms. */
        applyMs: number;
    };
    /** Per-block miss breakdown (all depths). */
    blockMisses: AcDbRenderingCacheBlockMissProfile[];
}
/**
 * Internal class used to cache rendered results to avoid duplicated rendering.
 *
 * This class can be used to improve performance when rendering block references.
 * Blocks without ByBlock-colored entities share one color-independent template.
 * Blocks that contain ByBlock entities still key by block name and color because
 * different INSERT colors produce different materials.
 *
 * Templates may be compacted (same-material leaves merged) before or on first
 * reuse so each INSERT clones O(material) geometries instead of O(entity)
 * geometries. Mid-size templates defer compaction until the first cache hit so
 * one-shot blocks skip merge work; tiny templates never compact.
 *
 * @internal
 *
 * @example
 * ```typescript
 * const cache = AcDbRenderingCache.instance;
 * const color = new AcCmColor().setRGBValue(0xFF0000);
 * const key = cache.createKey('MyBlock', color);
 * const renderedEntity = cache.draw(renderer, blockRecord, color);
 * ```
 */
export declare class AcDbRenderingCache {
    /** Map of cached rendering results indexed by key. */
    private _blocks;
    /** Estimated bytes per cached key (tracked only while LRU is enabled). */
    private _lruBytes;
    /** Sum of {@link _lruBytes} values. */
    private _lruTotalBytes;
    /**
     * Evicted compacted templates awaiting document-close disposal. Compacted
     * templates share geometry buffers with clones already in the scene, so
     * they cannot be disposed at eviction time.
     */
    private _retiredCompactedTemplates;
    /** Singleton instance of the cache. */
    private static _instance?;
    /**
     * When true, {@link draw} / {@link get} / {@link set} accumulate
     * {@link profileStats}. Off by default (zero overhead when false).
     */
    static profiling: boolean;
    /**
     * LRU master switch. When false, the cache never evicts and behaves like
     * the pre-LRU implementation.
     */
    static lruEnabled: boolean;
    /** Max cached templates before the oldest entries are evicted (0 = unlimited). */
    static lruMaxEntries: number;
    /**
     * Max estimated cached bytes before the oldest entries are evicted
     * (0 = unlimited). Estimates duck-type walk the template tree geometry.
     */
    static lruMaxEstimatedBytes: number;
    /**
     * Mutable profile accumulator used while {@link profiling} is true.
     */
    private static _profileStats;
    /** Nesting depth of {@link draw} while profiling (1 = outermost). */
    private static _drawDepth;
    /**
     * Accumulated profile counters. Only updated while {@link profiling} is true.
     */
    static get profileStats(): Readonly<AcDbRenderingCacheProfileStats>;
    /**
     * Clears {@link profileStats} and draw nesting depth.
     * Leaves {@link profiling} unchanged.
     */
    static resetProfile(): void;
    /**
     * Gets the singleton instance of the rendering cache.
     *
     * @returns The singleton instance of AcDbRenderingCache
     *
     * @example
     * ```typescript
     * const cache = AcDbRenderingCache.instance;
     * ```
     */
    static get instance(): AcDbRenderingCache;
    /**
     * Creates a new AcDbRenderingCache instance.
     *
     * @example
     * ```typescript
     * const cache = new AcDbRenderingCache();
     * ```
     */
    constructor();
    /**
     * Creates a cache key by combining the block name and color.
     *
     * Prefer {@link createCacheKey} when the block's ByBlock dependency is known,
     * so color-independent blocks can share one template.
     *
     * @param name - The block name
     * @param color - The resolved block color
     * @returns A unique key for the cache entry
     *
     * @example
     * ```typescript
     * const color = new AcCmColor().setRGBValue(0xFF0000);
     * const key = cache.createKey('MyBlock', color);
     * // Returns: "MyBlock_RGB:255,0,0"
     * ```
     */
    createKey(name: string, color: AcCmColor): string;
    /**
     * Creates a cache key, omitting color when the block has no ByBlock entities.
     *
     * Color-independent keys let INSERTs that differ only by layer (ByLayer
     * traits remapped at instance time) share one compacted template.
     *
     * @param name - The block name
     * @param color - The resolved INSERT color (used only when `hasByBlockColor`)
     * @param hasByBlockColor - Whether any entity in the block uses ByBlock color
     * @returns Cache key: `name` alone, or `name_color` when ByBlock entities exist
     */
    createCacheKey(name: string, color: AcCmColor, hasByBlockColor: boolean): string;
    /**
     * Stores rendering results of a block in the cache.
     *
     * Stores `group` by reference as an immutable template. Callers must not
     * mutate the stored object after this call; {@link get} / miss-path draws
     * return {@link AcGiEntity.fastDeepClone} instances for scene use. Compacted
     * templates share geometry buffers across clones (see three-renderer
     * `AcTrGroup.fastDeepClone`).
     *
     * @param key - The key for the rendering results
     * @param group - The rendering results to store
     * @returns The stored rendering results (same reference as `group`)
     *
     * @example
     * ```typescript
     * const renderedEntity = cache.set(key, entity);
     * ```
     */
    set(key: string, group: AcGiEntity): AcGiEntity;
    /**
     * Evicts least-recently-used templates while the cache exceeds its entry or
     * estimated-byte budget.
     */
    private enforceLruBudget;
    /** Evicts the least-recently-used entry, disposing it when safe. */
    private evictOldest;
    /**
     * Estimates a template's byte footprint by walking its tree and summing
     * geometry attribute/index buffers. Returns 0 for objects that do not
     * expose `children`/`geometry` (non-three implementations).
     */
    private estimateTemplateBytes;
    /**
     * Gets rendering results with the specified key.
     *
     * Returns a deep clone so callers can transform the instance without
     * mutating the cached template. Compacted templates share geometry buffers
     * with the clone (Object3D wrappers are still unique per INSERT).
     *
     * @param name - The key of the rendering results
     * @returns The cloned rendering results, or `undefined` if not found
     *
     * @example
     * ```typescript
     * const cachedEntity = cache.get('MyBlock_16711680');
     * if (cachedEntity) {
     *   // Use cached entity
     * }
     * ```
     */
    get(name: string): AcGiEntity | undefined;
    /**
     * Checks if rendering results with the specified key exist in the cache.
     *
     * @param name - The key to check
     * @returns True if the key exists in the cache, false otherwise
     *
     * @example
     * ```typescript
     * if (cache.has('MyBlock_16711680')) {
     *   console.log('Cached result found');
     * }
     * ```
     */
    has(name: string): boolean;
    /**
     * Clears all cached rendering results and disposes owned geometry.
     *
     * @example
     * ```typescript
     * cache.clear();
     * console.log('Cache cleared');
     * ```
     */
    clear(): void;
    /**
     * Prebuilds color-independent block templates before entity flush.
     *
     * Skips layout blocks (`*Model_Space` / `*Paper_Space*`), empty blocks,
     * anonymous `*U` blocks, and blocks that contain ByBlock-colored entities
     * (those require the INSERT color and are built on demand).
     *
     * @param renderer - Renderer used to convert block entities
     * @param blocks - Iterator over block table records
     * @param progress - Optional progress callback `(built, total, blockName)`
     */
    prebuildAll(renderer: AcGiRenderer, blocks: Iterable<AcDbBlockTableRecord>, progress?: (built: number, total: number, blockName: string) => void | Promise<void>): Promise<void>;
    /**
     * Draws a block table record and optionally caches the result.
     *
     * This method renders the block table record using the specified renderer
     * and color, and optionally stores the result in the cache for future use.
     *
     * @param renderer - The renderer to use for drawing
     * @param blockTableRecord - The block table record to draw
     * @param blockColor - The resolved color to use for rendering
     * @param attributes - Attribute graphics to attach (WCS); converted to
     *   block-local space when `transform` is provided
     * @param cache - Whether to cache the rendering result (default: true)
     * @param transform - Optional block-reference transformation matrix
     * @param normal - Optional extrusion / normal vector
     * @returns The rendered entity
     *
     * @example
     * ```typescript
     * const renderedEntity = cache.draw(
     *   renderer,
     *   blockRecord,
     *   new AcCmColor().setRGBValue(0xFF0000),
     *   [],
     *   true,
     *   transform,
     *   normal
     * );
     * ```
     */
    draw(renderer: AcGiRenderer, blockTableRecord: AcDbBlockTableRecord, blockColor: AcCmColor, attributes?: AcGiEntity[], cache?: boolean, transform?: AcGeMatrix3d, normal?: AcGeVector3d): AcGiEntity | undefined;
    /**
     * Returns whether `block` should be excluded from {@link prebuildAll}.
     *
     * Skips layout blocks, anonymous `*U` blocks, blocks with ByBlock colors
     * (key depends on INSERT color), and blocks with no visible entities.
     *
     * @param block - Block table record to evaluate.
     * @returns `true` when the block should not be prebuilt.
     */
    private shouldSkipPrebuild;
    /**
     * Returns whether any visible entity in the block uses ByBlock color.
     *
     * @param blockTableRecord - Block whose entities are scanned.
     * @returns `true` when at least one visible ByBlock-colored entity exists.
     */
    private blockHasByBlockColor;
    /**
     * Draws one visible entity and appends its graphic result to `results`.
     *
     * @param entity - Database entity to convert.
     * @param results - Accumulator for graphic-interface entities.
     * @param renderer - Renderer used for `worldDraw`.
     */
    private addEntity;
    /**
     * Copies database identity/layer/visibility onto a graphic-interface entity.
     *
     * @param target - Graphic entity produced by `worldDraw`.
     * @param source - Source database entity.
     */
    private attachEntityInfo;
    /**
     * Optionally runs {@link AcGiEntity.compactForInstancing} using the adaptive
     * thresholds in {@link shouldCompactTemplate}.
     *
     * @param entity - Block template group to consider compacting.
     * @param onCacheHit - When true, mid-size templates become eligible (first
     *   reuse). When false, only huge templates compact eagerly on miss.
     * @returns `true` when compaction ran.
     */
    private maybeCompactTemplate;
}
//# sourceMappingURL=AcDbRenderingCache.d.ts.map