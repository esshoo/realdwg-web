import { AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
/**
 * Draws a rectangular image/OLE frame that remains interior-pickable when no
 * raster is shown.
 *
 * AutoCAD lets users click inside IMAGE / OLE2FRAME extents even when only the
 * outline is visible. Outline-only `renderer.lines` cannot provide that, so this
 * helper adds a fully transparent solid fill for hit-testing and keeps the
 * visible frame outline.
 *
 * @param renderer - Target graphics renderer.
 * @param boundary - Closed frame boundary in WCS (closing vertex optional).
 * @returns Group of fill + outline, or outline alone if fill cannot be built.
 */
export declare function acdbDrawImageFrame(renderer: AcGiRenderer, boundary: AcGePoint3dLike[]): AcGiEntity | undefined;
//# sourceMappingURL=acdbDrawImageFrame.d.ts.map