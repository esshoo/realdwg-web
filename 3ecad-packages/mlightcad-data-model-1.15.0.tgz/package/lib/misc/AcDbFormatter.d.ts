import { AcGePoint2d, AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbDatabase } from '../database/AcDbDatabase';
/**
 * Per-call options for {@link AcDbFormatter} methods.
 *
 * These options layer on top of the drawing system variables held by the bound
 * {@link AcDbDatabase}; they do not change the database itself.
 */
export interface AcDbFormatterOptions {
    /**
     * Whether to append real-world unit suffixes to formatted values.
     *
     * When `true`:
     * - Decimal/scientific/fractional linear values may receive a suffix derived from
     *   {@link AcDbDatabase.insunits | INSUNITS} (or {@link AcDbDatabase.measurement | MEASUREMENT}
     *   when **INSUNITS** is unitless), for example `12.35 mm` or `10"`.
     * - Angles may receive `°`, `g`, `rad`, or inch marks in DMS/surveyor formats.
     * - Engineering and architectural lengths already embed `'` / `"` in the **LUNITS** pattern;
     *   this flag mainly adds the inch quote for those modes when appropriate.
     *
     * When `false` (default), only the numeric pattern dictated by **LUNITS** / **AUNITS** is
     * returned (for example `12.35`, `1'-3 1/2`, `45d30'15"`).
     */
    showUnits?: boolean;
    /**
     * Whether to prefix the formatted value with `~ ` when display precision rounds the input.
     *
     * When `true`, values that are not exactly representable at the current **LUPREC** / **AUPREC**
     * (or fractional denominator for architectural modes) are returned as `~ ${formatted}` — for
     * example `~ 12.35` instead of `12.35` for `12.3456` with two decimal places.
     *
     * When `false` (default), no approximate prefix is added.
     */
    showApproximate?: boolean;
    /**
     * Whether to apply {@link AcDbDatabase.angbase | ANGBASE} and
     * {@link AcDbDatabase.angdir | ANGDIR} before formatting an angle.
     *
     * When `true` (default), the input is treated as an absolute WCS angle (counterclockwise
     * from +X before adjustment), matching status-bar bearing-style display.
     *
     * When `false`, the input radians are formatted directly (after normalization to
     * \([0, 2\pi)\)), for included angles, relative rotations, rubber-band sweep angles,
     * and dynamic-input relative angle values.
     */
    applyAngbaseAngdir?: boolean;
}
/**
 * Formats linear distances, point coordinates, and angles for display in the UI,
 * matching AutoCAD drawing-unit behavior as closely as the supported system variables allow.
 *
 * An instance is bound to one {@link AcDbDatabase}. On each call it reads the current values of
 * the relevant header/system variables from that database (not a snapshot taken at construction).
 *
 * ### Linear distances and coordinates
 *
 * | Variable | Role |
 * |----------|------|
 * | **LUNITS** | Display format (scientific, decimal, engineering, …); see {@link AcDbDatabase.lunits} |
 * | **LUPREC** | Precision (decimal places or fractional denominator); see {@link AcDbDatabase.luprec} |
 * | **INSUNITS** | Unit suffix when {@link AcDbFormatterOptions.showUnits} is `true`; see {@link AcDbDatabase.insunits} |
 * | **UNITMODE** | Report vs input delimiters for feet-inch and fractions; see {@link AcDbDatabase.unitmode} |
 * | **MEASUREMENT** | Imperial vs metric suffix when **INSUNITS** is unitless; see {@link AcDbDatabase.measurement} |
 *
 * Engineering (**LUNITS** = 3) and architectural (**LUNITS** = 4) formats treat the numeric
 * value as **inches**, consistent with AutoCAD.
 *
 * ### Angles
 *
 * Input angles are **radians in WCS**. Before formatting, the value is adjusted by
 * {@link AcDbDatabase.angbase | ANGBASE} and {@link AcDbDatabase.angdir | ANGDIR}, then converted
 * per {@link AcDbDatabase.aunits | AUNITS} and {@link AcDbDatabase.auprec | AUPREC}.
 *
 * ### Out of scope
 *
 * Dimension entity text uses per-style **DIM\*** variables (for example **DIMLUNIT**, **DIMDEC**),
 * not this class. **SNAPANG** and UCS settings affect snapping/input, not WCS coordinate strings here.
 *
 * @example
 * ```typescript
 * database.lunits = AcDbLinearUnits.Decimal;
 * database.luprec = 2;
 *
 * database.formatter.formatLength(12.3456); // "12.35"
 * database.formatter.formatLength(12.3456, { showUnits: true }); // "12.35 mm" (with INSUNITS = mm)
 * database.formatter.formatPoint2d(new AcGePoint2d(1, 2)); // "1, 2"
 * database.formatter.formatAngle(Math.PI / 4, { showUnits: true }); // "45°"
 * ```
 */
export declare class AcDbFormatter {
    private readonly database;
    /**
     * Creates a formatter that reads unit settings from the given database.
     *
     * @param database - Drawing database whose **LUNITS**, **AUNITS**, and related variables
     *   are consulted on every format call.
     */
    constructor(database: AcDbDatabase);
    /**
     * Formats a single linear distance in **drawing units**.
     *
     * The output pattern follows {@link AcDbDatabase.lunits | LUNITS} and
     * {@link AcDbDatabase.luprec | LUPREC}. When {@link AcDbFormatterOptions.showUnits} is `true`,
     * a suffix may be appended based on {@link AcDbDatabase.insunits | INSUNITS} and
     * {@link AcDbDatabase.measurement | MEASUREMENT}.
     *
     * | **LUNITS** | Typical output (no unit suffix) |
     * |-----------:|--------------------------------|
     * | `1` Scientific | `1.23E+02` |
     * | `2` Decimal | `12.35` |
     * | `3` Engineering | `1'-3.5` (value interpreted as inches) |
     * | `4` Architectural | `1'-3 1/2` |
     * | `5` Fractional | `15 1/2` |
     * | `6` Windows desktop | Same as decimal |
     *
     * {@link AcDbDatabase.unitmode | UNITMODE} changes delimiters for engineering, architectural,
     * and fractional modes (for example `1'3-1/2` when **UNITMODE** = 1).
     *
     * @param value - Distance in drawing units (WCS length, not pre-converted to feet or degrees).
     * @param options - Optional display flags; see {@link AcDbFormatterOptions}.
     * @returns Formatted string suitable for status bars, measurement overlays, or tooltips.
     *
     * @remarks
     * Non-finite values (`NaN`, `±Infinity`) are formatted as `"0"`.
     *
     * @example
     * ```typescript
     * database.lunits = AcDbLinearUnits.Architectural;
     * database.luprec = 2;
     * formatter.formatLength(15.5); // "1'-3 1/2"
     * ```
     */
    formatLength(value: number, options?: AcDbFormatterOptions): string;
    /**
     * Formats a 2D point as `"x, y"`, formatting each component with {@link formatLength}.
     *
     * Both coordinates use the same {@link AcDbDatabase.lunits | LUNITS} / **LUPREC** rules and the
     * same {@link AcDbFormatterOptions} for the call. The separator is a comma followed by a space
     * (`, `), which matches common Cartesian display in measurement UIs.
     *
     * @param point - Point in drawing units (WCS **x** / **y**).
     * @param options - Optional display flags applied to each coordinate.
     * @returns Formatted coordinate pair, for example `"1.2, 4.6"` or `"1'-0, 2'-6"` depending on **LUNITS**.
     *
     * @example
     * ```typescript
     * database.lunits = AcDbLinearUnits.Decimal;
     * database.luprec = 1;
     * formatter.formatPoint2d(new AcGePoint2d(1.23, 4.56)); // "1.2, 4.6"
     * ```
     */
    formatPoint2d(point: AcGePoint2d, options?: AcDbFormatterOptions): string;
    /**
     * Formats a 3D point as `"x, y, z"`, formatting each component with {@link formatLength}.
     *
     * Behavior is the same as {@link formatPoint2d} for **x** and **y**, with **z** appended using
     * the same linear formatting and options.
     *
     * @param point - Point in drawing units (WCS **x** / **y** / **z**).
     * @param options - Optional display flags applied to each coordinate.
     * @returns Formatted coordinate triple, for example `"1.2, 4.6, 7.9"`.
     *
     * @example
     * ```typescript
     * formatter.formatPoint3d(new AcGePoint3d(1, 2, 3)); // "1, 2, 3" (with default decimal LUNITS)
     * ```
     */
    formatPoint3d(point: AcGePoint3d, options?: AcDbFormatterOptions): string;
    /**
     * Formats an angle given in **radians** (WCS), for display according to the drawing angle units.
     *
     * Processing order:
     * 1. Subtract {@link AcDbDatabase.angbase | ANGBASE} (zero direction).
     * 2. Negate if {@link AcDbDatabase.angdir | ANGDIR} = 1 (clockwise positive).
     * 3. Normalize to \([0, 2\pi)\) via {@link AcGeMathUtil.normalizeAngle}.
     * 4. Format using {@link AcDbDatabase.aunits | AUNITS} and {@link AcDbDatabase.auprec | AUPREC}.
     *
     * | **AUNITS** | Typical output (no unit suffix) |
     * |-----------:|--------------------------------|
     * | `0` Decimal degrees | `45` or `45.5` |
     * | `1` Degrees/minutes/seconds | `45d30'15"` |
     * | `2` Gradians | `50` |
     * | `3` Radians | `0.785` |
     * | `4` Surveyor's | `N 45d30'15" E` |
     *
     * @param radians - Angle in radians. When {@link AcDbFormatterOptions.applyAngbaseAngdir} is
     *   `true` (default), this is an absolute WCS angle (counterclockwise from +X before
     *   **ANGBASE** / **ANGDIR** adjustment). When `false`, this is the scalar angle to display.
     * @param options - Optional display flags; when {@link AcDbFormatterOptions.showUnits} is `true`,
     *   unit markers such as `°`, `g`, or `rad` may be appended.
     * @returns Formatted angle string.
     *
     * @remarks
     * For included or relative angles, pass {@link AcDbFormatterOptions.applyAngbaseAngdir} = `false`.
     * For arc sweep or dimension overrides, supply the appropriate radians value and flags.
     *
     * @example
     * ```typescript
     * database.aunits = AcDbAngleUnits.DecimalDegrees;
     * database.auprec = 0;
     * formatter.formatAngle(Math.PI / 4); // "45"
     * formatter.formatAngle(Math.PI / 4, { showUnits: true }); // "45°"
     * ```
     */
    formatAngle(radians: number, options?: AcDbFormatterOptions): string;
    /**
     * Builds the formatting context from the bound database and call options.
     *
     * @param options - Per-call overrides; omitted fields use database defaults.
     * @returns Snapshot of linear and angular unit settings for one format call.
     * @internal
     */
    private createContext;
}
//# sourceMappingURL=AcDbFormatter.d.ts.map