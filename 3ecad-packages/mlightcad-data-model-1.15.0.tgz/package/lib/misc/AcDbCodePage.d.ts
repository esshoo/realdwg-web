export declare enum AcDbCodePage {
    UTF8 = 0,
    US_ASCII = 1,
    ISO_8859_1 = 2,
    ISO_8859_2 = 3,
    ISO_8859_3 = 4,
    ISO_8859_4 = 5,
    ISO_8859_5 = 6,
    ISO_8859_6 = 7,
    ISO_8859_7 = 8,
    ISO_8859_8 = 9,
    ISO_8859_9 = 10,
    CP437 = 11,// DOS English
    CP850 = 12,// 12 DOS Latin-1
    CP852 = 13,// DOS Central European
    CP855 = 14,// DOS Cyrillic
    CP857 = 15,// DOS Turkish
    CP860 = 16,// DOS Portoguese
    CP861 = 17,// DOS Icelandic
    CP863 = 18,// DOS Hebrew
    CP864 = 19,// DOS Arabic (IBM)
    CP865 = 20,// DOS Nordic
    CP869 = 21,// DOS Greek
    CP932 = 22,// DOS Japanese (shiftjis)
    MACINTOSH = 23,// 23
    BIG5 = 24,
    CP949 = 25,// Korean (Wansung + Johab)
    JOHAB = 26,// Johab?
    CP866 = 27,// Russian
    ANSI_1250 = 28,// Central + Eastern European
    ANSI_1251 = 29,// Cyrillic
    ANSI_1252 = 30,// Western European
    GB2312 = 31,// EUC-CN Chinese
    ANSI_1253 = 32,// Greek
    ANSI_1254 = 33,// Turkish
    ANSI_1255 = 34,// Hebrew
    ANSI_1256 = 35,// Arabic
    ANSI_1257 = 36,// Baltic
    ANSI_874 = 37,// Thai
    ANSI_932 = 38,// 38 Japanese (extended shiftjis, windows-31j)
    ANSI_936 = 39,// 39 Simplified Chinese
    ANSI_949 = 40,// 40 Korean Wansung
    ANSI_950 = 41,// 41 Trad Chinese
    ANSI_1361 = 42,// 42 Korean Wansung
    UTF16 = 43,
    ANSI_1258 = 44,// Vietnamese
    UNDEFINED = 255
}
export declare const acdbDwgCodePageToEncoding: (codepage: AcDbCodePage) => string;
/**
 * Normalizes a user-supplied encoding label to one `TextDecoder` accepts.
 *
 * Unknown labels pass through unchanged so `TextDecoder` reports the error
 * itself. Labels are matched case-insensitively with `'_'` and `'-'` ignored,
 * mirroring how DXF code page names arrive in mixed forms.
 *
 * @param encoding - Encoding label such as `'cp949'` or `'EUC-KR'`.
 * @returns A label `new TextDecoder(...)` accepts in every runtime.
 */
export declare const acdbNormalizeTextEncoding: (encoding: string) => string;
//# sourceMappingURL=AcDbCodePage.d.ts.map