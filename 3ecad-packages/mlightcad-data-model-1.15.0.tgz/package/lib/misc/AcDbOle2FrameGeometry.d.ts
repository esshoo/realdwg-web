/**
 * Parses the AutoCAD OLE2FRAME binary geometry header that precedes the
 * embedded MS-CFB compound document.
 *
 * Layout (little-endian), matching observed DXF group-310 / DWG `data` payloads:
 * - `uint16` marker (commonly `0x5580`)
 * - four `Point3d` corners: upper-left, upper-right, lower-right, lower-left
 * - additional metadata through offset `0x80`
 * - MS-CFB document starting at offset `0x80`
 *
 * @see https://macoy.me/blog/programming/DXFFormat
 * @see LibreDWG `dwg_decode_ole2` notes on `OLE2FRAME.data`
 */
/** Bytes reserved for the OLE2FRAME geometry / metadata header. */
export declare const ACDB_OLE2FRAME_GEOMETRY_HEADER_SIZE = 128;
export interface AcDbOle2FrameGeometryHeader {
    /** Upper-left corner in WCS (DXF group code 10). */
    upperLeft: {
        x: number;
        y: number;
        z: number;
    };
    /** Upper-right corner in WCS. */
    upperRight: {
        x: number;
        y: number;
        z: number;
    };
    /** Lower-right corner in WCS (DXF group code 11). */
    lowerRight: {
        x: number;
        y: number;
        z: number;
    };
    /** Lower-left corner in WCS. */
    lowerLeft: {
        x: number;
        y: number;
        z: number;
    };
}
/**
 * Attempts to read the OLE2FRAME geometry header from an OLE binary payload.
 *
 * @param data - Full OLE2FRAME binary blob (geometry header + CFB).
 * @returns Parsed corners when the header looks valid; otherwise `undefined`.
 */
export declare function acdbParseOle2FrameGeometryHeader(data?: Uint8Array | null): AcDbOle2FrameGeometryHeader | undefined;
//# sourceMappingURL=AcDbOle2FrameGeometry.d.ts.map