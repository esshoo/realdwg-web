import type { AcDbPatDocument } from './AcDbPatDefinition';
/**
 * Parser for AutoCAD PAT text content.
 *
 * This parser follows a best-effort strategy:
 * - valid patterns are still returned when some rows are malformed;
 * - non-fatal problems are collected into {@link AcDbPatDocument.issues};
 * - PAT line numbers are preserved in parsed descriptors for diagnostics.
 *
 * Typical usage:
 * - instantiate once and call {@link parse} for each PAT payload;
 * - or call the convenience static {@link AcDbPatParser.parse} method.
 */
export declare class AcDbPatParser {
    /**
     * Parse PAT file text into structured patterns and issues.
     *
     * The method accepts complete PAT file content (including comments, blank
     * lines, and multiple pattern blocks). It normalizes line endings, parses
     * headers and line descriptors, and records any recoverable errors.
     *
     * @param content - Raw PAT file text.
     * @returns Parsed document containing both successful patterns and collected
     * parse issues.
     */
    parse(content: string): AcDbPatDocument;
    /**
     * Parse PAT text without manually creating a parser instance.
     *
     * @param content - Raw PAT file text.
     * @returns Parsed PAT document.
     */
    static parse(content: string): AcDbPatDocument;
    /**
     * Normalize line endings to Unix `\n` form.
     *
     * @param content - Raw text that may include `\r\n`, `\r`, or `\n`.
     * @returns Text with all line endings converted to `\n`.
     */
    private normalizeLineEndings;
    /**
     * Remove inline PAT comments from a source line.
     *
     * PAT comment syntax uses `;` and ignores everything after it.
     *
     * @param rawLine - Unprocessed source line from the PAT file.
     * @returns Source line without trailing comment section.
     */
    private stripInlineComment;
    /**
     * Parse a PAT header body after the leading `*`.
     *
     * Examples:
     * - `ANSI31, 45 degree hatch`
     * - `SOLID`
     *
     * @param body - Header content without the leading `*`.
     * @returns Parsed `{ name, description }`, or `null` when header is invalid.
     */
    private parseHeader;
    /**
     * Parse a numeric token from PAT syntax.
     *
     * @param token - Numeric field text from a PAT row.
     * @returns Finite number value, or `null` when token is not a valid number.
     */
    private parseNumber;
    /**
     * Parse one PAT line descriptor row.
     *
     * Expected format:
     * `angle,x-origin,y-origin,delta-x,delta-y[,dash-1,dash-2,...]`
     *
     * @param raw - Row text without inline comments.
     * @param lineNumber - Original 1-based source line number.
     * @returns Parsed line descriptor with source metadata, or `null` when row
     * does not satisfy the expected numeric schema.
     */
    private parseLineDescriptor;
    /**
     * Finalize the current pattern and append it to output collections.
     *
     * If a pattern header was parsed but no line descriptor followed, this method
     * records an issue and still emits the empty pattern to preserve source
     * intent and ordering.
     *
     * @param currentPattern - Pattern currently being accumulated.
     * @param patterns - Target array that receives completed patterns.
     * @param issues - Target array that receives parse issues.
     */
    private flushCurrentPattern;
}
//# sourceMappingURL=AcDbPatParser.d.ts.map