import type { AcDbPatDocument } from './AcDbPatDefinition';
/**
 * Predefined hatch patterns from the classic `acad.pat` library.
 */
export declare const AcDbPredefinedAcadPat: AcDbPatDocument;
/**
 * Predefined hatch patterns from the ISO-oriented `acadiso.pat` library.
 */
export declare const AcDbPredefinedAcadIsoPat: AcDbPatDocument;
//# sourceMappingURL=AcDbPatPredefined.d.ts.map