import type { AcDbGradientName } from '../../entity/AcDbHatch';
import type { AcDbPatPattern, AcDbPatPreviewOptions } from './AcDbPatDefinition';
export type AcDbPatGradientColor = number | string;
/**
 * Optional preview options when rendering an AutoCAD hatch gradient to SVG.
 */
export interface AcDbPatGradientPreviewOptions {
    /**
     * SVG viewport width in pixels.
     */
    width?: number;
    /**
     * SVG viewport height in pixels.
     */
    height?: number;
    /**
     * First gradient color.
     *
     * A number is treated as packed RGB (`0xRRGGBB`). A string is emitted as a
     * CSS color value.
     */
    startColor?: AcDbPatGradientColor;
    /**
     * Second gradient color.
     *
     * A number is treated as packed RGB (`0xRRGGBB`). A string is emitted as a
     * CSS color value.
     */
    endColor?: AcDbPatGradientColor;
    /**
     * Background fill color shown behind the gradient rectangle.
     */
    background?: string;
    /**
     * Gradient angle in radians, matching {@link AcDbHatch.gradientAngle}.
     */
    angle?: number;
    /**
     * Relative shift applied to the gradient focus or midpoint.
     */
    shift?: number;
    /**
     * Whether the gradient uses one base color plus a shade/tint variant.
     */
    oneColorMode?: boolean;
    /**
     * Shade/tint value used in one-color mode. `0` maps to black, `0.5` keeps the
     * base color, and `1` maps to white.
     */
    shadeTintValue?: number;
}
/**
 * Renders an {@link AcDbPatPattern} into a standalone SVG preview string.
 *
 * The renderer normalizes pattern units to pixels, expands each hatch line
 * family to cover the viewport, resolves dash/gap sequences into explicit
 * segments, and emits a compact `<svg>` document.
 */
export declare class AcDbPatSvgRenderer {
    /** Numerical tolerance used to avoid division-by-zero and near-zero noise. */
    private static readonly EPSILON;
    private static gradientIdCounter;
    /**
     * Builds an SVG-local ID that avoids collisions when multiple previews are
     * injected into the same document.
     *
     * @param name - Gradient pattern name.
     * @returns Unique gradient ID.
     */
    private static nextGradientId;
    /**
     * Converts a packed RGB value to a CSS hex color.
     *
     * @param rgb - Packed RGB value.
     * @returns CSS hex color.
     */
    private static packedRgbToCss;
    /**
     * Converts either packed RGB or CSS color input to a CSS color string.
     *
     * @param color - Source color.
     * @param fallback - Color used when source is undefined.
     * @returns CSS color.
     */
    private static gradientColorToCss;
    /**
     * Computes the shade/tint variant used by one-color gradient hatches.
     *
     * @param rgb - Packed base RGB value.
     * @param shadeTintValue - Interpolation from black (`0`) through base
     * (`0.5`) to white (`1`).
     * @returns Packed RGB shade/tint value.
     */
    private static applyShadeTint;
    /**
     * Resolves the two CSS colors used by gradient stops.
     *
     * @param options - Gradient preview options.
     * @returns CSS start and end colors.
     */
    private static resolveGradientColors;
    /**
     * Converts normalized stop data to SVG `<stop>` elements.
     *
     * @param stops - Gradient stops.
     * @returns SVG stop markup.
     */
    private static renderGradientStops;
    /**
     * Gets the SVG coordinate direction for a gradient angle.
     *
     * @param angle - Angle in radians, measured in CAD coordinates.
     * @returns Unit vector in SVG coordinates.
     */
    private static getGradientVector;
    /**
     * Checks whether a pattern is the reserved AutoCAD solid-fill pattern.
     *
     * `SOLID` has no PAT line descriptors; its preview is an area fill instead
     * of generated hatch linework.
     *
     * @param pattern - Pattern to inspect.
     * @returns `true` when the pattern name resolves to `SOLID`.
     */
    private static isSolidPattern;
    /**
     * Renders an SVG background rectangle.
     *
     * @param width - SVG viewport width in pixels.
     * @param height - SVG viewport height in pixels.
     * @param background - CSS fill for the preview background.
     * @returns SVG `<rect>` markup.
     */
    private static renderBackground;
    /**
     * Estimates a representative unit length for the pattern.
     *
     * The current strategy samples delta vectors and dash lengths, removes
     * near-zero values, and uses the median as a robust scale anchor.
     *
     * @param pattern - Pattern whose geometric magnitudes are sampled.
     * @returns Estimated pattern unit size. Falls back to `1` if no usable
     * samples exist.
     */
    private static estimateUnitScale;
    /**
     * Converts a geometric segment into a single SVG `M ... L ...` path command.
     *
     * SVG Y coordinates are inverted to match the pattern coordinate convention.
     *
     * @param segment - Segment to serialize.
     * @returns SVG path fragment for the segment.
     */
    private static segmentToSvgPath;
    /**
     * Expands a hatch line and its dash definition into concrete drawable
     * segments within a finite interval.
     *
     * Dash rule:
     * - `> 0`: drawn segment
     * - `< 0`: gap
     * - `= 0`: dot (rendered as a very short segment for visibility)
     *
     * @param line - Hatch line definition containing dash sequence.
     * @param startAlong - Interval start on the line direction axis.
     * @param endAlong - Interval end on the line direction axis.
     * @param originX - Line family origin X coordinate.
     * @param originY - Line family origin Y coordinate.
     * @param dirX - Unit direction vector X component.
     * @param dirY - Unit direction vector Y component.
     * @returns Drawable segments clipped to `[startAlong, endAlong]`.
     */
    private static buildDashSegments;
    /**
     * Renders one hatch line family (parallel repetitions of the same line rule)
     * into a single SVG `<path>` element.
     *
     * @param line - Hatch line rule to expand.
     * @param maxRadius - Coverage radius used to decide repetition count and
     * drawable extent.
     * @returns SVG `<path>` markup containing all generated segments.
     */
    private static renderFamily;
    /**
     * Renders an SVG `<linearGradient>` definition.
     *
     * @param id - Gradient ID.
     * @param angle - Gradient angle in radians.
     * @param shift - Relative shift applied along the gradient axis.
     * @param extent - Coordinate extent covering the viewport.
     * @param stops - Color stops.
     * @returns SVG gradient definition.
     */
    private static renderLinearGradientDef;
    /**
     * Renders an SVG `<radialGradient>` definition.
     *
     * @param id - Gradient ID.
     * @param cx - Center X coordinate.
     * @param cy - Center Y coordinate.
     * @param radius - Gradient radius.
     * @param stops - Color stops.
     * @returns SVG gradient definition.
     */
    private static renderRadialGradientDef;
    /**
     * Builds the SVG definition for a hatch gradient pattern.
     *
     * SVG supports linear and radial gradients natively, so AutoCAD-specific
     * shapes such as CYLINDER and CURVED are represented with mirrored stops or
     * offset radial gradients.
     *
     * @param id - Gradient ID.
     * @param name - AutoCAD gradient name.
     * @param colors - Resolved gradient colors.
     * @param angle - Gradient angle in radians.
     * @param shift - Relative shift.
     * @param width - SVG viewport width.
     * @param height - SVG viewport height.
     * @returns SVG gradient definition.
     */
    private static renderGradientDef;
    /**
     * Renders a PAT pattern preview as a complete SVG document string.
     *
     * The method applies option defaults, computes an automatic unit-to-pixel
     * scale, transforms the pattern to screen space, and combines all line
     * families into one grouped stroke layer over a background rectangle.
     *
     * @param pattern - Pattern definition to render.
     * @param options - Optional preview style and size settings.
     * @returns Standalone SVG markup that can be injected directly into DOM or
     * saved as a `.svg` asset.
     */
    renderPattern(pattern: AcDbPatPattern, options?: AcDbPatPreviewOptions): string;
    /**
     * Renders an AutoCAD hatch gradient preview as a complete SVG document
     * string.
     *
     * The method uses native SVG linear/radial gradients where possible and
     * approximates AutoCAD-only gradient shapes with mirrored stops or offset
     * radial centers.
     *
     * @param name - AutoCAD gradient name.
     * @param options - Optional preview style and size settings.
     * @returns Standalone SVG markup that can be injected directly into DOM or
     * saved as a `.svg` asset.
     */
    renderGradient(name: AcDbGradientName, options?: AcDbPatGradientPreviewOptions): string;
}
//# sourceMappingURL=AcDbPatSvgRenderer.d.ts.map