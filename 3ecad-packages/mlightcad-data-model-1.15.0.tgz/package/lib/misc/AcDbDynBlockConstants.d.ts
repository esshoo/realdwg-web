/**
 * Dictionary keys and AppId names used by AutoCAD dynamic blocks.
 *
 * These strings match ObjectARX / DXF conventions so both DWG converters can
 * materialize the same data-model shape for {@link AcDbDynBlockReference}.
 */
export declare const ACDB_DYN_BLOCK_REPRESENTATION_DICT = "AcDbBlockRepresentation";
export declare const ACDB_DYN_BLOCK_REP_DATA = "AcDbRepData";
export declare const ACDB_DYN_BLOCK_ENHANCED_BLOCK = "ACAD_ENHANCEDBLOCK";
export declare const ACDB_DYN_BLOCK_REP_BTAG_APP = "AcDbBlockRepBTag";
export declare const ACDB_DYN_BLOCK_REP_ETAG_APP = "AcDbBlockRepETag";
export declare const ACDB_DYN_BLOCK_TRUE_NAME_APP = "AcDbDynamicBlockTrueName";
export declare const ACDB_DYN_BLOCK_GUID_APP = "AcDbDynamicBlockGUID";
/**
 * Returns true when `name` looks like an AutoCAD anonymous user block (`*U…`),
 * which dynamic-block representations use.
 */
export declare function acdbIsAnonymousUserBlockName(name: string | undefined | null): boolean;
//# sourceMappingURL=AcDbDynBlockConstants.d.ts.map