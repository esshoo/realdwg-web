/**
 * Rasterizes Windows metafile blobs extracted from OLE frames (WMF / EMF)
 * into browser-decodable PNG images via `@mlightcad/emf-converter`.
 *
 * AutoCAD Excel OLE previews are typically stored as CF_ENHMETAFILE / WMF
 * presentation streams. Browsers cannot decode those formats natively, so
 * viewers must convert them to PNG (or similar) before texturing.
 *
 * The converter is a static import so the data-model CJS/Vite bundle inlines
 * the (small) `@mlightcad/emf-converter` implementation.
 */
export interface AcDbOleMetafileRasterizeOptions {
    /** Maximum output width in pixels. */
    maxWidth?: number;
    /** Maximum output height in pixels. */
    maxHeight?: number;
    /**
     * DPI scale factor for higher-resolution output.
     * Defaults to `1` for CAD overlays (sharp enough without huge textures).
     */
    dpiScale?: number;
    /** Hard cap on canvas width/height. */
    maxCanvasDimension?: number;
    /** Optional Windows face-name → CSS font-family map. */
    fontFamilyMap?: Record<string, string>;
}
/**
 * Converts a WMF/EMF {@link Blob} (or raw bytes) to an `image/png` blob.
 *
 * @returns PNG blob, or `undefined` when conversion fails / canvas is unavailable.
 */
export declare function acdbRasterizeOleMetafile(input: Blob | Uint8Array, options?: AcDbOleMetafileRasterizeOptions): Promise<Blob | undefined>;
/**
 * True when `blob` looks like an OLE metafile that needs canvas rasterization
 * before it can be used as a WebGL texture.
 */
export declare function acdbOleBlobNeedsMetafileRasterization(blob: Blob): boolean;
//# sourceMappingURL=AcDbOleMetafileRasterizer.d.ts.map