/**
 * @fileoverview Heuristic in-memory size estimator for {@link AcDbDatabase}.
 *
 * Walks the ownership graph with a {@link WeakSet} to avoid cycles and estimates
 * bytes using V8-inspired constants. Results are reproducible and useful for
 * comparing drawings; they are not exact Chrome heap retained sizes.
 * Cross-check with `performance.memory` / DevTools heap snapshots when needed.
 *
 * @module AcDbMemoryEstimator
 */
import type { AcDbDatabase } from '../database/AcDbDatabase';
/**
 * Accumulated byte and object counts for one breakdown key
 * (category name or entity type name).
 */
export interface AcDbMemoryEstimateBucket {
    /** Estimated retained payload size in bytes for this key. */
    bytes: number;
    /**
     * Number of JS objects attributed to this key.
     * For entity-type buckets this is the entity instance count;
     * for category buckets it is the visited object count in that category.
     */
    count: number;
}
/**
 * Structured result returned by {@link acdbEstimateDatabaseMemory}.
 *
 * Categories typically include `sysvars`, `tables`, `entities`, `objects`,
 * `handleRegistry`, `xdata`, and optionally `transaction` / `events`.
 */
export interface AcDbMemoryEstimate {
    /** Sum of all category bytes. */
    totalBytes: number;
    /** Number of distinct JS objects visited (excluding primitives). */
    objectCount: number;
    /** Number of {@link AcDbEntity} instances visited. */
    entityCount: number;
    /**
     * Breakdown by high-level ownership category
     * (for example `entities`, `tables`, `handleRegistry`).
     */
    byCategory: Record<string, AcDbMemoryEstimateBucket>;
    /**
     * Breakdown by entity `type` name
     * (for example `Line`, `Polyline`, `Hatch`).
     */
    byEntityType: Record<string, AcDbMemoryEstimateBucket>;
}
/**
 * Options controlling which non-model graphs are included when estimating
 * {@link AcDbDatabase} memory via {@link acdbEstimateDatabaseMemory}.
 */
export interface AcDbMemoryEstimateOptions {
    /**
     * When `true`, include `transactionManager` and undo stacks.
     * Default: `false` (model body only).
     */
    includeTransactionManager?: boolean;
    /**
     * When `true`, include `events` / event managers and their listeners.
     * Default: `false`.
     */
    includeEventManagers?: boolean;
}
/**
 * Estimates the in-memory footprint of an {@link AcDbDatabase} by walking its
 * ownership graph and applying V8-inspired size heuristics.
 *
 * The estimate is reproducible and suitable for comparing drawings. It is not
 * an exact Chrome / V8 heap retained size; expect roughly ±20–30% versus
 * DevTools heap snapshots. Rendering GPU buffers and converter worker / WASM
 * heaps are not included.
 *
 * @param db - Drawing database to measure (typically after `read` / `openUri`).
 * @param options - Optional inclusion of transaction / event graphs.
 * @returns Structured estimate with category and entity-type breakdowns.
 *
 * @example
 * ```typescript
 * const report = acdbEstimateDatabaseMemory(database)
 * console.log(acdbFormatMemoryEstimate(report))
 * ```
 */
export declare function acdbEstimateDatabaseMemory(db: AcDbDatabase, options?: AcDbMemoryEstimateOptions): AcDbMemoryEstimate;
/**
 * Formats a byte count as a short human-readable string using binary units
 * (`B`, `KiB`, or `MiB`).
 *
 * @param bytes - Non-negative byte count to format.
 * @returns Formatted size string, for example `"512 B"` or `"2.00 KiB"`.
 *
 * @example
 * ```typescript
 * acdbFormatMemoryBytes(512)    // "512 B"
 * acdbFormatMemoryBytes(2048)   // "2.00 KiB"
 * ```
 */
export declare function acdbFormatMemoryBytes(bytes: number): string;
/**
 * Formats an {@link AcDbMemoryEstimate} as multi-line text for console or UI
 * output, including totals plus category and entity-type breakdowns sorted by
 * descending byte size.
 *
 * @param report - Estimate produced by {@link acdbEstimateDatabaseMemory}.
 * @returns Human-readable multi-line summary string.
 *
 * @example
 * ```typescript
 * const report = acdbEstimateDatabaseMemory(database)
 * console.log(acdbFormatMemoryEstimate(report))
 * ```
 */
export declare function acdbFormatMemoryEstimate(report: AcDbMemoryEstimate): string;
//# sourceMappingURL=AcDbMemoryEstimator.d.ts.map