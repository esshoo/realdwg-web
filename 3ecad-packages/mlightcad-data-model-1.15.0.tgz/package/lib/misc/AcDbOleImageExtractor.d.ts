/**
 * Extracts a renderable image {@link Blob} from AutoCAD OLE frame binary
 * payloads (OLE2FRAME / OLEFRAME).
 *
 * AutoCAD stores OLE 2 items as a short geometry header followed by an OLE
 * Compound File Binary (CFB) document. Embedded pictures (for example
 * "Paintbrush Picture") typically expose either:
 * - a `CONTENTS` stream containing a full BMP / PNG / JPEG file, or
 * - a `\2OlePres###` presentation stream with a CF_DIB / CF_BITMAP /
 *   CF_ENHMETAFILE / CF_METAFILEPICT payload
 *
 * Excel OLE objects almost always ship a WMF/EMF presentation in
 * `\2OlePres000`. Those metafile blobs use MIME types {@link
 * ACDB_OLE_METAFILE_WMF_MIME} / {@link ACDB_OLE_METAFILE_EMF_MIME} and must be
 * rasterized (see {@link acdbRasterizeOleMetafile}) before WebGL texturing.
 *
 * Preference order (important for regressions):
 * 1. OlePres **raster** (CF_DIB / CF_BITMAP) when present
 * 2. CONTENTS / Ole10Native / Package **raster** (Paintbrush BMP/PNG)
 * 3. OlePres **metafile** (Excel WMF/EMF presentations)
 * 4. Remaining CFB streams, then a raw-buffer signature scan
 *
 * Preferring OlePres metafiles before Ole10Native/CONTENTS breaks Paintbrush
 * OLE2FRAME entities that ship a blank-looking WMF preview alongside a real
 * BMP in `\1Ole10Native` (white rectangle, missing ink such as CJK glyphs).
 */
/**
 * Attempts to extract an image blob from OLE binary data.
 *
 * @param data - Raw OLE payload from {@link AcDbOleFrame.getOleObject}.
 * @returns A browser-decodable raster blob (`image/bmp|png|jpeg|gif`) or a
 *   metafile blob (`image/wmf|emf`), or `undefined` when nothing usable is found.
 */
export declare function acdbExtractOleImageBlob(data?: Uint8Array | null): Blob | undefined;
//# sourceMappingURL=AcDbOleImageExtractor.d.ts.map