import { AcDbObjectId } from '../base/AcDbObject';
import { AcDbDatabase } from '../database/AcDbDatabase';
/**
 * Normalized dictionary descriptor shared by DWG converters when importing
 * extension-dictionary graphs used by dynamic blocks.
 */
export interface AcDbDynBlockDictionarySource {
    handle: string;
    ownerHandle?: string;
    entries: Array<{
        name: string;
        handle: string;
    }>;
}
/**
 * Normalized representation-data descriptor (original dynamic definition handle).
 */
export interface AcDbDynBlockRepresentationSource {
    handle: string;
    ownerHandle?: string;
    /** Object id / handle of the dynamic block table record. */
    blockHandle: string;
}
export interface AcDbImportDynBlockMetadataOptions {
    dictionaries?: Iterable<AcDbDynBlockDictionarySource>;
    representationData?: Iterable<AcDbDynBlockRepresentationSource>;
}
/**
 * Imports dynamic-block dictionary / representation objects into `db`.
 *
 * Both `@mlightcad/libredwg-converter` and `@mlightcad/dwg-converter` should
 * call this after entities and block table records exist, and after setting
 * `extensionDictionary` handles on INSERTs / BTRs.
 *
 * Dictionary keys of interest:
 * - {@link ACDB_DYN_BLOCK_REPRESENTATION_DICT}
 * - {@link ACDB_DYN_BLOCK_REP_DATA}
 * - {@link ACDB_DYN_BLOCK_ENHANCED_BLOCK}
 */
export declare function acdbImportDynBlockMetadata(db: AcDbDatabase, options: AcDbImportDynBlockMetadataOptions): void;
/**
 * Resolves a soft/hard dictionary handle field from converter JSON into a
 * normalized object id, or `undefined` when absent.
 */
export declare function acdbNormalizeExtensionDictionaryId(value: unknown): AcDbObjectId | undefined;
//# sourceMappingURL=AcDbImportDynBlockMetadata.d.ts.map