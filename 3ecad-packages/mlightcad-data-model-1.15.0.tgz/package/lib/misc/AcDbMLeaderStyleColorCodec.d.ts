import { AcCmColor } from '@mlightcad/common';
/**
 * DXF raw-color type flag: inherit color from layer.
 *
 * Stored in the high byte (bits 24-31) of MLEADERSTYLE raw-color int32.
 */
export declare const RAW_COLOR_TYPE_BY_LAYER = 192;
/**
 * DXF raw-color type flag: inherit color from block.
 *
 * Stored in the high byte (bits 24-31) of MLEADERSTYLE raw-color int32.
 */
export declare const RAW_COLOR_TYPE_BY_BLOCK = 193;
/**
 * DXF raw-color type flag: explicit true color.
 *
 * Stored in the high byte (bits 24-31); payload uses low 24 bits as 0xRRGGBB.
 */
export declare const RAW_COLOR_TYPE_RGB = 194;
/**
 * DXF raw-color type flag: AutoCAD Color Index (ACI).
 *
 * Stored in the high byte (bits 24-31); payload uses low 8 bits as ACI index.
 */
export declare const RAW_COLOR_TYPE_ACI = 195;
/**
 * DXF raw-color type flag: window background color.
 *
 * This value appears in some producers; we treat it as a compatible fallback.
 */
export declare const RAW_COLOR_TYPE_WINDOW_BG = 200;
/**
 * Encodes MLEADERSTYLE color (`AcCmColor`) to DXF raw-color int32.
 *
 * Algorithm sources:
 * - AutoCAD DXF MLEADERSTYLE docs (group codes 91/93/94):
 *   https://help.autodesk.com/cloudhelp/2021/ENU/AutoCAD-DXF/files/GUID-0E489B69-17A4-4439-8505-9DCE032100B4.htm
 * - ezdxf reference implementation (`encode_raw_color`):
 *   https://raw.githubusercontent.com/mozman/ezdxf/master/src/ezdxf/colors.py
 */
export declare function acdbEncodeMLeaderStyleRawColor(color: AcCmColor): number;
/**
 * Decodes MLEADERSTYLE DXF raw-color int32 to `AcCmColor`.
 *
 * Raw-color is a packed 32-bit signed integer:
 * - high byte (bits 24-31): color type flag
 * - low bytes: payload
 *
 * Why values often look negative:
 * - DXF stores this as signed int32; high-byte flags >= 0x80 become negative decimals.
 *
 * Algorithm sources:
 * - AutoCAD DXF MLEADERSTYLE docs (group codes 91/93/94):
 *   https://help.autodesk.com/cloudhelp/2021/ENU/AutoCAD-DXF/files/GUID-0E489B69-17A4-4439-8505-9DCE032100B4.htm
 * - ezdxf reference implementation (`decode_raw_color_int`):
 *   https://raw.githubusercontent.com/mozman/ezdxf/master/src/ezdxf/colors.py
 */
export declare function acdbDecodeMLeaderStyleRawColor(rawColor: number): AcCmColor;
//# sourceMappingURL=AcDbMLeaderStyleColorCodec.d.ts.map