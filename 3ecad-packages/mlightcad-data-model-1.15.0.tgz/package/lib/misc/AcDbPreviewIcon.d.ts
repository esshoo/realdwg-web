/**
 * Converts AutoCAD block PreviewIcon bytes to a browser-displayable BMP data URL.
 *
 * PreviewIcon data is typically a Device-Independent Bitmap (DIB): a memory copy
 * of {@link https://learn.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfo | BITMAPINFO}
 * followed by pixel bits (DXF BLOCK_RECORD group 310). A full BMP file also has a
 * 14-byte BITMAPFILEHEADER; this helper prepends that header when needed.
 *
 * @param data - Raw PreviewIcon bytes, or an empty buffer when none exist.
 * @returns A `data:image/bmp;base64,...` URL, or `undefined` when the payload is empty/invalid.
 */
export declare function acdbPreviewIconToDataUrl(data: Uint8Array | undefined | null): string | undefined;
/**
 * Converts drawing thumbnail bytes to a browser-displayable data URL.
 *
 * Accepts PNG, JPEG, full BMP files, and DIB payloads (same wrapping as
 * {@link acdbPreviewIconToDataUrl}). Used for DXF `THUMBNAILIMAGE` and DWG
 * preview bitmaps (`Database.ThumbnailBitmap`).
 *
 * @param data - Raw thumbnail bytes, or an empty buffer when none exist.
 * @returns A data URL, or `undefined` when the payload is empty/unsupported.
 */
export declare function acdbThumbnailImageToDataUrl(data: Uint8Array | undefined | null): string | undefined;
//# sourceMappingURL=AcDbPreviewIcon.d.ts.map