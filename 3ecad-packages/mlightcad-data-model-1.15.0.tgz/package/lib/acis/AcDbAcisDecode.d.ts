import type { AcDbAcisModel } from './AcDbAcisEntities';
/**
 * Finds the byte offset of an ACIS/ASM binary signature within `data`.
 *
 * @param data - Raw SAB/ASM byte payload.
 * @returns Zero-based offset, or `-1` when no known signature is found.
 */
export declare function acdbFindAcisSabSignatureOffset(data: Uint8Array): number;
/**
 * Returns true when `data` begins with (or contains) an ACIS/ASM binary signature.
 *
 * @param data - Raw SAB/ASM byte payload.
 */
export declare function acdbIsAcisSabPayload(data: Uint8Array): boolean;
/**
 * Decode an ACIS/ASM SAB byte stream into a resolved B-rep model graph.
 *
 * @param data - Raw SAB/ASM byte payload (may include leading non-ACIS bytes).
 * @returns Resolved model graph, or `null` for empty payloads, missing signatures,
 * or malformed streams.
 */
export declare function acdbDecodeAcisModel(data: Uint8Array): AcDbAcisModel | null;
//# sourceMappingURL=AcDbAcisDecode.d.ts.map