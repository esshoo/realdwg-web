import type { AcDbAcisModel, AcDbAcisNode } from './AcDbAcisEntities';
import type { AcDbAcisSabVector } from './AcDbAcisSab';
/** 3D position or direction vector `[x, y, z]`. */
export type AcDbAcisVec3 = AcDbAcisSabVector;
/** Known analytic curve kinds extracted from ACIS edge geometry. */
export type AcDbAcisCurveKind = 'straight' | 'ellipse' | 'intcurve' | 'unknown';
/** Known analytic surface kinds extracted from ACIS face geometry. */
export type AcDbAcisSurfaceKind = 'plane' | 'cone' | 'torus' | 'sphere' | 'spline' | 'unknown';
/** Parameters for a straight (line) ACIS curve. */
export interface AcDbAcisStraightCurveParams {
    readonly kind: 'straight';
    /** Line origin in model space. */
    readonly origin: AcDbAcisVec3;
    /** Unit direction vector along the line. */
    readonly direction: AcDbAcisVec3;
}
/** Parameters for an ellipse (or circular arc) ACIS curve. */
export interface AcDbAcisEllipseCurveParams {
    readonly kind: 'ellipse';
    /** Ellipse center in model space. */
    readonly center: AcDbAcisVec3;
    /** Plane normal of the ellipse. */
    readonly normal: AcDbAcisVec3;
    /** Major-axis vector (length defines semi-major axis). */
    readonly majorAxis: AcDbAcisVec3;
    /** Ratio of minor to major axis length. */
    readonly ratio: number;
}
/**
 * An interpolated/intersection spline curve. `controlPoints` is the `nubs`/`nurbs`
 * B-spline control polygon extracted from the record's subtype block — a usable
 * polyline approximation of the curve (the first/last control point coincide with
 * the edge's start/end vertices). Empty when the subtype is a `nullbs` placeholder
 * or the control polygon could not be read. Full NURBS evaluation is out of scope.
 */
export interface AcDbAcisIntCurveParams {
    readonly kind: 'intcurve';
    /** B-spline control polygon used as a polyline wireframe approximation. */
    readonly controlPoints: readonly AcDbAcisVec3[];
}
/** Discriminated union of parsed ACIS curve parameters. */
export type AcDbAcisCurveParams = AcDbAcisStraightCurveParams | AcDbAcisEllipseCurveParams | AcDbAcisIntCurveParams | {
    readonly kind: 'unknown';
};
/** Parameters for a plane ACIS surface. */
export interface AcDbAcisPlaneParams {
    readonly kind: 'plane';
    /** Point on the plane. */
    readonly origin: AcDbAcisVec3;
    /** Outward plane normal. */
    readonly normal: AcDbAcisVec3;
    /** Optional in-plane U direction. */
    readonly uDir?: AcDbAcisVec3;
}
/** Parameters for a cone (or cylinder) ACIS surface. */
export interface AcDbAcisConeParams {
    readonly kind: 'cone';
    /** Apex or base reference point. */
    readonly origin: AcDbAcisVec3;
    /** Axis direction. */
    readonly axis: AcDbAcisVec3;
    /** Major-axis vector in the base plane. */
    readonly majorAxis: AcDbAcisVec3;
    /** Ratio of minor to major axis in the base ellipse. */
    readonly ratio: number;
    /** Sine of the half-angle between axis and surface generator. */
    readonly sineAngle: number;
    /** Cosine of the half-angle between axis and surface generator. */
    readonly cosineAngle: number;
}
/** Parameters for a torus ACIS surface. */
export interface AcDbAcisTorusParams {
    readonly kind: 'torus';
    /** Torus center in model space. */
    readonly center: AcDbAcisVec3;
    /** Revolution axis direction. */
    readonly axis: AcDbAcisVec3;
    /** Distance from center to tube centerline. */
    readonly majorRadius: number;
    /** Tube radius. */
    readonly minorRadius: number;
}
/** Parameters for a sphere ACIS surface. */
export interface AcDbAcisSphereParams {
    readonly kind: 'sphere';
    /** Sphere center in model space. */
    readonly center: AcDbAcisVec3;
    /** Sphere radius. */
    readonly radius: number;
    /** Reference U direction on the sphere. */
    readonly uDir: AcDbAcisVec3;
    /** Pole axis direction. */
    readonly poleAxis: AcDbAcisVec3;
}
/** Discriminated union of parsed ACIS surface parameters. */
export type AcDbAcisSurfaceParams = AcDbAcisPlaneParams | AcDbAcisConeParams | AcDbAcisTorusParams | AcDbAcisSphereParams | {
    readonly kind: 'unknown';
};
/**
 * A B-rep vertex with its resolved 3D point location.
 */
export interface AcDbAcisVertex {
    /** Index of the source `vertex` node in the model graph. */
    readonly nodeIndex: number;
    /** Resolved 3D point location, or `null` when the pointer chain is broken. */
    readonly point: AcDbAcisVec3 | null;
}
/**
 * A B-rep edge with resolved endpoint locations and optional curve parameters.
 */
export interface AcDbAcisEdge {
    /** Index of the source `edge` node in the model graph. */
    readonly nodeIndex: number;
    /** Resolved start vertex location. */
    readonly start: AcDbAcisVec3 | null;
    /** Resolved end vertex location. */
    readonly end: AcDbAcisVec3 | null;
    /** Parsed analytic curve kind. */
    readonly curveType: AcDbAcisCurveKind;
    /** Parsed curve parameters when the subtype is recognized. */
    readonly curve?: AcDbAcisCurveParams;
}
/**
 * One boundary loop on a B-rep face.
 */
export interface AcDbAcisFaceLoop {
    /** Index of the source `loop` node in the model graph. */
    readonly nodeIndex: number;
    /** Number of coedges in the loop ring. */
    readonly coedgeCount: number;
}
/**
 * A B-rep face with surface type/parameters and boundary loop structure.
 */
export interface AcDbAcisFace {
    /** Index of the source `face` node in the model graph. */
    readonly nodeIndex: number;
    /** Parsed analytic surface kind. */
    readonly surfaceType: AcDbAcisSurfaceKind;
    /** Parsed surface parameters when the subtype is recognized. */
    readonly surface?: AcDbAcisSurfaceParams;
    /** Ordered boundary loops on this face. */
    readonly loops: readonly AcDbAcisFaceLoop[];
}
/** Axis-aligned bounding box over a set of 3D points. */
export interface AcDbAcisBBox {
    /** Minimum corner `[x, y, z]`. */
    readonly min: AcDbAcisVec3;
    /** Maximum corner `[x, y, z]`. */
    readonly max: AcDbAcisVec3;
}
/** An indexed triangle mesh for one face: shared `positions` + `triangles` (index triples). */
export interface AcDbAcisTriangleMesh {
    /** Source surface kind for this mesh. */
    readonly surfaceType: AcDbAcisSurfaceKind;
    /** Shared vertex positions referenced by `triangles`. */
    readonly positions: readonly AcDbAcisVec3[];
    /** Triangle index triples into `positions`. */
    readonly triangles: readonly (readonly [number, number, number])[];
}
/**
 * Tessellation of a body's faces.
 *
 * - `faces`: legacy flat-polygon rings — one ordered ring per plane-surface face
 *   bounded entirely by straight edges (kept for existing consumers).
 * - `triangles`: indexed triangle meshes covering plane faces (fan-triangulated)
 *   **and** the analytic curved faces — `cone` (incl. cylinders) and `torus`,
 *   meshed as full surfaces of revolution with the v-range taken from each
 *   face's loops. Correct for full-revolution faces (the common case);
 *   u-partial curved faces are approximated (flagged in `diagnostics`).
 *   sphere/spline surfaces are not meshed.
 */
export interface AcDbAcisMesh {
    /** Legacy flat polygon rings for plane faces bounded by straight edges. */
    readonly faces: readonly (readonly AcDbAcisVec3[])[];
    /** Indexed triangle meshes for plane and selected curved faces. */
    readonly triangles: readonly AcDbAcisTriangleMesh[];
    /** Best-effort tessellation notes and approximations. */
    readonly diagnostics: readonly string[];
}
/** Options for {@link tessellateAcDbAcisGeometry}. */
export interface AcDbAcisTessellationOptions {
    /** Samples per full revolution for curved faces (≥3). Default 32. */
    readonly segments?: number;
}
/**
 * Extracted B-rep geometry from a decoded ACIS model.
 */
export interface AcDbAcisGeometry {
    /** Resolved B-rep vertices. */
    readonly vertices: readonly AcDbAcisVertex[];
    /** Resolved B-rep edges with optional curve parameters. */
    readonly edges: readonly AcDbAcisEdge[];
    /** Resolved B-rep faces with optional surface parameters. */
    readonly faces: readonly AcDbAcisFace[];
    /** Wireframe bounding box over resolved vertex points, or null when none resolve. */
    readonly bbox: AcDbAcisBBox | null;
    /** Best-effort notes: dangling pointers, degenerate edges, unhandled subtypes. */
    readonly diagnostics: readonly string[];
}
/**
 * Summary statistics over extracted ACIS geometry.
 */
export interface AcDbAcisGeometrySummary {
    /** Number of resolved vertices. */
    readonly vertexCount: number;
    /** Number of resolved edges. */
    readonly edgeCount: number;
    /** Number of resolved faces. */
    readonly faceCount: number;
    /** Total boundary loops across all faces. */
    readonly loopCount: number;
    /** Histogram of parsed curve kinds. */
    readonly curveTypes: Readonly<Record<AcDbAcisCurveKind, number>>;
    /** Histogram of parsed surface kinds. */
    readonly surfaceTypes: Readonly<Record<AcDbAcisSurfaceKind, number>>;
    /** Bounding box over resolved vertices, if any. */
    readonly bbox: AcDbAcisBBox | null;
    /** Number of diagnostic messages. */
    readonly diagnosticCount: number;
    /** Diagnostic messages from geometry extraction. */
    readonly diagnostics: readonly string[];
}
/**
 * Parses analytic surface parameters from a `-surface` ACIS node.
 *
 * @param surface - Resolved surface node from an ACIS model graph.
 * @returns Discriminated surface parameters, or `{ kind: 'unknown' }`.
 */
export declare function acdbAcisParseSurfaceParams(surface: AcDbAcisNode): AcDbAcisSurfaceParams;
/**
 * Extract the B-rep geometry from a decoded ACIS model. Never throws; unresolved
 * topology/geometry is reported via `diagnostics` and `'unknown'` type labels.
 *
 * Coordinates are returned in model space: each entity is mapped by its owning
 * body's `transform` (multi-body models with distinct transforms are supported).
 *
 * @param model - Resolved ACIS model graph.
 * @returns Extracted vertices, edges, faces, bounding box, and diagnostics.
 */
export declare function acdbExtractAcisGeometry(model: AcDbAcisModel): AcDbAcisGeometry;
/**
 * Reads the curve parameter interval carried on an `edge` record (first two doubles).
 *
 * @param edge - Resolved `edge` node from an ACIS model graph.
 * @returns Parameter interval `[t0, t1]`, or `null` when unavailable.
 */
export declare function acdbAcisEdgeParamBounds(edge: AcDbAcisNode): [number, number] | null;
/**
 * Sample an ellipse-curve arc over its parameter interval.
 *
 * @param params - Parsed ellipse curve parameters.
 * @param t0 - Start parameter in radians.
 * @param t1 - End parameter in radians.
 * @param samples - Number of interior segments (≥1).
 * @returns Sampled points along the arc, including both endpoints.
 */
export declare function acdbSampleAcisEllipseArc(params: AcDbAcisEllipseCurveParams, t0: number, t1: number, samples: number): AcDbAcisVec3[];
/**
 * Sample wireframe circles for a sphere surface (latitude/longitude-style rings).
 *
 * @param params - Parsed sphere surface parameters.
 * @param segments - Approximate number of samples per full ring (default 16).
 * @returns Closed polylines forming a sphere wireframe scaffold.
 */
export declare function acdbSampleAcisSphereWireframe(params: AcDbAcisSphereParams, segments?: number): AcDbAcisVec3[][];
//# sourceMappingURL=AcDbAcisGeometry.d.ts.map