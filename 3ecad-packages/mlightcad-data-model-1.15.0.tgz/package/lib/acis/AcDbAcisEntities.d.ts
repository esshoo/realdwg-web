import type { AcDbAcisSabData, AcDbAcisSabHeader, AcDbAcisSabRecord, AcDbAcisSabVector } from './AcDbAcisSab';
/**
 * One node in the resolved ACIS B-rep entity DAG.
 * Pointers in the source record are resolved to references to other nodes.
 */
export interface AcDbAcisNode {
    /** Zero-based index of this node in the model's record list. */
    readonly index: number;
    /** ACIS entity type name, e.g. `"body"`, `"edge"`, `"plane-surface"`. */
    readonly type: string;
    /** Raw SAB record backing this node. */
    readonly record: AcDbAcisSabRecord;
    /** Resolved pointer targets from this record's tokens. */
    readonly refs: readonly (AcDbAcisNode | null)[];
}
/**
 * Resolved ACIS/ASM B-rep model graph built from parsed SAB data.
 */
export interface AcDbAcisModel {
    /** Parsed SAB file header metadata. */
    readonly header: AcDbAcisSabHeader;
    /** All resolved entity nodes in record order. */
    readonly nodes: readonly AcDbAcisNode[];
    /** Top-level `body` entity nodes. */
    readonly bodies: readonly AcDbAcisNode[];
    /** Count of nodes per entity type name. */
    readonly typeCounts: ReadonlyMap<string, number>;
    /** Returns all nodes whose entity type matches `type`. */
    nodesOfType(type: string): readonly AcDbAcisNode[];
    /** Collects 3D locations from all `point` entity records. */
    pointLocations(): readonly AcDbAcisSabVector[];
}
/**
 * Builds a resolved B-rep DAG from parsed SAB data by wiring pointer tokens
 * between records.
 *
 * @param sab - Parsed SAB header and record list from {@link acdbParseAcisSab}.
 * @returns Resolved model graph with indexed nodes and type-based lookups.
 */
export declare function acdbBuildAcisModel(sab: AcDbAcisSabData): AcDbAcisModel;
//# sourceMappingURL=AcDbAcisEntities.d.ts.map