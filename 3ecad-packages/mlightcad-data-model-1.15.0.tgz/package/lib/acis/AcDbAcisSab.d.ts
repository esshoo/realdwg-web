/**
 * SAB tag bytes (ezdxf `Tags`).
 * Each tag identifies the type of the next value in a SAB record stream.
 */
export declare const AcDbAcisSabTag: {
    readonly NoType: 0;
    readonly Byte: 1;
    readonly Char: 2;
    readonly Short: 3;
    readonly Int: 4;
    readonly Float: 5;
    readonly Double: 6;
    readonly Str: 7;
    readonly Str2: 8;
    readonly Str3: 9;
    readonly BoolTrue: 10;
    readonly BoolFalse: 11;
    readonly Pointer: 12;
    readonly EntityType: 13;
    readonly EntityTypeEx: 14;
    readonly SubtypeStart: 15;
    readonly SubtypeEnd: 16;
    readonly RecordEnd: 17;
    readonly LiteralStr: 18;
    readonly LocationVec: 19;
    readonly DirectionVec: 20;
    readonly Enum: 21;
    readonly Unknown0x17: 23;
};
/** A 3D vector tuple `[x, y, z]` as stored in SAB location/direction tags. */
export type AcDbAcisSabVector = readonly [number, number, number];
/** Possible decoded values for a single SAB field token. */
export type AcDbAcisSabTokenValue = number | boolean | string | AcDbAcisSabVector;
/**
 * One decoded field token from a SAB record stream.
 */
export interface AcDbAcisSabToken {
    /** SAB tag byte identifying the value type. */
    readonly tag: number;
    /** Decoded field value. */
    readonly value: AcDbAcisSabTokenValue;
}
/**
 * One ACIS entity record from a SAB stream.
 */
export interface AcDbAcisSabRecord {
    /** Record identity = the first entity-type, e.g. `"body"`, `"plane-surface"`. */
    readonly type: string;
    /**
     * All field tokens in wire order, including entity-type tokens (the first is
     * the record identity; later ones name nested subtypes, e.g. an
     * `intcurve-curve`'s `nullbs` geometry).
     */
    readonly tokens: readonly AcDbAcisSabToken[];
}
/**
 * Header metadata parsed from the start of a SAB stream.
 */
export interface AcDbAcisSabHeader {
    /** File signature, e.g. `"ACIS BinaryFile"` or `"ASM BinaryFile4"`. */
    readonly signature: string;
    /** SAB format version number. */
    readonly version: number;
    /** Total record count declared in the header. */
    readonly numRecords: number;
    /** Entity count declared in the header. */
    readonly numEntities: number;
    /** Header flags bitmask. */
    readonly flags: number;
    /** Product identifier string. */
    readonly productId: string;
    /** ACIS kernel version string. */
    readonly acisVersion: string;
    /** Creation timestamp string from the SAB header. */
    readonly creationDate: string;
    /** Model units expressed in millimeters. */
    readonly unitsInMm: number;
    /** Resolution tolerance from the SAB header. */
    readonly resTol: number;
    /** Normal tolerance from the SAB header. */
    readonly norTol: number;
}
/**
 * Fully parsed SAB payload: file header plus the ordered record list.
 */
export interface AcDbAcisSabData {
    /** Parsed SAB file header. */
    readonly header: AcDbAcisSabHeader;
    /** Ordered list of decoded entity records. */
    readonly records: readonly AcDbAcisSabRecord[];
}
/**
 * Decode a byte-true SAB stream into a header + record list. Reading stops at
 * the `End-of-(ACIS|ASM)-data` record (inclusive) or when the data is exhausted.
 *
 * @param data - Raw SAB byte stream starting at (or containing) a known signature.
 * @returns Parsed header and records.
 * @throws `RangeError` on a malformed or truncated stream.
 */
export declare function acdbParseAcisSab(data: Uint8Array): AcDbAcisSabData;
//# sourceMappingURL=AcDbAcisSab.d.ts.map