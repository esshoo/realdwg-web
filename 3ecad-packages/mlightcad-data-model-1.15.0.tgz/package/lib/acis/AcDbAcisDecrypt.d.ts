/**
 * Decrypts obfuscated ACIS SAT text stored in DXF group codes 1 and 3.
 *
 * AutoCAD applies `chr(159 - ord(c))` to every character above ASCII space.
 * See LibreDWG `dec_sat.pl` and the DXF reference for 3DSOLID/REGION/BODY.
 */
/**
 * Decrypts an obfuscated SAT fragment from a DXF group 1 or 3 value.
 *
 * @param encrypted - Obfuscated SAT fragment.
 */
export declare function acdbDecryptAcisData(encrypted: string): string;
/**
 * Returns true when `data` looks like encrypted ACIS rather than plain SAT/ASM
 * text (which typically starts with a version number or "ACIS"/"ASM").
 *
 * @param data - Raw group 1/3 value before decryption.
 */
export declare function acdbIsEncryptedAcisData(data: string): boolean;
/**
 * Decrypts ACIS data when it is still in the DXF obfuscated form; otherwise
 * returns the input unchanged.
 *
 * @param data - Raw or already-decrypted SAT fragment.
 */
export declare function acdbNormalizeAcisData(data: string): string;
/**
 * Decrypts each SAT line and joins them with `\n`.
 *
 * @param lines - One logical SAT line per group-code 1 (group 3 fragments are
 *   already stitched onto the preceding line).
 */
export declare function acdbJoinAcisPayloadLines(lines: readonly string[]): string;
/**
 * Stitches group-code 1/3 SAT fragments: group 1 starts a new SAT line and
 * group 3 continues the previous line (255-character splits).
 *
 * @param lines - Mutable accumulator for logical SAT lines.
 * @param code - DXF group code (1 or 3).
 * @param value - Raw group value to append.
 */
export declare function acdbAppendAcisPayloadFragment(lines: string[], code: 1 | 3, value: string): void;
/**
 * Joins encrypted ACSH OBJECT group-1 chunks (no newlines between chunks).
 *
 * @param chunks - Ordered group 1/3 fragments from an ACSH OBJECT entry.
 */
export declare function acdbJoinAcisObjectChunks(chunks: readonly string[]): string;
//# sourceMappingURL=AcDbAcisDecrypt.d.ts.map