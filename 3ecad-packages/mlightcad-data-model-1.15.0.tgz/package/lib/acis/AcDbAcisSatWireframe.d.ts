/**
 * Best-effort wireframe extraction from SAT/ASM text (non-SAB) payloads.
 * Used when ACSH history provides inline text rather than ACDSDATA binary.
 */
/**
 * Extract wireframe segments from a SAT text stream by matching common curve
 * records. This is a fallback when SAB decoding is unavailable.
 *
 * Curve geometry is sampled in body space, then mapped through the shared body
 * `transform` when one can be resolved.
 *
 * @param satText - Plain SAT/ASM text payload.
 * @returns Flat `Float32Array` of line-segment endpoint pairs (`[x,y,z,x,y,z,...]`).
 */
export declare function acdbAcisWireframeSegmentsFromSatText(satText: string): Float32Array;
//# sourceMappingURL=AcDbAcisSatWireframe.d.ts.map