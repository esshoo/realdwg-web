/**
 * ACIS body `transform` entity parsing and application.
 *
 * Each `body` may reference a `transform` that maps body-space geometry into
 * model space: `p' = scale * (x*px + y*py + z*pz) + translation`. Wireframe
 * extraction must apply this or solids appear far from sibling 2D entities
 * (common when ACIS points stay in a pre-block coordinate frame).
 */
import type { AcDbAcisModel, AcDbAcisNode } from './AcDbAcisEntities';
import type { AcDbAcisSabVector } from './AcDbAcisSab';
/** Affine transform carried by an ACIS `transform` entity. */
export interface AcDbAcisAffineTransform {
    /** Image of the unit X axis. */
    readonly xAxis: AcDbAcisSabVector;
    /** Image of the unit Y axis. */
    readonly yAxis: AcDbAcisSabVector;
    /** Image of the unit Z axis. */
    readonly zAxis: AcDbAcisSabVector;
    /** Translation applied after rotation/scale. */
    readonly translation: AcDbAcisSabVector;
    /** Uniform scale factor. */
    readonly scale: number;
}
/**
 * Returns the identity body transform.
 */
export declare function acdbAcisIdentityTransform(): AcDbAcisAffineTransform;
/**
 * Returns true when two affine transforms are numerically equal.
 *
 * @param a - First transform.
 * @param b - Second transform.
 */
export declare function acdbAcisTransformsEqual(a: AcDbAcisAffineTransform, b: AcDbAcisAffineTransform): boolean;
/**
 * Parses an ACIS `transform` node into an affine transform.
 *
 * SAB layout (after entity-type / pointers): three axis direction vectors,
 * one translation vector, then a scale double. Returns `null` when the record
 * does not carry four vectors.
 *
 * @param node - Resolved `transform` entity node.
 */
export declare function acdbAcisParseTransform(node: AcDbAcisNode): AcDbAcisAffineTransform | null;
/**
 * Returns the affine transform referenced by a `body` node, or identity when
 * the body has no resolvable `transform`.
 *
 * @param body - Resolved `body` entity node.
 */
export declare function acdbAcisTransformFromBody(body: AcDbAcisNode): AcDbAcisAffineTransform;
/**
 * Returns true when `transform` is (numerically) the identity.
 *
 * @param transform - Affine transform to test.
 */
export declare function acdbAcisTransformIsIdentity(transform: AcDbAcisAffineTransform): boolean;
/**
 * Transforms a point: `scale * (x*px + y*py + z*pz) + translation`.
 *
 * @param point - Body-space point.
 * @param transform - Body transform.
 */
export declare function acdbAcisTransformPoint(point: AcDbAcisSabVector, transform: AcDbAcisAffineTransform): AcDbAcisSabVector;
/**
 * Transforms a direction / free vector (rotation + scale, no translation).
 *
 * @param direction - Body-space direction.
 * @param transform - Body transform.
 */
export declare function acdbAcisTransformDirection(direction: AcDbAcisSabVector, transform: AcDbAcisAffineTransform): AcDbAcisSabVector;
/**
 * Walks each body DAG and records the owning body's transform per node index.
 *
 * Attribute entities are skipped so owner back-pointers cannot cross bodies.
 * Shared nodes keep the first body's transform.
 *
 * @param model - Resolved ACIS model graph.
 */
export declare function acdbAcisBuildNodeTransforms(model: AcDbAcisModel): ReadonlyMap<number, AcDbAcisAffineTransform>;
/**
 * Picks a single body transform shared by every body in the model.
 *
 * Returns identity when there is no body, or when bodies disagree on
 * transform (callers that need per-body mapping should use
 * {@link acdbAcisBuildNodeTransforms}).
 *
 * @param model - Resolved ACIS model graph.
 */
export declare function acdbAcisModelSpaceTransform(model: AcDbAcisModel): AcDbAcisAffineTransform;
/**
 * Applies an affine transform to a flat wireframe segment buffer in place
 * style (returns a new buffer).
 *
 * @param segments - `[x,y,z,x,y,z,...]` endpoint pairs.
 * @param transform - Transform to apply to every endpoint.
 */
export declare function acdbAcisTransformSegments(segments: Float32Array, transform: AcDbAcisAffineTransform): Float32Array;
//# sourceMappingURL=AcDbAcisTransform.d.ts.map