import type { AcDbAcisModel } from './AcDbAcisEntities';
import { type AcDbAcisGeometry } from './AcDbAcisGeometry';
/**
 * Converts extracted ACIS B-rep geometry into line-segment endpoint pairs
 * suitable for {@link AcGiRenderer.lineSegments}.
 *
 * @param geometry - Geometry extracted from a decoded ACIS model.
 * @param model - Optional source model used to read edge parameter bounds.
 * @returns Flat `Float32Array` of segment endpoint pairs.
 */
export declare function acdbAcisWireframeSegmentsFromGeometry(geometry: AcDbAcisGeometry, model?: AcDbAcisModel): Float32Array;
/**
 * Decodes a SAB byte stream and returns wireframe line segments, or `null`
 * when decoding fails or no drawable geometry is present.
 *
 * @param sabBytes - Raw SAB/ASM binary payload.
 * @returns Wireframe segment buffer, or `null` when nothing drawable is found.
 */
export declare function acdbAcisWireframeSegmentsFromSab(sabBytes: Uint8Array): Float32Array | null;
//# sourceMappingURL=AcDbAcisWireframe.d.ts.map