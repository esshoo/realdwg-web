import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbEntity } from './AcDbEntity';
/**
 * Represents a proxy entity for custom objects not natively supported by the
 * host application.
 *
 * When AutoCAD loads a drawing that contains custom ObjectARX entities whose
 * class definitions are unavailable, those objects are stored as
 * `ACAD_PROXY_ENTITY` records. Each proxy entity carries metadata about the
 * original class and a binary **proxy graphic** stream that encodes drawable
 * primitives (lines, arcs, text, and so on).
 *
 * {@link subWorldDraw} decodes that stream through {@link AcDbProxyGraphic}
 * and renders the contained primitives via {@link AcGiRenderer}, allowing
 * viewers such as cad-viewer to display third-party objects without the
 * original ARX module.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbProxyEntity
 *
 * @example
 * ```typescript
 * const proxy = new AcDbProxyEntity()
 * proxy.originalDxfName = 'AECC_TIN_SURFACE'
 * proxy.setProxyGraphic(binaryData)
 * const drawable = proxy.subWorldDraw(renderer)
 * ```
 */
export declare class AcDbProxyEntity extends AcDbEntity {
    /**
     * The runtime entity type name used by {@link AcDbEntity.type}.
     *
     * Always `'ProxyEntity'`.
     */
    static typeName: string;
    /**
     * Gets the DXF entity type name written to and read from drawing files.
     *
     * @returns The literal `'ACAD_PROXY_ENTITY'`.
     */
    get dxfTypeName(): string;
    /**
     * Original DXF entity name of the proxied class.
     *
     * Stored in DXF group code **1**. Example: `'AECC_TIN_SURFACE'`.
     */
    private _originalDxfName;
    /**
     * Original ObjectARX class name of the proxied object.
     *
     * Stored in DXF group code **3** when present.
     */
    private _originalClassName;
    /**
     * Registered application name that created the proxied object.
     *
     * Stored in DXF extended-data group code **1001** when present.
     */
    private _applicationName;
    /**
     * Proxy-entity class identifier assigned by the creating application.
     *
     * Stored in DXF group code **90**. Always `498` for `AcDbProxyEntity`.
     */
    private _proxyEntityClassId;
    /**
     * Application entity class ID from the CLASSES section order (500+).
     *
     * Stored in DXF group code **91**.
     */
    private _applicationEntityClassId;
    /**
     * Object drawing format when the custom object became a proxy.
     *
     * Stored in DXF group code **95**. Low word is AcDbDwgVersion; high word is
     * MaintenanceReleaseVersion.
     */
    private _objectDrawingFormat;
    /**
     * Original custom object data format.
     *
     * Stored in DXF group code **70**: `0` = DWG, `1` = DXF.
     */
    private _originalDataFormat;
    /**
     * Raw binary proxy-graphics payload.
     *
     * Length is stored in DXF group code **160**; the bytes themselves are
     * serialized as hexadecimal strings in group code **310** chunks.
     */
    private _proxyGraphic?;
    /**
     * Optional entity-origin anchor points associated with the proxy entity.
     *
     * Used at draw time for grips; not written with group code **92** (that code
     * is reserved for graphics-data size in classic DXF).
     */
    private _entityOrigins;
    /**
     * Cumulative world-space transform applied at draw time.
     *
     * The proxy-graphic byte stream is left unchanged; editor operations such as
     * MOVE, COPY, and ROTATE update this matrix instead of rewriting the stream.
     */
    private _worldTransform;
    /**
     * Gets the original DXF name of the proxied entity class.
     *
     * Mirrors the ObjectARX original-class DXF name and corresponds to DXF
     * group code **1**.
     *
     * @returns The proxied class DXF name, or an empty string when unset.
     */
    get originalDxfName(): string;
    /**
     * Sets the original DXF name of the proxied entity class.
     *
     * @param value - Proxied class DXF name (DXF group code **1**).
     */
    set originalDxfName(value: string);
    /**
     * Gets the original ObjectARX class name of the proxied object.
     *
     * Corresponds to DXF group code **3** when exported.
     *
     * @returns The ObjectARX class name, or an empty string when unset.
     */
    get originalClassName(): string;
    /**
     * Sets the original ObjectARX class name of the proxied object.
     *
     * @param value - ObjectARX class name (DXF group code **3**).
     */
    set originalClassName(value: string);
    /**
     * Gets the registered application name that created the proxied object.
     *
     * Corresponds to DXF extended-data group code **1001** when exported.
     *
     * @returns The creating application name, or an empty string when unset.
     */
    get applicationName(): string;
    /**
     * Sets the registered application name that created the proxied object.
     *
     * @param value - Application name (DXF group code **1001**).
     */
    set applicationName(value: string);
    /**
     * Gets the proxy-entity class identifier.
     *
     * Corresponds to DXF group code **90**.
     *
     * @returns The class identifier assigned by the creating application.
     */
    get proxyEntityClassId(): number;
    /**
     * Sets the proxy-entity class identifier.
     *
     * @param value - Class identifier (DXF group code **90**).
     */
    set proxyEntityClassId(value: number);
    /**
     * Gets the application entity class ID (CLASSES section order, 500+).
     *
     * Corresponds to DXF group code **91**.
     */
    get applicationEntityClassId(): number;
    /**
     * Sets the application entity class ID.
     *
     * @param value - Class ID from CLASSES section order (DXF group code **91**).
     */
    set applicationEntityClassId(value: number);
    /**
     * Gets the object drawing format (DXF group code **95**).
     */
    get objectDrawingFormat(): number;
    /**
     * Sets the object drawing format (DXF group code **95**).
     *
     * @param value - Packed AcDbDwgVersion / MaintenanceReleaseVersion.
     */
    set objectDrawingFormat(value: number);
    /**
     * Alias of {@link objectDrawingFormat} for older callers.
     *
     * @deprecated Use {@link objectDrawingFormat}.
     */
    get graphicsMetafileType(): number;
    /**
     * Alias of {@link objectDrawingFormat} for older callers.
     *
     * @deprecated Use {@link objectDrawingFormat}.
     */
    set graphicsMetafileType(value: number);
    /**
     * Gets the original custom object data format (DXF group code **70**).
     *
     * @returns `0` for DWG format, `1` for DXF format.
     */
    get originalDataFormat(): number;
    /**
     * Sets the original custom object data format (DXF group code **70**).
     *
     * @param value - `0` = DWG, `1` = DXF.
     */
    set originalDataFormat(value: number);
    /**
     * Gets the decoded proxy-graphics binary payload.
     *
     * @returns A copy of the stored bytes, or `undefined` when no graphics are
     *   attached.
     */
    get proxyGraphic(): Uint8Array | undefined;
    /**
     * Sets the proxy-graphics binary payload.
     *
     * The supplied buffer is copied so subsequent mutations of the caller's array
     * do not affect this entity.
     *
     * @param data - Raw proxy-graphic bytes, or `null`/`undefined` to clear.
     */
    setProxyGraphic(data?: Uint8Array | null): void;
    /**
     * Gets the entity-origin anchor points stored on this proxy entity.
     *
     * @returns A read-only view of the origin points. Mutate through
     *   {@link setEntityOrigins}.
     */
    get entityOrigins(): AcGePoint3d[];
    /**
     * Replaces the entity-origin anchor points stored on this proxy entity.
     *
     * Each input point is cloned into an {@link AcGePoint3d} instance.
     *
     * @param origins - New origin points (DXF group codes **92** / **10**).
     */
    setEntityOrigins(origins: AcGePoint3d[]): void;
    /**
     * Gets the geometric extents of this proxy entity.
     *
     * When the proxy-graphic stream contains an {@link AcDbProxyGraphicType.Extents}
     * chunk, the returned box is built from its minimum and maximum corners.
     * Otherwise an empty {@link AcGeBox3d} is returned.
     *
     * @returns The axis-aligned bounding box derived from proxy graphics.
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this proxy entity.
     *
     * When entity origins are stored on the proxy, they are returned as grips.
     * Otherwise the axis-aligned extents corners are used when available.
     *
     * @returns Array of grip points as 3D points
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Transforms this proxy entity by the specified matrix.
     *
     * {@link entityOrigins} and the cumulative {@link _worldTransform} are
     * updated. The proxy-graphic byte stream is left unchanged; stream-local
     * transforms remain encoded as {@link AcDbProxyGraphicType.PushMatrix} /
     * {@link AcDbProxyGraphicType.PopMatrix} commands and are applied by
     * {@link AcDbProxyGraphic} before {@link _worldTransform}.
     *
     * @param matrix - World-space transformation matrix to apply.
     * @returns This entity for chaining.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Draws proxy graphics by decoding the binary stream and emitting primitives
     * through the renderer.
     *
     * This is the primary world-space draw entry point for proxy entities. It
     * delegates to {@link AcDbProxyGraphic.worldDraw} using the entity database
     * and layer as rendering context.
     *
     * @param renderer - Target graphics renderer.
     * @returns A grouped {@link AcGiEntity} when geometry was emitted, otherwise
     *   `undefined`.
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Writes DXF subclass fields for this proxy entity.
     *
     * Emits the `AcDbProxyEntity` subclass marker followed by Autodesk group
     * codes **90**, **91**, **95**, **70**, **160**, and **310**, plus optional
     * **1** / **3** when original class metadata is available.
     *
     * @param filer - DXF output filer.
     * @returns This entity for chaining.
     * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=GUID-89A690F9-E859-4D57-89EA-750F3FB76C6B
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Loads proxy-graphic bytes from DXF group codes **160** and **310**.
     *
     * @param length - Expected byte length from group code **160**. When provided
     *   and positive, the result is truncated to this length.
     * @param chunks - One or more hexadecimal strings or binary chunks from
     *   group code **310**.
     */
    loadProxyGraphicFromDxf(length?: number, chunks?: Array<string | Uint8Array>): void;
}
//# sourceMappingURL=AcDbProxyEntity.d.ts.map