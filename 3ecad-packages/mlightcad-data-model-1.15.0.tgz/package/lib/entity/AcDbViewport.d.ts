import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer, AcGiViewport } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbEntity } from './AcDbEntity';
/**
 * Represents a viewport entity in AutoCAD drawings.
 *
 * A viewport is a rectangular window that displays a portion of the drawing model space
 * within paper space layouts. Viewports allow users to create multiple views of the same
 * drawing at different scales and orientations on a single sheet.
 *
 * Key characteristics:
 * - Viewports exist primarily in paper space layouts
 * - Each viewport has a unique ID number (except the default system viewport with ID 1)
 * - Viewports can be active or inactive
 * - The viewport entity itself is drawn as a rectangular border in paper space
 *
 * @example
 * ```typescript
 * const viewport = new AcDbViewport();
 * viewport.centerPoint = new AcGePoint3d(0, 0, 0);
 * viewport.width = 10;
 * viewport.height = 8;
 * viewport.number = 2;
 * ```
 */
export declare class AcDbViewport extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    private _centerPoint;
    private _height;
    private _width;
    private _viewCenter;
    private _viewTarget;
    private _viewDirection;
    private _viewTwistAngle;
    private _viewHeight;
    private _number;
    private _snapBase;
    private _snapSpacing;
    private _gridSpacing;
    private _perspectiveLensLength;
    private _frontClipZ;
    private _backClipZ;
    private _snapAngle;
    private _status;
    private _ucsPerViewport;
    private _circleZoomPercent;
    private _statusBitFlags;
    private _ucsOrigin;
    private _ucsXAxis;
    private _ucsYAxis;
    private _elevation;
    private _frozenLayerIds;
    private _sheetName;
    private _iconFlag;
    private _orthographicType;
    private _majorGridFrequency;
    private _ambientLightColorIndex;
    private _brightness;
    private _contrast;
    private _shadePlotMode;
    private _renderMode;
    private _defaultLightingType;
    private _isDefaultLighting;
    private _clippingBoundaryId;
    private _backgroundId;
    private _shadePlotId;
    private _ucsId;
    private _ucsBaseId;
    private _visualStyleId;
    private _sunId;
    private _ambientLightColorInstance;
    private _ambientLightColorName;
    private _softPointers;
    /**
     * Creates a new AcDbViewport instance.
     *
     * Initializes all properties with default values:
     * - centerPoint: origin (0,0,0)
     * - height: 0
     * - width: 0
     * - viewCenter: origin (0,0,0)
     * - viewTarget: origin (0,0,0)
     * - viewTwistAngle: 0
     * - viewHeight: 0
     * - number: -1 (indicating inactive viewport)
     */
    constructor();
    /**
     * Gets or sets the viewport ID number.
     *
     * This is the number that is reported by the AutoCAD CVPORT system variable
     * when the viewport is the current viewport in the AutoCAD editor. If the viewport is inactive, -1
     * is returned.
     *
     * Important notes:
     * - This value is not saved with the drawing, and changes each time the drawing is opened
     * - Viewport ID 1 is reserved for the system-defined default viewport in paper space
     * - Active viewports have IDs greater than 1
     * - Inactive viewports return -1
     *
     * @returns The viewport ID number
     */
    get number(): number;
    set number(value: number);
    /**
     * Gets or sets the center point of the viewport entity in WCS coordinates (within Paper Space).
     *
     * This point represents the geometric center of the viewport's rectangular boundary
     * in paper space coordinates, not the center of the model space view within the viewport.
     *
     * @returns The center point of the viewport entity
     */
    get centerPoint(): AcGePoint3d;
    set centerPoint(value: AcGePoint3d);
    /**
     * Gets or sets the height of the viewport entity's window in drawing units.
     *
     * This represents the height of the viewport's rectangular boundary in paper space,
     * measured in the current drawing units. It defines the vertical extent of the
     * viewport border, not the height of the model space view within it.
     *
     * @returns The height of the viewport entity in drawing units
     */
    get height(): number;
    set height(value: number);
    /**
     * Gets or sets the width of the viewport entity's window in drawing units.
     *
     * This represents the width of the viewport's rectangular boundary in paper space,
     * measured in the current drawing units. It defines the horizontal extent of the
     * viewport border, not the width of the model space view within the viewport.
     *
     * Note: This is the width in Paper Space of the viewport itself, not the width
     * of the Model Space view within the viewport.
     *
     * @returns The width of the viewport entity in drawing units
     */
    get width(): number;
    set width(value: number);
    /**
     * Gets or sets the view center in display coordinate system coordinates.
     *
     * This point represents the center of the model space view that is displayed
     * within the viewport. It is specified in the display coordinate system and
     * determines what portion of the model space drawing is visible in the viewport.
     *
     * @returns The center point of the model space view within the viewport
     */
    get viewCenter(): AcGePoint3d;
    set viewCenter(value: AcGePoint3d);
    /**
     * Gets or sets the view target in WCS coordinates (DXF group 17).
     *
     * The model view center stored in {@link viewCenter} is in DCS; the WCS
     * center shown through the viewport is `viewTarget + rotate(viewCenter,
     * viewTwistAngle)`.
     */
    get viewTarget(): AcGePoint3d;
    set viewTarget(value: AcGePoint3d);
    /**
     * View direction from target (DXF group 16).
     */
    get viewDirection(): AcGeVector3dLike;
    set viewDirection(value: AcGeVector3dLike);
    /** Snap base point (DXF group 13). */
    get snapBase(): AcGePoint3d;
    set snapBase(value: AcGePoint3d);
    /** Snap spacing (DXF group 14). */
    get snapSpacing(): AcGePoint3d;
    set snapSpacing(value: AcGePoint3d);
    /** Grid spacing (DXF group 15). */
    get gridSpacing(): AcGePoint3d;
    set gridSpacing(value: AcGePoint3d);
    /** Perspective lens length (DXF group 42). */
    get perspectiveLensLength(): number;
    set perspectiveLensLength(value: number);
    /** Front clip plane Z value (DXF group 43). */
    get frontClipZ(): number;
    set frontClipZ(value: number);
    /** Back clip plane Z value (DXF group 44). */
    get backClipZ(): number;
    set backClipZ(value: number);
    /** Snap angle in radians (DXF group 50). */
    get snapAngle(): number;
    set snapAngle(value: number);
    /** Viewport status field (DXF group 68). */
    get status(): number;
    set status(value: number);
    /** UCS per-viewport flag (DXF group 71). */
    get ucsPerViewport(): number;
    set ucsPerViewport(value: number);
    /** Circle zoom percent (DXF group 72). */
    get circleZoomPercent(): number;
    set circleZoomPercent(value: number);
    /** Status bit flags (DXF group 90). */
    get statusBitFlags(): number;
    set statusBitFlags(value: number);
    /** UCS origin (DXF group 110). */
    get ucsOrigin(): AcGePoint3d;
    set ucsOrigin(value: AcGePoint3d);
    /** Elevation (DXF group 146). */
    get elevation(): number;
    set elevation(value: number);
    /** Frozen layer soft-pointer IDs (DXF group 331). */
    get frozenLayerIds(): string[];
    set frozenLayerIds(value: string[]);
    /** UCS X axis (DXF group 111). */
    get ucsXAxis(): AcGeVector3dLike;
    set ucsXAxis(value: AcGeVector3dLike);
    /** UCS Y axis (DXF group 112). */
    get ucsYAxis(): AcGeVector3dLike;
    set ucsYAxis(value: AcGeVector3dLike);
    /** Paper space sheet name (DXF group 1). */
    get sheetName(): string;
    set sheetName(value: string);
    /** UCSICON display flag (DXF group 74). */
    get iconFlag(): number;
    set iconFlag(value: number);
    /** Orthographic type of UCS (DXF group 79). */
    get orthographicType(): number;
    set orthographicType(value: number);
    /** Major grid-line frequency (DXF group 61). */
    get majorGridFrequency(): number;
    set majorGridFrequency(value: number);
    /** Ambient light color index (DXF group 63). */
    get ambientLightColorIndex(): number;
    set ambientLightColorIndex(value: number);
    /** Brightness (DXF group 141). */
    get viewportBrightness(): number;
    set viewportBrightness(value: number);
    /** Contrast (DXF group 142). */
    get viewportContrast(): number;
    set viewportContrast(value: number);
    /** Shade plot mode (DXF group 170). */
    get shadePlotMode(): number;
    set shadePlotMode(value: number);
    /** Render mode (DXF group 281). */
    get renderMode(): number;
    set renderMode(value: number);
    /** Default lighting type (DXF group 282). */
    get defaultLightingType(): number;
    set defaultLightingType(value: number);
    /** Whether default lighting is on (DXF group 292). */
    get isDefaultLighting(): boolean;
    set isDefaultLighting(value: boolean);
    /** Clipping boundary hard-pointer ID (DXF group 340). */
    get clippingBoundaryId(): string;
    set clippingBoundaryId(value: string);
    /** Background soft-pointer ID (DXF group 332). */
    get backgroundId(): string;
    set backgroundId(value: string);
    /** Shade plot soft-pointer ID (DXF group 333). */
    get shadePlotId(): string;
    set shadePlotId(value: string);
    /** UCS soft-pointer ID (DXF group 345). */
    get ucsId(): string;
    set ucsId(value: string);
    /** UCS base soft-pointer ID (DXF group 346). */
    get ucsBaseId(): string;
    set ucsBaseId(value: string);
    /** Visual style soft-pointer ID (DXF group 348). */
    get visualStyleId(): string;
    set visualStyleId(value: string);
    /** Sun soft-pointer ID (DXF group 361). */
    get sunId(): string;
    set sunId(value: string);
    /** Ambient light color (true color, DXF group 421). */
    get ambientLightColorInstance(): number;
    set ambientLightColorInstance(value: number);
    /** Ambient light color name (DXF group 431). */
    get ambientLightColorName(): string;
    set ambientLightColorName(value: string);
    /** Soft-pointer IDs from groups 91 / 335 / 343 / 344. */
    get softPointers(): string[];
    set softPointers(value: string[]);
    /**
     * Gets or sets the view twist angle in radians (DXF group 51).
     */
    get viewTwistAngle(): number;
    set viewTwistAngle(value: number);
    /**
     * Gets or sets the height of the Model Space view within the viewport.
     *
     * This value represents the height of the model space view that is displayed
     * within the viewport, specified in display coordinate system coordinates.
     *
     * Zoom behavior:
     * - Zooming the view out within the viewport increases this value
     * - Zooming the view in within the viewport decreases this value
     *
     * @returns The height of the model space view in display coordinates
     */
    get viewHeight(): number;
    set viewHeight(value: number);
    /**
     * Gets the geometric extents of the viewport entity.
     *
     * This method returns a bounding box that encompasses the entire viewport entity
     * in world coordinate system (WCS) coordinates.
     *
     * @returns A bounding box containing the viewport entity
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this viewport.
     *
     * Grip points are the center point and the four corners of the viewport
     * boundary in paper space, matching AutoCAD viewport grip behavior.
     *
     * @returns Array of grip points as 3D points
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Transforms this viewport entity by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Renders the viewport entity using the specified renderer.
     *
     * The viewport is drawn as a rectangular border when the following conditions are met:
     * - The viewport entity is not in model space (i.e., it's in paper space)
     * - The viewport ID number is greater than 1 (not the default system viewport)
     *
     * In paper space layouts, there is always a system-defined "default" viewport that exists as
     * the bottom-most item. This viewport doesn't show any entities and is mainly for internal
     * AutoCAD purposes. The viewport ID number of this system-defined "default" viewport is 1.
     *
     * @param renderer - The renderer to use for drawing the viewport
     * @returns A render group containing the viewport border lines, or undefined if not drawn
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Converts this AcDbViewport to an AcGiViewport for rendering purposes.
     *
     * This method creates a graphic interface viewport object that contains all the
     * necessary properties for rendering the viewport in the graphics system.
     *
     * @returns An AcGiViewport instance with all viewport properties copied
     */
    toGiViewport(): AcGiViewport;
    /**
     * Creates the rectangular border lines for the viewport.
     *
     * This private method generates four line entities that form a rectangle representing
     * the viewport's boundary. The rectangle is centered on the viewport's center point
     * and has dimensions specified by the viewport's width and height.
     *
     * @param viewport - The graphic interface viewport containing rendering properties
     * @param renderer - The renderer to use for creating the line entities
     * @returns An array of line entities forming the viewport border
     * @private
     */
    private createViewportRect;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private applyViewportDxfIn;
    private moveGripAt;
}
//# sourceMappingURL=AcDbViewport.d.ts.map