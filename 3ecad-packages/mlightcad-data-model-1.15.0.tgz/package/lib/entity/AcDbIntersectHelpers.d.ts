import { AcGeIntersectPrimitive, AcGeLoop2dType, AcGeMatrix3d, AcGePoint3dLike, AcGePolyline2dVertex, AcGeVector3dLike } from '@mlightcad/geometry-engine';
/**
 * Builds bounded line primitives from a 3D point path.
 *
 * Open paths mark the first and last segments as extendable; closed paths
 * mark every segment as not extendable. Pass `extendable` to override that
 * default for every segment (for example mesh edges).
 */
export declare function acdbIntersectPrimitivesFromPointPath(points: readonly AcGePoint3dLike[], closed: boolean, extendable?: boolean): AcGeIntersectPrimitive[];
/**
 * Converts a 2D polyline (including bulge arcs) into WCS intersection primitives.
 */
export declare function acdbIntersectPrimitivesFromPolyline2d(vertices: readonly AcGePolyline2dVertex[], closed: boolean, elevation: number, normal: AcGeVector3dLike): AcGeIntersectPrimitive[];
/**
 * Converts hatch / area loops into WCS intersection primitives.
 */
export declare function acdbIntersectPrimitivesFromAreaLoops(loops: readonly AcGeLoop2dType[], elevation: number, normal: AcGeVector3dLike): AcGeIntersectPrimitive[];
/**
 * Transforms a list of intersection primitives by a WCS matrix.
 */
export declare function acdbTransformIntersectPrimitives(primitives: readonly AcGeIntersectPrimitive[], matrix: AcGeMatrix3d): AcGeIntersectPrimitive[];
//# sourceMappingURL=AcDbIntersectHelpers.d.ts.map