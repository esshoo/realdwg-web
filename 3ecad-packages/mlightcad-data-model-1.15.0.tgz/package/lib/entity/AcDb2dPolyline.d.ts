import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint2d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents the curve/spline-fit type for one 2d polyline.
 */
export declare enum AcDbPoly2dType {
    /**
     * A standard polyline with no curve/spline fitting.
     */
    SimplePoly = 0,
    /**
     * A polyline that has been curve fit.
     */
    FitCurvePoly = 1,
    /**
     * A spline-fit polyline that has a Quadratic B-spline path.
     */
    QuadSplinePoly = 2,
    /**
     * A spline-fit polyline that has a Cubic B-spline path.
     */
    CubicSplinePoly = 3
}
/**
 * Represents a 2d polyline entity in AutoCAD. This is the older class used to
 * represent 2D polylines in the legacy (DXF/DWG R12 and before) format.
 *
 * Characteristics
 * - Represents 2D polyline entities, typically planar (all vertices lie in a single plane).
 * - Each vertex is an instance of AcDb2dVertex.
 * - Supports bulge values (for arcs between vertices).
 * - Can represent fit curves or spline-fit polylines (via the polyline type flag).
 * - Each vertex can have flags like curve-fit vertex, spline vertex, etc.
 * - Geometry is stored as a linked list of vertex entities (not a single compact structure).
 *
 * Typical use case
 * - Used mainly for backward compatibility and import/export of old drawings.
 */
export declare class AcDb2dPolyline extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The curve/spline-fit type for this 2d polyline */
    private _polyType;
    /** The elevation (Z-coordinate) of the polyline plane */
    private _elevation;
    /** Extrusion direction / plane normal (DXF group 210). */
    private _normal;
    /** The underlying geometric polyline object */
    private _geo;
    /**
     * Creates a new empty 2d polyline entity.
     */
    constructor(type: AcDbPoly2dType, vertices: AcGePoint3dLike[], elevation?: number, closed?: boolean, _startWidth?: number, _endWidth?: number, bulges?: number[] | null);
    /**
     * Gets the curve/spline-fit type for this 2d polyline.
     *
     * @returns The curve/spline-fit type for this 2d polyline.
     */
    get polyType(): AcDbPoly2dType;
    /**
     * Sets the curve/spline-fit type for this 2d polyline.
     *
     * @param value - The curve/spline-fit type for this 2d polyline.
     */
    set polyType(value: AcDbPoly2dType);
    /**
     * Gets the elevation of this polyline.
     *
     * The elevation is the distance of the polyline's plane from the WCS origin
     * along the Z-axis.
     *
     * @returns The elevation value
     *
     * @example
     * ```typescript
     * const elevation = polyline.elevation;
     * console.log(`Polyline elevation: ${elevation}`);
     * ```
     */
    get elevation(): number;
    /**
     * Sets the elevation of this polyline.
     *
     * @param value - The new elevation value
     *
     * @example
     * ```typescript
     * polyline.elevation = 10;
     * ```
     */
    set elevation(value: number);
    /**
     * Extrusion direction / plane normal (DXF group 210).
     */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets whether this polyline is closed.
     *
     * A closed polyline has a segment drawn from the last vertex to the first vertex,
     * forming a complete loop.
     *
     * @returns True if the polyline is closed, false otherwise
     *
     * @example
     * ```typescript
     * const isClosed = polyline.closed;
     * console.log(`Polyline is closed: ${isClosed}`);
     * ```
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Sets whether this polyline is closed.
     *
     * @param value - True to close the polyline, false to open it
     *
     * @example
     * ```typescript
     * polyline.closed = true; // Close the polyline
     * ```
     */
    set closed(value: boolean);
    get numberOfVertices(): number;
    getPointAt(index: number): AcGePoint2d;
    /**
     * Gets the bulge value of the vertex at the specified index.
     *
     * @param index - The index of the vertex
     * @returns The bulge value of the vertex
     */
    getBulgeAt(index: number): number;
    /**
     * Gets the geometric extents (bounding box) of this polyline.
     *
     * @returns The bounding box that encompasses the entire polyline
     *
     * @example
     * ```typescript
     * const extents = polyline.geometricExtents;
     * console.log(`Polyline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this polyline.
     *
     * Grip points are control points that can be used to modify the polyline.
     * For a polyline, the grip points are all the vertices.
     *
     * @returns Array of grip points (all vertices)
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this polyline.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this legacy 2D polyline by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this polyline entity, including
     * general group and geometry group.
     *
     * The geometry group exposes properties via {@link AcDbPropertyAccessor} so
     * the property palette can update the polyline in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * This 2d polyline always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * Draws this polyline using the specified renderer.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered polyline entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes the DXF record for the polyline, plus legacy VERTEX/SEQEND records.
     *
     * The extra records are required by the classic POLYLINE entity format.
     *
     * @param filer - DXF output writer.
     * @param allXdata - When true, emits all XData attached to this entity.
     * @returns The entity instance (for chaining).
     */
    /**
     * Writes this object to the DXF output.
     *
     * @param filer - DXF output writer.
     * @param allXdata - When true, emits all XData attached to this object.
     * @returns The instance (for chaining).
     */
    dxfOut(filer: AcDbDxfFiler, allXdata?: boolean): this;
    /**
     * Writes the POLYLINE entity fields (header) for a 2D polyline.
     *
     * @param filer - DXF output writer.
     * @returns The entity instance (for chaining).
     */
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Approximates the legacy 2D polyline in the XY plane, offsets that path, and
     * returns a single {@link AcDbPolyline}. Elevation is not preserved on the result.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Projects the entity to a sampled 2D path and delegates the side test to a
     * temporary {@link AcDbPolyline}.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * Builds the offset result as a lightweight {@link AcDbPolyline}.
     *
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline, or `null` when the sampled path is too short or offset fails
     */
    private createOffsetCurve;
    /**
     * Samples the underlying {@link AcGePolyline2d} into a dense 2D path for offsetting.
     *
     * Sample count scales with vertex count so curved or fitted segments are represented
     * adequately in the planar approximation.
     *
     * @returns XY points along the polyline geometry
     */
    private collectPath2d;
}
//# sourceMappingURL=AcDb2dPolyline.d.ts.map