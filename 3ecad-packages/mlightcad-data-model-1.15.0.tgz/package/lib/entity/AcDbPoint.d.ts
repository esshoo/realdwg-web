import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGePointLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a point entity in AutoCAD.
 *
 * A point is a 0-dimensional geometric object defined by its position in 3D space.
 * Points are fundamental drawing entities that can be used to mark specific
 * locations in drawings or as reference points for other entities.
 *
 * @example
 * ```typescript
 * // Create a point at the origin
 * const point = new AcDbPoint();
 * point.position = new AcGePoint3d(0, 0, 0);
 *
 * // Create a point at a specific location
 * const point2 = new AcDbPoint();
 * point2.position = new AcGePoint3d(10, 20, 5);
 *
 * // Access point properties
 * console.log(`Point position: ${point.position}`);
 * ```
 */
export declare class AcDbPoint extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The underlying geometric point object */
    private _geo;
    /** Thickness along the normal (DXF group 39) */
    private _thickness;
    /** Extrusion / plane normal (DXF group 210) */
    private _normal;
    /**
     * Angle of the X axis for the UCS in effect when the point was drawn
     * (DXF group 50). Used when PDMODE is nonzero.
     */
    private _ecsRotation;
    /**
     * Creates a new point entity.
     *
     * This constructor initializes a point object at the origin (0,0,0).
     * The position can be set after creation using the position property.
     *
     * @example
     * ```typescript
     * const point = new AcDbPoint();
     * point.position = new AcGePoint3d(5, 10, 0);
     * ```
     */
    constructor();
    /**
     * Gets the position of this point in WCS coordinates.
     *
     * @returns The position as a 3D point
     *
     * @example
     * ```typescript
     * const position = point.position;
     * console.log(`Point at: ${position.x}, ${position.y}, ${position.z}`);
     * ```
     */
    get position(): AcGePoint3d;
    /**
     * Sets the position of this point in WCS coordinates.
     *
     * @param value - The new position
     *
     * @example
     * ```typescript
     * point.position = new AcGePoint3d(15, 25, 0);
     * ```
     */
    set position(value: AcGePointLike);
    /**
     * Thickness along the entity normal (DXF group 39).
     */
    get thickness(): number;
    set thickness(value: number);
    /**
     * Extrusion direction / plane normal (DXF group 210).
     */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Angle of the X axis for the UCS in effect when the point was drawn
     * (DXF group 50), in radians.
     */
    get ecsRotation(): number;
    set ecsRotation(value: number);
    /**
     * Gets the geometric extents (bounding box) of this point.
     *
     * For a point, the bounding box is a minimal box that contains just the point.
     *
     * @returns The bounding box that encompasses the point
     *
     * @example
     * ```typescript
     * const extents = point.geometricExtents;
     * console.log(`Point bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the object snap points for this point.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    /**
     * Gets the grip points for this point entity.
     *
     * @returns Array containing the point position.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Returns the full property definition for this point entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the point in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Transforms this point by the specified matrix.
     *
     * This method applies a geometric transformation to the point, updating
     * its position according to the transformation matrix.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This point after transformation
     *
     * @example
     * ```typescript
     * const translationMatrix = AcGeMatrix3d.translation(10, 0, 0);
     * point.transformBy(translationMatrix);
     * // Point is now translated 10 units in the X direction
     * ```
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Only the simple PDMODE dot (0) is a single `THREE.Points` drawable.
     * Other modes emit symbol LineSegments and stay on the legacy path.
     *
     * @internal
     */
    get directBatchPrimitive(): "point" | null;
    /**
     * Draws this point using the specified renderer.
     *
     * This method renders the point using the point's current style properties,
     * including the display mode and size from the database.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered point entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbPoint.d.ts.map