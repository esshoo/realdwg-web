import { AcCmColor } from '@mlightcad/common';
import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiMTextAttachmentPoint, AcGiMTextFlowDirection, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Defines the type of leader line used by a multileader.
 */
export declare enum AcDbMLeaderLineType {
    /** The leader line is not displayed. */
    InvisibleLeader = 0,
    /** The leader line is drawn using straight segments. */
    StraightLeader = 1,
    /** The leader line is drawn as a spline. */
    SplineLeader = 2
}
/**
 * Defines the annotation content type used by a multileader.
 */
export declare enum AcDbMLeaderContentType {
    /** No annotation content. */
    NoneContent = 0,
    /** Block annotation content. */
    BlockContent = 1,
    /** MText annotation content. */
    MTextContent = 2,
    /** Tolerance annotation content. */
    ToleranceContent = 3
}
/**
 * Defines the attachment direction of multileader text.
 */
export declare enum AcDbMLeaderTextAttachmentDirection {
    /** Text is attached horizontally. */
    Horizontal = 0,
    /** Text is attached vertically. */
    Vertical = 1
}
/**
 * Defines the general direction of a leader branch.
 */
export declare enum AcDbMLeaderDirectionType {
    /** Direction is not known or not applicable. */
    Unknown = 0,
    /** Leader points to the left of the content. */
    Left = 1,
    /** Leader points to the right of the content. */
    Right = 2,
    /** Leader points above the content. */
    Top = 3,
    /** Leader points below the content. */
    Bottom = 4
}
/**
 * Represents a leader break segment input using point-like values.
 */
export interface AcDbMLeaderBreakLike {
    index?: number;
    start: AcGePoint3dLike;
    end: AcGePoint3dLike;
}
/**
 * Represents a normalized leader break segment stored with concrete points.
 */
export interface AcDbMLeaderBreak {
    index?: number;
    start: AcGePoint3d;
    end: AcGePoint3d;
}
/**
 * Represents a leader-line input payload before normalization.
 */
export interface AcDbMLeaderLineLike {
    vertices?: AcGePoint3dLike[];
    breakPointIndexes?: number[];
    leaderLineIndex?: number;
    breaks?: AcDbMLeaderBreakLike[];
}
/**
 * Represents one normalized leader line.
 */
export interface AcDbMLeaderLine {
    vertices: AcGePoint3d[];
    breakPointIndexes: number[];
    leaderLineIndex?: number;
    breaks: AcDbMLeaderBreak[];
}
/**
 * Represents a leader-branch input payload.
 */
export interface AcDbMLeaderLeaderLike {
    lastLeaderLinePoint?: AcGePoint3dLike;
    lastLeaderLinePointSet?: boolean;
    landingPoint?: AcGePoint3dLike;
    doglegVector?: AcGeVector3dLike;
    doglegVectorSet?: boolean;
    doglegLength?: number;
    breaks?: AcDbMLeaderBreakLike[];
    leaderBranchIndex?: number;
    directionType?: AcDbMLeaderDirectionType;
    leaderLines?: AcDbMLeaderLineLike[];
}
/**
 * Represents one normalized leader branch stored by the entity.
 */
export interface AcDbMLeaderLeader {
    lastLeaderLinePoint?: AcGePoint3d;
    lastLeaderLinePointSet?: boolean;
    landingPoint?: AcGePoint3d;
    doglegVector?: AcGeVector3d;
    doglegVectorSet?: boolean;
    doglegLength?: number;
    breaks: AcDbMLeaderBreak[];
    leaderBranchIndex?: number;
    directionType?: AcDbMLeaderDirectionType;
    leaderLines: AcDbMLeaderLine[];
}
/**
 * Represents MText content input data for a multileader.
 */
export interface AcDbMLeaderMTextContentLike {
    text: string;
    anchorPoint: AcGePoint3dLike;
}
/**
 * Represents normalized MText content stored by a multileader.
 */
export interface AcDbMLeaderMTextContent {
    text: string;
    anchorPoint: AcGePoint3d;
}
/**
 * Represents block content input data for a multileader.
 */
export interface AcDbMLeaderBlockContentLike {
    blockContentId?: string;
    blockHandle?: string;
    normal?: AcGeVector3dLike;
    position?: AcGePoint3dLike;
    scale?: AcGeVector3dLike;
    rotation?: number;
    color?: AcCmColor;
    transformationMatrix?: number[];
}
/**
 * Represents normalized block content stored by a multileader.
 */
export interface AcDbMLeaderBlockContent {
    blockContentId?: string;
    blockHandle?: string;
    normal?: AcGeVector3d;
    position?: AcGePoint3d;
    scale: AcGeVector3d;
    rotation: number;
    color?: AcCmColor;
    transformationMatrix: number[];
}
/**
 * Represents a handle tied to a specific index in multileader data.
 */
export interface AcDbMLeaderIndexedHandle {
    index: number;
    handle?: string;
}
/**
 * Represents one block attribute override entry.
 */
export interface AcDbMLeaderBlockAttribute {
    id?: string;
    index?: number;
    width?: number;
    text?: string;
}
/**
 * Represents a multileader entity.
 *
 * A multileader contains one or more leader branches, each of which can contain
 * one or more leader lines, plus optional MText or block content.
 */
export declare class AcDbMLeader extends AcDbEntity {
    /** The entity type name. */
    static typeName: string;
    /**
     * Gets the DXF type name used when exporting this entity.
     */
    get dxfTypeName(): string;
    private _leaders;
    private _leaderLineType;
    private _contentType;
    private _doglegEnabled;
    private _doglegLength;
    private _landingPoint?;
    private _doglegVector;
    private _normal;
    private _mleaderStyleId;
    private _mtextContent?;
    private _textHeight;
    private _textWidth;
    private _textRotation;
    private _textDirection;
    private _textStyleName;
    private _textAttachmentPoint;
    private _textDrawingDirection;
    private _textLineSpacingFactor;
    private _textAttachmentDirection;
    private _blockContent?;
    private _version?;
    private _leaderStyleId?;
    private _propertyOverrideFlag?;
    private _leaderLineColor?;
    private _leaderLineTypeId?;
    private _leaderLineWeight?;
    private _landingEnabled?;
    private _arrowheadId?;
    private _arrowheadSize?;
    private _textStyleId?;
    private _textLeftAttachmentType?;
    private _textRightAttachmentType?;
    private _textAngleType?;
    private _textAlignmentType?;
    private _textColor?;
    private _textFrameEnabled?;
    private _landingGap?;
    private _textAttachment?;
    private _textFlowDirection?;
    private _blockContentId?;
    private _blockContentColor?;
    private _blockContentScale?;
    private _blockContentRotation?;
    private _blockContentConnectionType?;
    private _annotativeScaleEnabled?;
    private _arrowheadOverrides;
    private _blockAttributes;
    private _textDirectionNegative?;
    private _textAlignInIPE?;
    private _bottomTextAttachmentDirection?;
    private _topTextAttachmentDirection?;
    private _contentScale?;
    private _contentBasePosition?;
    private _textAnchor?;
    private _textLineSpacingStyle?;
    private _textBackgroundColor?;
    private _textBackgroundScaleFactor?;
    private _textBackgroundTransparency?;
    private _textBackgroundColorOn?;
    private _textFillOn?;
    private _textColumnType?;
    private _textUseAutoHeight?;
    private _textColumnWidth?;
    private _textColumnGutterWidth?;
    private _textColumnFlowReversed?;
    private _textColumnHeight?;
    private _textUseWordBreak?;
    private _hasMText?;
    private _hasBlock?;
    private _planeOrigin?;
    private _planeXAxisDirection?;
    private _planeYAxisDirection?;
    private _planeNormalReversed?;
    /**
     * Creates an empty multileader entity with default style-related state.
     *
     * @remarks
     * Initializes geometry, text, and block-related members to defaults that
     * are compatible with common MLEADER behavior.
     */
    constructor();
    /**
     * Gets a deep-cloned collection of all leader branches.
     */
    get leaders(): AcDbMLeaderLeader[];
    /**
     * Gets the current number of leader branches.
     */
    get numberOfLeaders(): number;
    /**
     * Gets the leader line type.
     */
    get leaderLineType(): AcDbMLeaderLineType;
    set leaderLineType(value: AcDbMLeaderLineType);
    /**
     * Gets the content type.
     */
    get contentType(): AcDbMLeaderContentType;
    set contentType(value: AcDbMLeaderContentType);
    /**
     * Gets the dogleg enabled.
     */
    get doglegEnabled(): boolean;
    set doglegEnabled(value: boolean);
    /**
     * Gets the dogleg length.
     */
    get doglegLength(): number;
    set doglegLength(value: number);
    /**
     * Gets the dogleg vector.
     */
    get doglegVector(): AcGeVector3dLike;
    set doglegVector(value: AcGeVector3dLike);
    /**
     * Gets the landing point.
     */
    get landingPoint(): AcGePoint3dLike | undefined;
    set landingPoint(value: AcGePoint3dLike | undefined);
    /**
     * Gets the normal.
     */
    get normal(): AcGeVector3dLike;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the mleader style id.
     */
    get mleaderStyleId(): string;
    set mleaderStyleId(value: string);
    /**
     * Gets or sets the serialized MLeader version code.
     *
     * This value mirrors DXF/internal version metadata and is used to keep
     * compatibility with files saved from different AutoCAD generations.
     */
    get version(): number | undefined;
    set version(value: number | undefined);
    /**
     * Gets or sets the MLeader style handle override stored on the entity.
     *
     * When provided, this value is typically used as a fallback in addition to
     * `mleaderStyleId` during style resolution.
     */
    get leaderStyleId(): string | undefined;
    set leaderStyleId(value: string | undefined);
    /**
     * Gets or sets the property-override bit flag.
     *
     * The flag indicates which visual/behavioral properties are overridden at the
     * entity level instead of inherited from the referenced MLeader style.
     */
    get propertyOverrideFlag(): number | undefined;
    set propertyOverrideFlag(value: number | undefined);
    /**
     * Gets or sets the explicit leader line color override.
     */
    get leaderLineColor(): AcCmColor | undefined;
    set leaderLineColor(value: AcCmColor | undefined);
    /**
     * Gets or sets the leader line type handle override.
     */
    get leaderLineTypeId(): string | undefined;
    set leaderLineTypeId(value: string | undefined);
    /**
     * Gets or sets the lineweight override for leader segments.
     */
    get leaderLineWeight(): number | undefined;
    set leaderLineWeight(value: number | undefined);
    /**
     * Gets or sets whether leader landings are enabled.
     */
    get landingEnabled(): boolean | undefined;
    set landingEnabled(value: boolean | undefined);
    /**
     * Gets or sets the arrowhead block handle/name override.
     */
    get arrowheadId(): string | undefined;
    set arrowheadId(value: string | undefined);
    /**
     * Gets or sets the arrowhead size override in drawing units.
     */
    get arrowheadSize(): number | undefined;
    set arrowheadSize(value: number | undefined);
    /**
     * Gets or sets the text style handle override for MText content.
     */
    get textStyleId(): string | undefined;
    set textStyleId(value: string | undefined);
    /**
     * Gets or sets left-side text attachment behavior code.
     */
    get textLeftAttachmentType(): number | undefined;
    set textLeftAttachmentType(value: number | undefined);
    /**
     * Gets or sets right-side text attachment behavior code.
     */
    get textRightAttachmentType(): number | undefined;
    set textRightAttachmentType(value: number | undefined);
    /**
     * Gets or sets the text angle type code controlling rotation strategy.
     */
    get textAngleType(): number | undefined;
    set textAngleType(value: number | undefined);
    /**
     * Gets or sets the text alignment type code.
     */
    get textAlignmentType(): number | undefined;
    set textAlignmentType(value: number | undefined);
    /**
     * Gets or sets the MText color override.
     */
    get textColor(): AcCmColor | undefined;
    set textColor(value: AcCmColor | undefined);
    /**
     * Gets or sets whether a text frame (border) is enabled.
     */
    get textFrameEnabled(): boolean | undefined;
    set textFrameEnabled(value: boolean | undefined);
    /**
     * Gets or sets the gap distance between landing and annotation content.
     */
    get landingGap(): number | undefined;
    set landingGap(value: number | undefined);
    /**
     * Gets or sets the legacy text attachment value used in some DXF variants.
     */
    get textAttachment(): number | undefined;
    set textAttachment(value: number | undefined);
    /**
     * Gets or sets the text flow direction override code.
     */
    get textFlowDirection(): number | undefined;
    set textFlowDirection(value: number | undefined);
    /**
     * Gets or sets the referenced block content id/handle for block-based content.
     */
    get blockContentId(): string | undefined;
    set blockContentId(value: string | undefined);
    /**
     * Gets or sets the block content color override.
     */
    get blockContentColor(): AcCmColor | undefined;
    set blockContentColor(value: AcCmColor | undefined);
    /**
     * Gets or sets the block content scale vector override.
     */
    get blockContentScale(): AcGeVector3d | undefined;
    set blockContentScale(value: AcGeVector3d | undefined);
    /**
     * Gets or sets the block content rotation override in radians.
     */
    get blockContentRotation(): number | undefined;
    set blockContentRotation(value: number | undefined);
    /**
     * Gets or sets the block content connection type code.
     */
    get blockContentConnectionType(): number | undefined;
    set blockContentConnectionType(value: number | undefined);
    /**
     * Gets or sets whether annotative scaling is enabled for this entity.
     */
    get annotativeScaleEnabled(): boolean | undefined;
    set annotativeScaleEnabled(value: boolean | undefined);
    /**
     * Gets or sets per-index arrowhead overrides.
     *
     * Each entry maps a branch/line index to a specific arrowhead handle.
     */
    get arrowheadOverrides(): AcDbMLeaderIndexedHandle[];
    set arrowheadOverrides(value: AcDbMLeaderIndexedHandle[]);
    /**
     * Gets or sets block attribute override values used by block content.
     */
    get blockAttributes(): AcDbMLeaderBlockAttribute[];
    set blockAttributes(value: AcDbMLeaderBlockAttribute[]);
    /**
     * Gets or sets whether text direction is treated as negative.
     */
    get textDirectionNegative(): boolean | undefined;
    set textDirectionNegative(value: boolean | undefined);
    /**
     * Gets or sets the in-place editor text alignment code.
     */
    get textAlignInIPE(): number | undefined;
    set textAlignInIPE(value: number | undefined);
    /**
     * Gets or sets bottom attachment direction code for vertical text behavior.
     */
    get bottomTextAttachmentDirection(): number | undefined;
    set bottomTextAttachmentDirection(value: number | undefined);
    /**
     * Gets or sets top attachment direction code for vertical text behavior.
     */
    get topTextAttachmentDirection(): number | undefined;
    set topTextAttachmentDirection(value: number | undefined);
    /**
     * Gets or sets the overall content scale override.
     */
    get contentScale(): number | undefined;
    set contentScale(value: number | undefined);
    /**
     * Gets or sets the base insertion position of annotation content.
     */
    get contentBasePosition(): AcGePoint3d | undefined;
    set contentBasePosition(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the explicit text anchor position.
     */
    get textAnchor(): AcGePoint3d | undefined;
    set textAnchor(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the text line spacing style code for column/text layout.
     */
    get textLineSpacingStyle(): number | undefined;
    set textLineSpacingStyle(value: number | undefined);
    /**
     * Gets or sets text background color override.
     */
    get textBackgroundColor(): AcCmColor | undefined;
    set textBackgroundColor(value: AcCmColor | undefined);
    /**
     * Gets or sets background-mask scale factor around text.
     */
    get textBackgroundScaleFactor(): number | undefined;
    set textBackgroundScaleFactor(value: number | undefined);
    /**
     * Gets or sets text background transparency value.
     */
    get textBackgroundTransparency(): number | undefined;
    set textBackgroundTransparency(value: number | undefined);
    /**
     * Gets or sets whether explicit background color masking is enabled.
     */
    get textBackgroundColorOn(): boolean | undefined;
    set textBackgroundColorOn(value: boolean | undefined);
    /**
     * Gets or sets whether text fill/mask is enabled.
     */
    get textFillOn(): boolean | undefined;
    set textFillOn(value: boolean | undefined);
    /**
     * Gets or sets the text column layout type code.
     */
    get textColumnType(): number | undefined;
    set textColumnType(value: number | undefined);
    /**
     * Gets or sets whether text column height is auto-managed.
     */
    get textUseAutoHeight(): boolean | undefined;
    set textUseAutoHeight(value: boolean | undefined);
    /**
     * Gets or sets the fixed width for text columns.
     */
    get textColumnWidth(): number | undefined;
    set textColumnWidth(value: number | undefined);
    /**
     * Gets or sets the gutter width between text columns.
     */
    get textColumnGutterWidth(): number | undefined;
    set textColumnGutterWidth(value: number | undefined);
    /**
     * Gets or sets whether text columns flow in reverse order.
     */
    get textColumnFlowReversed(): boolean | undefined;
    set textColumnFlowReversed(value: boolean | undefined);
    /**
     * Gets or sets the explicit text column height.
     */
    get textColumnHeight(): number | undefined;
    set textColumnHeight(value: number | undefined);
    /**
     * Gets or sets whether word breaking is enabled in column layout.
     */
    get textUseWordBreak(): boolean | undefined;
    set textUseWordBreak(value: boolean | undefined);
    /**
     * Gets or sets whether MText content exists in the serialized payload.
     */
    get hasMText(): boolean | undefined;
    set hasMText(value: boolean | undefined);
    /**
     * Gets or sets whether block content exists in the serialized payload.
     */
    get hasBlock(): boolean | undefined;
    set hasBlock(value: boolean | undefined);
    /**
     * Gets or sets the origin of the MLeader plane definition.
     */
    get planeOrigin(): AcGePoint3d | undefined;
    set planeOrigin(value: AcGePoint3d | undefined);
    /**
     * Gets or sets the X-axis direction vector of the MLeader plane.
     */
    get planeXAxisDirection(): AcGeVector3d | undefined;
    set planeXAxisDirection(value: AcGeVector3d | undefined);
    /**
     * Gets or sets the Y-axis direction vector of the MLeader plane.
     */
    get planeYAxisDirection(): AcGeVector3d | undefined;
    set planeYAxisDirection(value: AcGeVector3d | undefined);
    /**
     * Gets or sets whether the MLeader plane normal is reversed.
     */
    get planeNormalReversed(): boolean | undefined;
    set planeNormalReversed(value: boolean | undefined);
    /**
     * Gets the alias of `leaders`.
     */
    get leaderSections(): AcDbMLeaderLeader[];
    /**
     * Gets the alias of `blockContent`.
     */
    get blockContentData(): AcDbMLeaderBlockContentLike | undefined;
    /**
     * Gets the MText content payload if present.
     */
    get mtextContent(): AcDbMLeaderMTextContentLike | undefined;
    set mtextContent(value: AcDbMLeaderMTextContentLike | undefined);
    /**
     * Gets the displayed MText string content.
     */
    get contents(): string;
    set contents(value: string);
    /**
     * Gets the MText anchor point.
     */
    get textLocation(): AcGePoint3dLike | undefined;
    set textLocation(value: AcGePoint3dLike | undefined);
    /**
     * Gets the text height.
     */
    get textHeight(): number;
    set textHeight(value: number);
    /**
     * Gets the text width.
     */
    get textWidth(): number;
    set textWidth(value: number);
    /**
     * Gets the text rotation.
     */
    get textRotation(): number;
    set textRotation(value: number);
    /**
     * Gets the text direction.
     */
    get textDirection(): AcGeVector3dLike;
    set textDirection(value: AcGeVector3dLike);
    /**
     * Gets the text style name.
     */
    get textStyleName(): string;
    set textStyleName(value: string);
    /**
     * Gets the text attachment point.
     */
    get textAttachmentPoint(): AcGiMTextAttachmentPoint;
    set textAttachmentPoint(value: AcGiMTextAttachmentPoint);
    /**
     * Gets the text drawing direction.
     */
    get textDrawingDirection(): AcGiMTextFlowDirection;
    set textDrawingDirection(value: AcGiMTextFlowDirection);
    /**
     * Gets the text line spacing factor.
     */
    get textLineSpacingFactor(): number;
    set textLineSpacingFactor(value: number);
    /**
     * Gets the text attachment direction.
     */
    get textAttachmentDirection(): AcDbMLeaderTextAttachmentDirection;
    set textAttachmentDirection(value: AcDbMLeaderTextAttachmentDirection);
    /**
     * Gets the block content.
     */
    get blockContent(): AcDbMLeaderBlockContentLike | undefined;
    set blockContent(value: AcDbMLeaderBlockContentLike | undefined);
    /**
     * Adds a leader branch and returns its index.
     *
     * @param leader Optional leader payload used to initialize branch data.
     * @returns Index of the newly added leader branch.
     */
    addLeader(leader?: AcDbMLeaderLeaderLike): number;
    /**
     * Removes a leader branch.
     *
     * @param leaderIndex Zero-based index of the leader branch to remove.
     * @returns The current entity instance for chaining.
     */
    removeLeader(leaderIndex: number): this;
    /**
     * Adds a leader line to a leader branch and returns the line index.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param vertices Optional initial vertices for the leader line.
     * @returns Index of the newly added leader line.
     */
    addLeaderLine(leaderIndex: number, vertices?: AcGePoint3dLike[]): number;
    /**
     * Appends a vertex to one leader line.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param leaderLineIndex Index of the target leader line.
     * @param point Vertex to append.
     * @returns The current entity instance for chaining.
     */
    appendVertex(leaderIndex: number, leaderLineIndex: number, point: AcGePoint3dLike): this;
    /**
     * Replaces the vertices of one leader line.
     *
     * @param leaderIndex Index of the target leader branch.
     * @param leaderLineIndex Index of the target leader line.
     * @param vertices New vertex sequence.
     * @returns The current entity instance for chaining.
     */
    setLeaderLineVertices(leaderIndex: number, leaderLineIndex: number, vertices: AcGePoint3dLike[]): this;
    /**
     * Gets cloned vertices from the specified leader line.
     *
     * @param leaderIndex Index of the leader branch.
     * @param leaderLineIndex Index of the leader line in the branch.
     * @returns A cloned vertex list so callers cannot mutate internal state.
     */
    getLeaderLineVertices(leaderIndex: number, leaderLineIndex: number): AcGePoint3d[];
    /**
     * Adds a break segment to a specific leader line.
     *
     * @param leaderIndex Index of the leader branch.
     * @param leaderLineIndex Index of the leader line.
     * @param start Break start point.
     * @param end Break end point.
     * @returns The current entity instance for chaining.
     */
    addBreak(leaderIndex: number, leaderLineIndex: number, start: AcGePoint3dLike, end: AcGePoint3dLike): this;
    /**
     * Sets the landing point for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param point New landing point, or `undefined` to clear it.
     * @returns The current entity instance for chaining.
     */
    setLandingPoint(leaderIndex: number, point: AcGePoint3dLike | undefined): this;
    /**
     * Sets the dogleg direction for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param vector New dogleg direction vector.
     * @returns The current entity instance for chaining.
     */
    setDoglegDirection(leaderIndex: number, vector: AcGeVector3dLike): this;
    /**
     * Sets the dogleg length for one leader branch.
     *
     * @param leaderIndex Index of the leader branch.
     * @param length New dogleg length, or `undefined` to clear the override.
     * @returns The current entity instance for chaining.
     */
    setDoglegLength(leaderIndex: number, length: number | undefined): this;
    /**
     * Gets the axis-aligned extents computed from all geometry points.
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets grip points used for interactive editing.
     *
     * @returns Cloned grip points derived from renderable geometry.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this multileader.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Applies a transformation matrix to this entity.
     *
     * @param matrix Transformation matrix applied to all geometry and vectors.
     * @returns The current entity instance for chaining.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     *
     * @returns The current entity instance with effective properties resolved.
     */
    resolveEffectiveProperties(): void;
    /**
     * Builds renderable primitives for this multileader entity.
     *
     * @param renderer Graphics renderer used to create draw entities.
     * @returns A single entity, an entity group, or undefined when nothing is drawable.
     */
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Writes this multileader entity to DXF group codes.
     *
     * @param filer DXF filer that receives serialized values.
     * @returns The current entity instance for chaining.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Finalizes MLEADER fields after DXF group codes are consumed.
     */
    private finishMLeaderDxfIn;
    /**
     * Parses the native AutoCAD `CONTEXT_DATA{ ... }` block (group 300/301).
     *
     * Mirrors dxf-json `parseContextData` so built-in DXF reading matches the
     * converter path used by `@mlightcad/dxf-json`.
     */
    private dxfInContextData;
    /**
     * Parses one `LEADER{ ... }` section (group 302/303) inside CONTEXT_DATA.
     */
    private dxfInLeaderSection;
    /**
     * Parses one `LEADER_LINE{ ... }` block (group 304/305) inside a LEADER section.
     */
    private dxfInLeaderLine;
    private readDxfBoolean;
    private isValidMLeaderHandle;
    /**
     * Creates a concrete point from point-like input.
     *
     * @param point Source point-like value.
     * @returns A newly created point instance.
     */
    private createPoint;
    /**
     * Normalizes one leader-line payload into internal storage format.
     *
     * @param line Source leader-line payload.
     * @returns A normalized leader line.
     */
    private createLeaderLine;
    /**
     * Creates a deep clone of a leader branch.
     *
     * @param leader Leader branch to clone.
     * @returns A deep-cloned leader branch.
     */
    private cloneLeader;
    /**
     * Validates that a leader index is in range.
     *
     * @param leaderIndex Leader branch index to validate.
     * @throws {Error} Thrown when `leaderIndex` is outside valid range.
     * @returns `void`.
     */
    private checkLeaderIndex;
    /**
     * Gets a mutable leader line by branch and line index.
     *
     * @param leaderIndex Leader branch index.
     * @param leaderLineIndex Leader-line index in the branch.
     * @returns The mutable leader line reference.
     */
    private getMutableLeaderLine;
    /**
     * Collects all geometry points contributing to draw/extents calculations.
     *
     * @returns Geometry point collection.
     */
    private collectGeometryPoints;
    /**
     * Moves one geometry grip point using the same index order as
     * {@link collectGeometryPoints}.
     */
    private moveGeometryGripPointAt;
    /**
     * Resolves the final draw points for a leader line.
     *
     * @param leader Owning leader branch.
     * @param line Leader line to resolve.
     * @returns The resolved draw-point sequence.
     */
    private getLeaderLineDrawPoints;
    /**
     * Computes the dogleg segment points for a leader branch.
     *
     * @param leader Leader branch to evaluate.
     * @returns Dogleg segment points, or `undefined` if not applicable.
     */
    private getDoglegPoints;
    /**
     * Builds arrowhead polyline points from leader-line points.
     *
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Arrowhead points, or `undefined` when no arrowhead is drawable.
     */
    private getArrowheadPoints;
    /**
     * Checks whether an arrowhead should be rendered.
     *
     * @returns `true` if arrowhead configuration is visible.
     */
    private isArrowheadVisible;
    /**
     * Draws one leader line and applies arrow style from MLEADER/MLEADERSTYLE.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line draw points.
     * @returns One entity or an entity group representing the full leader line.
     */
    private drawLeaderLine;
    /**
     * Resolves leader-line points used for stroke drawing after arrow overlap trim.
     *
     * @param points Original leader polyline points.
     * @returns Trimmed points used to draw the leader stroke.
     */
    private getLeaderLinePointsForDraw;
    /**
     * Resolves how much of leader start should be trimmed to avoid arrow overlap.
     *
     * @returns Trim distance in drawing units.
     */
    private getArrowheadLeaderLineTrimDistance;
    /**
     * Trims the start of a polyline by a given distance.
     *
     * @param points Polyline points.
     * @param trimDistance Distance to trim from the start.
     * @returns Trimmed polyline points.
     */
    private trimPolylineStart;
    /**
     * Draws one arrowhead primitive from leader-line points.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Arrowhead entity, or `undefined` when no arrowhead is drawable.
     */
    private drawArrowhead;
    /**
     * Draws arrowhead by rendering entities from referenced arrow block record.
     *
     * @param renderer Graphics renderer used to create primitives.
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Rendered block-based arrowhead entity, or `undefined`.
     */
    private drawArrowheadBlock;
    /**
     * Resolves tip point and direction for arrowhead placement.
     *
     * @param points Leader-line points where the first point is treated as tip.
     * @returns Tip and normalized direction, or `undefined` when unavailable.
     */
    private getArrowheadFrame;
    /**
     * Resolves the effective arrowhead id.
     *
     * @returns Arrowhead id used for rendering.
     */
    private getResolvedArrowheadId;
    /**
     * Resolves arrowhead block record by Arrowhead ID handle.
     *
     * @returns Arrowhead block table record, or `undefined` when not found.
     */
    private getResolvedArrowheadBlockTableRecord;
    /**
     * Resolves the effective arrowhead size.
     *
     * @returns Arrowhead size used for rendering.
     */
    private getResolvedArrowheadSize;
    /**
     * Resolves effective text height by style and override-flag rules.
     *
     * @returns Effective text height used for rendering.
     */
    private getResolvedTextHeight;
    /**
     * Resolves renderable MText content using entity content first, with style fallback.
     *
     * @returns Renderable text payload, or `undefined` when unavailable.
     */
    private getRenderableMTextContent;
    /**
     * Computes render width for current MText content.
     *
     * @param text Source MText content string.
     * @param textHeight Effective text height used for fallback estimation.
     * @returns Explicit width or an estimated width based on plain text length.
     */
    private getMTextRenderWidth;
    /**
     * Transforms a direction vector with an affine matrix.
     *
     * @param vector Vector to mutate.
     * @param matrix Transformation matrix.
     * @returns `void`.
     */
    private transformVector;
    /**
     * Resolves the referenced MLeader style object.
     *
     * @returns Resolved style object or `undefined` when not available.
     */
    private getMLeaderStyle;
    /**
     * Resolves the default MLEADER style from CMLEADERSTYLE, with first-entry fallback.
     *
     * @returns Default style object or `undefined` when style dictionary is empty.
     */
    private getDefaultMLeaderStyle;
    /**
     * Resolves one MLEADER style by style name (dictionary key) or object ID.
     *
     * @param styleName Style name or object id candidate.
     * @returns Matching style object, or `undefined` when not found.
     */
    private resolveMLeaderStyleByName;
    /**
     * Resolves current CMLEADERSTYLE value with a stable default fallback.
     *
     * @returns Preferred default style name.
     */
    private getDefaultMLeaderStyleName;
    /**
     * Resolves text style name considering entity values, ids and style fallback.
     *
     * @returns Resolved text style name, or `undefined` when unresolved.
     */
    private getResolvedTextStyleName;
    /**
     * Resolves the text style used by renderer-side MText drawing.
     *
     * @returns A valid text style object.
     */
    private getTextStyle;
    /**
     * Resolves effective leader-line color by override-flag and style rules.
     *
     * @returns Effective leader-line color.
     */
    private getResolvedLeaderLineColor;
    /**
     * Resolves effective leader-line geometry type.
     *
     * @returns Effective leader-line type.
     */
    private getResolvedLeaderLineType;
    /**
     * Resolves effective leader-line linetype id/handle.
     *
     * @returns Effective linetype id, or `undefined` when not available.
     */
    private getResolvedLeaderLineTypeId;
    /**
     * Resolves renderer linetype style for leader lines.
     *
     * @returns User-specified renderer linetype style, or `undefined`.
     */
    private getResolvedLeaderLineStyle;
    /**
     * Resolves effective leader-line weight by override-flag and style rules.
     *
     * @returns Effective line weight, or `undefined`.
     */
    private getResolvedLeaderLineWeight;
    /**
     * Resolves whether dogleg drawing is effectively enabled.
     *
     * @returns Effective dogleg-enabled state.
     */
    private getResolvedDoglegEnabled;
    /**
     * Resolves effective dogleg length by override-flag and style rules.
     *
     * @returns Effective dogleg length.
     */
    private getResolvedDoglegLength;
    /**
     * Resolves effective text color by override-flag and style rules.
     *
     * @returns Effective text color.
     */
    private getResolvedTextColor;
    /**
     * Resolves effective component color from entity raw value and style fallback.
     *
     * @param rawEntityColor Raw DXF color value stored on the entity.
     * @param styleColor Style-level fallback color.
     * @param overrideFlagMask Property-override flag mask for this component.
     * @returns Effective color used for rendering and trait application.
     */
    private getResolvedComponentColor;
    /**
     * Resolves effective value using override-flag and style fallback rules.
     *
     * @typeParam T Value type.
     * @param entityValue Value stored on the entity.
     * @param styleValue Value provided by style.
     * @param overrideFlagMask Property-override flag mask for this component.
     * @returns Effective resolved value.
     */
    private getResolvedStyleDrivenValue;
    /**
     * Checks whether a specific property-override bit is enabled.
     *
     * @param flagMask Bit mask for the property being queried.
     * @returns `true` if enabled, `false` if disabled, or `undefined` when flag is absent.
     */
    private isPropertyOverrideEnabled;
    /**
     * Applies color traits while preserving original values for reset.
     *
     * @param traits Renderer traits object to mutate.
     * @param color Effective component color to apply.
     * @param originalColor Original trait color value.
     * @param originalRgbColor Original trait RGB value.
     * @returns `void`.
     */
    private applyColorTraits;
    /**
     * Applies line style traits when resolved values are available.
     *
     * @param traits Renderer traits object to mutate.
     * @param lineType Resolved linetype style.
     * @param lineWeight Resolved line weight.
     * @returns `void`.
     */
    private applyLineTraits;
}
//# sourceMappingURL=AcDbMLeader.d.ts.map