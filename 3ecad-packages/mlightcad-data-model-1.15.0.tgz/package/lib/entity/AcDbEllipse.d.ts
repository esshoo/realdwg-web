import { AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGePointLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents an ellipse entity in AutoCAD.
 *
 * An ellipse is a 2D geometric object defined by its center point, major and minor axes,
 * and optional start and end angles. Ellipses are curved shapes that can be used to
 * create elliptical shapes in drawings. The ellipse is always drawn in the plane
 * defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a full ellipse
 * const ellipse = new AcDbEllipse(
 *   new AcGePoint3d(0, 0, 0),
 *   AcGeVector3d.Z_AXIS,
 *   AcGeVector3d.X_AXIS,
 *   10, // major axis radius
 *   5,  // minor axis radius
 *   0,  // start angle
 *   2 * Math.PI // end angle (full ellipse)
 * );
 *
 * // Access ellipse properties
 * console.log(`Center: ${ellipse.center}`);
 * console.log(`Major radius: ${ellipse.majorAxisRadius}`);
 * console.log(`Minor radius: ${ellipse.minorAxisRadius}`);
 * ```
 */
export declare class AcDbEllipse extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Backing for the lazily materialized geometric ellipse arc object. */
    private _geoData;
    /**
     * The underlying geometric ellipse arc object. Materialized lazily so that
     * factory-created entities (dxfIn path) never allocate default geometry.
     */
    private get _geo();
    private set _geo(value);
    /**
     * Creates a new ellipse entity.
     *
     * This constructor creates an ellipse using the specified center point, normal vector,
     * major axis, and radii. The center point must be in World Coordinate System (WCS) coordinates.
     *
     * @param center - The center point of the ellipse in WCS coordinates
     * @param normal - The normal vector defining the plane of the ellipse
     * @param majorAxis - The major axis vector in WCS coordinates
     * @param majorAxisRadius - The radius of the major axis (must be positive)
     * @param minorAxisRadius - The radius of the minor axis (must be positive)
     * @param startAngle - The starting angle in radians (0 to 2?)
     * @param endAngle - The ending angle in radians (0 to 2?)
     *
     * @example
     * ```typescript
     * // Create a full ellipse in the XY plane
     * const fullEllipse = new AcDbEllipse(
     *   new AcGePoint3d(0, 0, 0),
     *   AcGeVector3d.Z_AXIS,
     *   AcGeVector3d.X_AXIS,
     *   20, // major radius
     *   10, // minor radius
     *   0,
     *   2 * Math.PI
     * );
     *
     * // Create a quarter ellipse
     * const quarterEllipse = new AcDbEllipse(
     *   new AcGePoint3d(10, 20, 0),
     *   AcGeVector3d.Z_AXIS,
     *   AcGeVector3d.X_AXIS,
     *   15,
     *   8,
     *   0,
     *   Math.PI / 2
     * );
     * ```
     */
    constructor();
    constructor(center: AcGePointLike, normal: AcGeVector3dLike, majorAxis: AcGeVector3dLike, majorAxisRadius: number, minorAxisRadius: number, startAngle: number, endAngle: number);
    /**
     * Gets the center point of this ellipse.
     *
     * @returns The center point as a 3D point
     *
     * @example
     * ```typescript
     * const centerPoint = ellipse.center;
     * console.log(`Ellipse center: ${centerPoint.x}, ${centerPoint.y}, ${centerPoint.z}`);
     * ```
     */
    get center(): AcGePoint3d;
    /**
     * Sets the center point of this ellipse.
     *
     * @param value - The new center point
     *
     * @example
     * ```typescript
     * ellipse.center = new AcGePoint3d(5, 5, 0);
     * ```
     */
    set center(value: AcGePoint3dLike);
    /**
     * Gets the major axis radius of this ellipse.
     *
     * @returns The major axis radius value
     *
     * @example
     * ```typescript
     * const majorRadius = ellipse.majorAxisRadius;
     * console.log(`Major radius: ${majorRadius}`);
     * ```
     */
    get majorAxis(): AcGeVector3dLike;
    get majorAxisRadius(): number;
    /**
     * Sets the major axis radius of this ellipse.
     *
     * @param value - The new major axis radius value (must be positive)
     *
     * @example
     * ```typescript
     * ellipse.majorAxisRadius = 25;
     * ```
     */
    set majorAxisRadius(value: number);
    /**
     * Gets the minor axis radius of this ellipse.
     *
     * @returns The minor axis radius value
     *
     * @example
     * ```typescript
     * const minorRadius = ellipse.minorAxisRadius;
     * console.log(`Minor radius: ${minorRadius}`);
     * ```
     */
    get minorAxisRadius(): number;
    /**
     * Sets the minor axis radius of this ellipse.
     *
     * @param value - The new minor axis radius value (must be positive)
     *
     * @example
     * ```typescript
     * ellipse.minorAxisRadius = 12;
     * ```
     */
    set minorAxisRadius(value: number);
    /**
     * Gets the start angle of this ellipse.
     *
     * @returns The start angle in radians
     *
     * @example
     * ```typescript
     * const startAngle = ellipse.startAngle;
     * console.log(`ellipse start angle: ${startAngle} radians (${startAngle * 180 / Math.PI} degrees)`);
     * ```
     */
    get startAngle(): number;
    /**
     * Sets the start angle of this ellipse.
     *
     * @param value - The new start angle in radians (0 to 2?)
     *
     * @example
     * ```typescript
     * ellipse.startAngle = Math.PI / 4; // 45 degrees
     * ```
     */
    set startAngle(value: number);
    /**
     * Gets the end angle of this ellipse.
     *
     * @returns The end angle in radians
     *
     * @example
     * ```typescript
     * const endAngle = ellipse.endAngle;
     * console.log(`ellipse end angle: ${endAngle} radians (${endAngle * 180 / Math.PI} degrees)`);
     * ```
     */
    get endAngle(): number;
    /**
     * Sets the end angle of this ellipse.
     *
     * @param value - The new end angle in radians (0 to 2?)
     *
     * @example
     * ```typescript
     * ellipse.endAngle = Math.PI; // 180 degrees
     * ```
     */
    set endAngle(value: number);
    /**
     * Gets the normal vector of this ellipse.
     *
     * The normal vector defines the plane in which the ellipse lies.
     *
     * @returns The unit normal vector in WCS coordinates
     *
     * @example
     * ```typescript
     * const normal = ellipse.normal;
     * console.log(`Ellipse normal: ${normal.x}, ${normal.y}, ${normal.z}`);
     * ```
     */
    get normal(): AcGeVector3dLike;
    /**
     * Sets the normal vector of this ellipse.
     *
     * @param value - The new normal vector
     *
     * @example
     * ```typescript
     * ellipse.normal = AcGeVector3d.Y_AXIS;
     * ```
     */
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the geometric extents (bounding box) of this ellipse.
     *
     * @returns The bounding box that encompasses the entire ellipse
     *
     * @example
     * ```typescript
     * const extents = ellipse.geometricExtents;
     * console.log(`Ellipse bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): import("@mlightcad/geometry-engine").AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets whether this ellipse is closed.
     *
     * A full ellipse may be stored either with identical start/end angles (AutoCAD
     * convention) or with a 0??? parameter span. Both represent a closed curve.
     *
     * @returns True if the ellipse is closed (forms a complete ellipse), false otherwise
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Gets the grip points for this ellipse.
     *
     * Closed ellipses return the center and four quadrant points.
     * Open ellipse arcs return the center, start point, and end point.
     *
     * @returns Array of grip points
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this ellipse or ellipse arc.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this ellipse by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this ellipse entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable properties via {@link AcDbPropertyAccessor}
     * so the property palette can update the ellipse in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * This ellipse always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * Draws this ellipse using the specified renderer.
     *
     * This method renders the ellipse as an elliptical arc using the ellipse's
     * current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered ellipse entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private applyDxfInGeometry;
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    private moveGripAt;
    /**
     * Moves a quadrant grip on a closed ellipse by updating the corresponding axis radius.
     *
     * Grips at 0? and 180? adjust {@link majorAxisRadius}; grips at 90? and 270? adjust
     * {@link minorAxisRadius}. The new radius is the absolute projection of the dragged
     * point onto the relevant axis from the ellipse center.
     *
     * @param angle - Quadrant angle in radians (0, ?/2, ?, or 3?/2).
     * @param offset - Translation applied to the grip point before recomputing the radius.
     * @private
     */
    private moveQuadrantGripAt;
    private createOffsetCurve;
}
//# sourceMappingURL=AcDbEllipse.d.ts.map