import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbEntity } from './AcDbEntity';
/**
 * Construction options for {@link AcDb3dSolid} when geometry is supplied as
 * binary SAB and/or plain SAT/ASM text rather than a single string argument.
 */
export interface AcDb3dSolidOptions {
    /** Binary SAB payload from ACDSDATA or inline modeler geometry. */
    sabBytes?: Uint8Array;
    /** Plain SAT/ASM text from inline groups 1/3 or ACSH BREP. */
    satText?: string;
    /** Legacy alias for {@link satText}. */
    acisData?: string;
    /** DXF group 70 ACIS version number, when present. */
    version?: number;
}
/**
 * Represents a 3D solid (ACIS/ASM B-rep) entity, such as those created by
 * AutoCAD's BOX, WEDGE, EXTRUDE, or boolean solid-modeling commands.
 *
 * Full B-rep tessellation is not yet supported. When binary SAB or SAT text is
 * available, this entity renders a best-effort wireframe derived from decoded
 * edges and curves; otherwise it falls back to a bounding-box wireframe built
 * from embedded `point` records in the SAT stream.
 */
export declare class AcDb3dSolid extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Raw ACIS SAT text preserved for DXF round-trip and future B-rep parsing. */
    private _acisData;
    /** Binary SAB/ASM payload from ACDSDATA, when present. */
    private _sabBytes?;
    /** DXF group 70 ACIS version number, when present. */
    private _version?;
    /** Soft-pointer to ACSH history object (DXF group 350). */
    private _historyObjectSoftId?;
    /** Revision GUID for the modeler geometry, when present (DXF group 2). */
    private _guid?;
    /** Whether the ASM/ACIS payload uses SAT text caching (DXF group 290). */
    private _satCache?;
    /** Vertex positions used for extents and fallback bounding-box rendering. */
    private _points;
    /** Line-segment endpoint pairs for wireframe rendering (`[x,y,z,...]`). */
    private _wireframe;
    /**
     * Creates a new 3D solid entity from raw ACIS data.
     *
     * @param acisData - Raw ACIS SAT text (group 1/3 lines).
     * @param version - DXF group 70 ACIS version number, when present.
     */
    constructor(acisData: string, version?: number);
    /**
     * Creates a new 3D solid entity from binary SAB and/or SAT text payloads.
     *
     * @param options - Construction options with optional SAB bytes and SAT text.
     */
    constructor(options: AcDb3dSolidOptions);
    /**
     * Raw ACIS SAT text for this solid, preserved for future full B-rep parsing.
     */
    get acisData(): string;
    /** DXF group 70 ACIS version number, when present. */
    get version(): number | undefined;
    /**
     * Soft-pointer handle to `ACSH_HISTORY_CLASS` (DXF group 350), when present.
     * Resolved later when OBJECTS-section data is available.
     */
    get historyObjectSoftId(): string | undefined;
    set historyObjectSoftId(value: string | undefined);
    /**
     * Revision GUID for the modeler geometry, when present (DXF group 2).
     */
    get guid(): string | undefined;
    set guid(value: string | undefined);
    /**
     * Whether the ASM/ACIS payload uses SAT text caching (DXF group 290).
     */
    get satCache(): boolean | undefined;
    set satCache(value: boolean | undefined);
    /**
     * Replaces the SAT/ACIS payload and rebuilds wireframe / point caches.
     * Used by DXF import after constructing an empty solid.
     */
    setAcisData(satText: string, version?: number): void;
    /**
     * Attaches binary SAB/ASM bytes (typically from ACDSDATA) and rebuilds
     * wireframe / point caches. Preferred over SAT text when both are present.
     *
     * @param sabBytes - Raw ASM_Data payload for this solid.
     */
    setSabBytes(sabBytes: Uint8Array | undefined): void;
    /** Binary SAB/ASM payload attached via ACDSDATA or construction options. */
    get sabBytes(): Uint8Array | undefined;
    /**
     * Rebuilds `_wireframe` / `_points` from SAB bytes (preferred) or SAT text.
     */
    private rebuildGeometryCaches;
    /**
     * Whether wireframe segments or fallback point data could be extracted from
     * the supplied SAB/SAT payload.
     */
    get hasRenderableGeometry(): boolean;
    /** @inheritdoc */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Transforms the extracted wireframe and point cloud by the specified matrix.
     *
     * {@link acisData} itself is left untouched since it isn't fully parsed.
     *
     * @param matrix - 4×4 transformation matrix.
     * @returns This instance (for chaining).
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Draws decoded wireframe segments when available; otherwise draws a bounding
     * box around extracted `point` records.
     *
     * @param renderer - The renderer to use for drawing.
     * @returns The rendered wireframe entity, or `undefined` when no geometry
     * could be extracted.
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity | undefined;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDb3dSolid.d.ts.map