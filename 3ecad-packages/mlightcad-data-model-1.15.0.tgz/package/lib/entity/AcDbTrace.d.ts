import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint2d, AcGePoint3d, AcGePoint3dLike, AcGePointLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
/**
 * Represents a trace entity in AutoCAD.
 *
 * A trace is a 3D geometric object that represents a filled four-sided polygon.
 * It is typically used to create trace-like shapes and can be visualized as a
 * "filled polyline" with four vertices, where each edge connects two consecutive points.
 *
 * This entity was more commonly used in earlier versions of AutoCAD, especially before
 * the introduction of more advanced entities like solid and hatches. Today, it's not
 * as commonly used since solid provides similar capabilities with more flexibility.
 *
 * @example
 * ```typescript
 * // Create a trace entity
 * const trace = new AcDbTrace();
 * trace.setPointAt(0, new AcGePoint3d(0, 0, 0));
 * trace.setPointAt(1, new AcGePoint3d(10, 0, 0));
 * trace.setPointAt(2, new AcGePoint3d(10, 5, 0));
 * trace.setPointAt(3, new AcGePoint3d(0, 5, 0));
 *
 * // Access trace properties
 * console.log(`Elevation: ${trace.elevation}`);
 * console.log(`Thickness: ${trace.thickness}`);
 * ```
 */
export declare class AcDbTrace extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The elevation (Z-coordinate) of the trace plane */
    private _elevation;
    /** The four vertices of the trace */
    private _vertices;
    /** The thickness (extrusion) of the trace */
    private _thickness;
    /** Extrusion / plane normal (DXF group 210) */
    private _normal;
    /**
     * Creates a new trace entity.
     *
     * This constructor initializes a trace with default values.
     * All vertices are set to the origin, elevation is 0, and thickness is 0.
     *
     * @example
     * ```typescript
     * const trace = new AcDbTrace();
     * // Set the four vertices to create a rectangle
     * trace.setPointAt(0, new AcGePoint3d(0, 0, 0));
     * trace.setPointAt(1, new AcGePoint3d(10, 0, 0));
     * trace.setPointAt(2, new AcGePoint3d(10, 5, 0));
     * trace.setPointAt(3, new AcGePoint3d(0, 5, 0));
     * ```
     */
    constructor();
    /**
     * Gets the elevation of this trace.
     *
     * The elevation is the distance of the trace's plane from the WCS origin
     * along the Z-axis.
     *
     * @returns The elevation value
     *
     * @example
     * ```typescript
     * const elevation = trace.elevation;
     * console.log(`Trace elevation: ${elevation}`);
     * ```
     */
    get elevation(): number;
    /**
     * Sets the elevation of this trace.
     *
     * @param value - The new elevation value
     *
     * @example
     * ```typescript
     * trace.elevation = 10;
     * ```
     */
    set elevation(value: number);
    /**
     * Gets whether this trace is closed.
     *
     * Traces are always closed entities, so this always returns true.
     *
     * @returns Always true for traces
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Gets the thickness of this trace.
     *
     * The thickness is the trace's dimension along its normal vector direction
     * (sometimes called the extrusion direction).
     *
     * @returns The thickness value
     *
     * @example
     * ```typescript
     * const thickness = trace.thickness;
     * console.log(`Trace thickness: ${thickness}`);
     * ```
     */
    get thickness(): number;
    /**
     * Sets the thickness of this trace.
     *
     * @param value - The new thickness value
     *
     * @example
     * ```typescript
     * trace.thickness = 2.0;
     * ```
     */
    set thickness(value: number);
    /**
     * Extrusion direction / plane normal (DXF group 210).
     */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the point at the specified index in this trace.
     *
     * The index can be 0, 1, 2, or 3, representing the four vertices of the trace.
     * If the index is out of range, it returns the first or last vertex accordingly.
     *
     * @param index - The index (0-3) of the vertex to get
     * @returns The point at the specified index in WCS coordinates
     *
     * @example
     * ```typescript
     * const point0 = trace.getPointAt(0);
     * const point1 = trace.getPointAt(1);
     * console.log(`Vertex 0: ${point0.x}, ${point0.y}, ${point0.z}`);
     * ```
     */
    getPointAt(index: number): AcGePoint3d;
    /**
     * Sets the point at the specified index in this trace.
     *
     * The index must be 0, 1, 2, or 3, representing the four vertices of the trace.
     * If the index is out of range, it sets the first or last vertex accordingly.
     *
     * @param index - The index (0-3) of the vertex to set
     * @param point - The new point in WCS coordinates
     *
     * @example
     * ```typescript
     * trace.setPointAt(0, new AcGePoint3d(0, 0, 0));
     * trace.setPointAt(1, new AcGePoint3d(10, 0, 0));
     * trace.setPointAt(2, new AcGePoint3d(10, 5, 0));
     * trace.setPointAt(3, new AcGePoint3d(0, 5, 0));
     * ```
     */
    setPointAt(index: number, point: AcGePointLike): AcGePoint3d | undefined;
    /**
     * Gets the geometric extents (bounding box) of this trace.
     *
     * @returns The bounding box that encompasses the entire trace
     *
     * @example
     * ```typescript
     * const extents = trace.geometricExtents;
     * console.log(`Trace bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this trace.
     *
     * Grip points are control points that can be used to modify the trace.
     * For a trace, the grip points are all four vertices.
     *
     * @returns Array of grip points (all four vertices)
     *
     * @example
     * ```typescript
     * const gripPoints = trace.subGetGripPoints();
     * // gripPoints contains all four vertices of the trace
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this trace.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this trace by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * This trace always draws as a single `area` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "area";
    /**
     * Draws this trace using the specified renderer.
     *
     * This method renders the trace as a filled area using the trace's
     * current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered trace entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the quadrilateral boundary (four corners in vertex order) as a closed
     * {@link AcDbPolyline} in the XY plane.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Treats the trace outline as a closed polygon in XY.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline around the trace boundary, or `null` on failure
     */
    private createOffsetCurve;
    /**
     * Projects the four trace corners to a closed 2D loop (codes 10–13 order).
     *
     * @returns XY boundary vertices
     */
    private collectBoundary2d;
    /**
     * Builds the closed 2D boundary for TRACE/SOLID entities.
     *
     * DXF stores corners 10–13 as two opposite edges (1–2 and 3–4), not as a
     * sequential perimeter. The filled outline follows 1 → 2 → 4 → 3.
     */
    static boundaryPointsFromVertices(vertices: ReadonlyArray<AcGePoint3dLike>): AcGePoint2d[];
}
//# sourceMappingURL=AcDbTrace.d.ts.map