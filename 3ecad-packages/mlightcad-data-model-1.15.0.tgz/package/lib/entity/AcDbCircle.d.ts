import { AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGePointLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a circle entity in AutoCAD.
 *
 * A circle is a 2D geometric object defined by its center point and radius.
 * Circles are closed curves that can be used to create circular shapes
 * in drawings. The circle is always drawn in the plane defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a circle with center at (0,0,0) and radius 5
 * const circle = new AcDbCircle(
 *   new AcGePoint3d(0, 0, 0),
 *   5
 * );
 *
 * // Access circle properties
 * console.log(`Center: ${circle.center}`);
 * console.log(`Radius: ${circle.radius}`);
 * console.log(`Normal: ${circle.normal}`);
 * ```
 */
export declare class AcDbCircle extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Backing for the lazily materialized geometric circular arc object. */
    private _geoData;
    /** Thickness along the normal (DXF group 39) */
    private _thickness;
    /**
     * The underlying geometric circular arc object. Materialized lazily so that
     * factory-created entities (dxfIn path) never allocate default geometry.
     */
    private get _geo();
    private set _geo(value);
    /**
     * Creates a new circle entity.
     *
     * This constructor creates a circle using the specified center point and radius.
     * The center point must be in World Coordinate System (WCS) coordinates.
     * The circle is created as a full circle (0 to 2π radians).
     *
     * @param center - The center point of the circle in WCS coordinates
     * @param radius - The radius of the circle (must be positive)
     * @param normal - The normal vector defining the plane of the circle (defaults to Z-axis)
     *
     * @example
     * ```typescript
     * // Create a circle in the XY plane
     * const circle = new AcDbCircle(
     *   new AcGePoint3d(10, 20, 0),
     *   15
     * );
     *
     * // Create a circle in a different plane
     * const circleInYZ = new AcDbCircle(
     *   new AcGePoint3d(0, 0, 0),
     *   10,
     *   AcGeVector3d.X_AXIS
     * );
     * ```
     */
    constructor();
    constructor(center: AcGePointLike, radius: number, normal?: AcGeVector3dLike);
    /**
     * Gets the center point of this circle.
     *
     * @returns The center point as a 3D point
     *
     * @example
     * ```typescript
     * const centerPoint = circle.center;
     * console.log(`Circle center: ${centerPoint.x}, ${centerPoint.y}, ${centerPoint.z}`);
     * ```
     */
    get center(): AcGePoint3d;
    /**
     * Sets the center point of this circle.
     *
     * @param value - The new center point
     *
     * @example
     * ```typescript
     * circle.center = new AcGePoint3d(5, 5, 0);
     * ```
     */
    set center(value: AcGePoint3dLike);
    /**
     * Gets the radius of this circle.
     *
     * @returns The radius value
     *
     * @example
     * ```typescript
     * const radius = circle.radius;
     * console.log(`Circle radius: ${radius}`);
     * ```
     */
    get radius(): number;
    /**
     * Sets the radius of this circle.
     *
     * @param value - The new radius value (must be positive)
     *
     * @example
     * ```typescript
     * circle.radius = 25;
     * ```
     */
    set radius(value: number);
    /**
     * Gets the normal vector of this circle.
     *
     * The normal vector defines the plane in which the circle lies.
     *
     * @returns The unit normal vector in WCS coordinates
     *
     * @example
     * ```typescript
     * const normal = circle.normal;
     * console.log(`Circle normal: ${normal.x}, ${normal.y}, ${normal.z}`);
     * ```
     */
    get normal(): AcGeVector3d;
    /**
     * Thickness along the entity normal (DXF group 39).
     */
    get thickness(): number;
    set thickness(value: number);
    /**
     * Gets the geometric extents (bounding box) of this circle.
     *
     * @returns The bounding box that encompasses the entire circle
     *
     * @example
     * ```typescript
     * const extents = circle.geometricExtents;
     * console.log(`Circle bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): import("@mlightcad/geometry-engine").AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets whether this circle is closed.
     *
     * Circles are always closed entities, so this always returns true.
     *
     * @returns Always true for circles
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Gets the object snap points for this circle.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Returns the full property definition for this circle entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable center coordinates and radius via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the circle in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this circle.
     *
     * Grip points are control points that can be used to modify the circle.
     * For a circle, the grip points are the center and the four quadrant
     * points at 0°, 90°, 180°, and 270°.
     *
     * @returns Array of grip points (center, then quadrant points)
     *
     * @example
     * ```typescript
     * const gripPoints = circle.subGetGripPoints();
     * // gripPoints contains: [center, q0, q90, q180, q270]
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Transforms this circle by the specified matrix.
     *
     * This method applies a geometric transformation to the circle, updating
     * the center point, radius, and normal vector according to the transformation matrix.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This circle after transformation
     *
     * @example
     * ```typescript
     * const translationMatrix = AcGeMatrix3d.translation(10, 0, 0);
     * circle.transformBy(translationMatrix);
     * // Circle is now translated 10 units in the X direction
     * ```
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * This circle always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * Draws this circle using the specified renderer.
     *
     * This method renders the circle as a circular arc using the circle's
     * current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered circle entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private applyDxfInGeometry;
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    private createOffsetCurve;
    private moveGripAt;
}
//# sourceMappingURL=AcDbCircle.d.ts.map