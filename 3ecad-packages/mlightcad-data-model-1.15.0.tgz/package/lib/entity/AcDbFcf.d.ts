import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a feature control frame (FCF) entity in AutoCAD.
 *
 * Feature control frames are used for geometric dimensioning and tolerancing
 * (GD&T). They are created by the TOLERANCE command and controlled by dimension
 * styles, mirroring {@link https://help.autodesk.com/view/OARX/2023/ENU/?guid=OARX-RefGuide-AcDbFcf AcDbFcf}
 * in ObjectARX.
 *
 * @example
 * ```typescript
 * const fcf = new AcDbFcf();
 * fcf.location = new AcGePoint3d(10, 20, 0);
 * fcf.text = '{\\Fgdt.shx|b0|i0|c134|p6;j}|0.05|A|';
 * fcf.dimensionStyle = 'Standard';
 * ```
 */
export declare class AcDbFcf extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /**
     * The insertion point of the feature control frame in WCS coordinates.
     *
     * This is the center of the left edge for the first row in the entity-local
     * frame. Geometry uses +localX along {@link direction}; when direction points
     * left (e.g. leader on the right), this insertion point coincides with the
     * right-edge center in WCS.
     */
    private _location;
    /** The encoded tolerance text string (symbol and format codes). */
    private _text;
    /** The dimension style name applied to this feature control frame. */
    private _dimensionStyle;
    /** The plane normal vector in WCS coordinates. */
    private _normal;
    /** The X-axis direction vector for the feature control frame in WCS coordinates. */
    private _direction;
    /**
     * Creates a new feature control frame entity at the origin with default orientation.
     */
    constructor();
    /**
     * Gets the insertion point of this feature control frame.
     *
     * Mirrors `AcDbFcf::location()` in ObjectARX.
     */
    get location(): AcGePoint3d;
    /**
     * Sets the insertion point of this feature control frame.
     *
     * Mirrors `AcDbFcf::setLocation()` in ObjectARX.
     */
    set location(value: AcGePoint3dLike);
    /**
     * Gets the encoded tolerance text string.
     *
     * Mirrors `AcDbFcf::text()` in ObjectARX.
     */
    get text(): string;
    /**
     * Sets the encoded tolerance text string.
     *
     * Mirrors `AcDbFcf::setText()` in ObjectARX.
     */
    set text(value: string);
    /**
     * Gets the dimension style name applied to this feature control frame.
     */
    get dimensionStyle(): string;
    /**
     * Sets the dimension style name applied to this feature control frame.
     */
    set dimensionStyle(value: string);
    /**
     * Gets the plane normal vector in WCS coordinates.
     *
     * Mirrors `AcDbFcf::normal()` in ObjectARX.
     */
    get normal(): AcGeVector3d;
    /**
     * Sets the plane normal vector in WCS coordinates.
     */
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the X-axis direction vector in WCS coordinates.
     *
     * Mirrors `AcDbFcf::direction()` in ObjectARX.
     */
    get direction(): AcGeVector3d;
    /**
     * Sets the X-axis direction vector in WCS coordinates.
     */
    set direction(value: AcGeVector3dLike);
    /**
     * Sets the plane normal and X-axis direction for this feature control frame.
     *
     * Mirrors `AcDbFcf::setOrientation()` in ObjectARX.
     */
    setOrientation(normal: AcGeVector3dLike, direction: AcGeVector3dLike): this;
    /**
     * Returns the consecutive distinct corner points of the feature control frame.
     *
     * Mirrors `AcDbFcf::getBoundingPoints()` in ObjectARX.
     */
    getBoundingPoints(): AcGePoint3d[];
    /**
     * Returns the closed bounding polyline of the feature control frame.
     *
     * Mirrors `AcDbFcf::getBoundingPolyline()` in ObjectARX.
     */
    getBoundingPolyline(): AcGePoint3d[];
    get geometricExtents(): AcGeBox3d;
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    transformBy(matrix: AcGeMatrix3d): this;
    get properties(): AcDbEntityProperties;
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Gets the rendered text height derived from the associated dimension style.
     */
    get textHeight(): number;
    private drawToleranceText;
    private collectFrameLineSegments;
    private toFrameWcs;
    private resolveFrameLayout;
    private parseToleranceFrame;
    private splitToleranceRows;
    private splitToleranceTokens;
    private parsePipeSeparatedCells;
    private resolveLocalBasis;
    private resolveDimensionStyle;
    private tryGetDatabase;
    private getTextStyle;
}
//# sourceMappingURL=AcDbFcf.d.ts.map