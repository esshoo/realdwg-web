import { AcDbAlignedDimension } from './AcDbAlignedDimension';
/**
 * Represents a rotated linear dimension entity in AutoCAD.
 *
 * A rotated dimension is similar to an aligned dimension, but its dimension line
 * direction is controlled by an explicit rotation angle.
 */
export declare class AcDbRotatedDimension extends AcDbAlignedDimension {
    /** The entity type name */
    static typeName: string;
    /**
     * @inheritdoc
     */
    protected get dxfSubclassMarker(): string;
}
//# sourceMappingURL=AcDbRotatedDimension.d.ts.map