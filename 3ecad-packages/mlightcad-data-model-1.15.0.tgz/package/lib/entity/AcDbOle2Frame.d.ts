import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntityProperties } from './AcDbEntityProperties';
import { AcDbOleFrame } from './AcDbOleFrame';
/**
 * OLE object type stored with an {@link AcDbOle2Frame} (DXF group code 71).
 *
 * @see https://help.autodesk.com/cloudhelp/2018/ENU/AutoCAD-DXF/files/GUID-77747CE6-82C6-4452-97ED-4CEEB38BE960.htm
 */
export declare enum AcDbOleObjectType {
    /** Linked OLE object */
    Link = 1,
    /** Embedded OLE object */
    Embedded = 2,
    /** Static OLE object */
    Static = 3
}
/**
 * Tile-mode descriptor stored with an {@link AcDbOle2Frame} (DXF group code 72).
 *
 * Distinct from the common entity paper-space flag (group code 67).
 */
export declare enum AcDbOleTileMode {
    /** Object resides in model space */
    ModelSpace = 0,
    /** Object resides in paper space */
    PaperSpace = 1
}
/**
 * Axis-aligned OLE frame rectangle in WCS, analogous to ObjectARX
 * `CRectangle3d`.
 */
export interface AcDbOleRectangle3d {
    /** Upper-left corner in WCS */
    upperLeft: AcGePoint3dLike;
    /** Upper-right corner in WCS */
    upperRight: AcGePoint3dLike;
    /** Lower-left corner in WCS */
    lowerLeft: AcGePoint3dLike;
    /** Lower-right corner in WCS */
    lowerRight: AcGePoint3dLike;
}
/**
 * Represents an OLE 2 frame entity in AutoCAD.
 *
 * {@link AcDbOle2Frame} provides a display frame for an OLE 2 object. It stores
 * frame geometry (location, width, height, rotation), display settings, link
 * metadata, and the embedded OLE binary payload inherited from
 * {@link AcDbOleFrame}.
 *
 * Platform-specific MFC types such as `COleClientItem` are represented as opaque
 * values in this TypeScript port.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbOle2Frame
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-__MEMBERTYPE_Methods_AcDbOle2Frame
 *
 * @example
 * ```typescript
 * const ole = new AcDbOle2Frame()
 * ole.setLocation(new AcGePoint3d(0, 10, 0))
 * ole.setWcsWidth(100)
 * ole.setWcsHeight(75)
 * ole.userType = 'Paintbrush Picture'
 * ole.oleObjectType = AcDbOleObjectType.Embedded
 * ```
 */
export declare class AcDbOle2Frame extends AcDbOleFrame {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Upper-left corner of the frame in WCS. */
    private _upperLeft;
    /** Lower-right corner of the frame in WCS. */
    private _lowerRight;
    /** Rotation angle in radians. */
    private _rotation;
    /** Relative scale factor applied to the frame width. */
    private _scaleWidth;
    /** Relative scale factor applied to the frame height. */
    private _scaleHeight;
    /** Whether the aspect ratio is locked. */
    private _lockAspect;
    /** Output quality value (DXF group code 73 when present). */
    private _outputQuality;
    /** Automatic output quality flag. */
    private _autoOutputQuality;
    /** OLE object type (link / embedded / static). */
    private _oleObjectType;
    /** Tile-mode descriptor. */
    private _tileMode;
    /** User-visible OLE type description (DXF group code 3). */
    private _userType;
    /** Linked OLE object name. */
    private _linkName;
    /** Linked OLE object path. */
    private _linkPath;
    /**
     * Opaque host OLE client item.
     *
     * Mirrors ObjectARX `COleClientItem*`. There is no MFC host in the browser
     * runtime, so this value is application-defined.
     */
    private _oleClientItem;
    /** Cached image decoded from the OLE binary payload. */
    private _image?;
    /** Whether image extraction from the current OLE payload has been attempted. */
    private _imageResolved;
    /**
     * Creates a new OLE 2 frame entity.
     *
     * Objects created with this constructor must receive a valid OLE payload
     * through {@link setOleObject} (or host-specific client-item APIs) before they
     * represent a complete OLE entity.
     */
    constructor();
    /**
     * Gets the upper-left corner of this frame in WCS.
     */
    get upperLeftCorner(): AcGePoint3d;
    /**
     * Sets the upper-left corner of this frame in WCS.
     */
    set upperLeftCorner(value: AcGePoint3dLike);
    /**
     * Gets the lower-right corner of this frame in WCS.
     */
    get lowerRightCorner(): AcGePoint3d;
    /**
     * Sets the lower-right corner of this frame in WCS.
     */
    set lowerRightCorner(value: AcGePoint3dLike);
    /**
     * Gets the location (upper-left corner) of this OLE frame in WCS.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getLocation`.
     */
    getLocation(result?: AcGePoint3d): AcGePoint3d;
    /**
     * Sets the location (upper-left corner) of this OLE frame in WCS.
     *
     * The lower-right corner is translated by the same delta so the frame size is
     * preserved.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setLocation`.
     */
    setLocation(value: AcGePoint3dLike): void;
    /**
     * Gets the frame rectangle in WCS.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::position(CRectangle3d&)`.
     */
    position(): AcDbOleRectangle3d;
    /**
     * Sets the frame rectangle in WCS from the given corner points.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setPosition(const CRectangle3d&)`.
     * Only the upper-left and lower-right corners are stored; the other two
     * corners are derived.
     */
    setPosition(rect: AcDbOleRectangle3d): void;
    /**
     * Gets the frame width in WCS units.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::wcsWidth`.
     */
    wcsWidth(): number;
    /**
     * Sets the frame width in WCS units, keeping the upper-left corner fixed.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setWcsWidth`.
     */
    setWcsWidth(value: number): void;
    /**
     * Gets the frame height in WCS units.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::wcsHeight`.
     */
    wcsHeight(): number;
    /**
     * Sets the frame height in WCS units, keeping the upper-left corner fixed.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setWcsHeight`.
     */
    setWcsHeight(value: number): void;
    /**
     * Gets the relative width scale factor.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::scaleWidth`.
     */
    scaleWidth(): number;
    /**
     * Sets the relative width scale factor.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setScaleWidth`.
     */
    setScaleWidth(value: number): void;
    /**
     * Gets the relative height scale factor.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::scaleHeight`.
     */
    scaleHeight(): number;
    /**
     * Sets the relative height scale factor.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setScaleHeight`.
     */
    setScaleHeight(value: number): void;
    /**
     * Gets the rotation angle of this frame in radians.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::rotation`.
     */
    rotation(): number;
    /**
     * Sets the rotation angle of this frame in radians.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setRotation`.
     */
    setRotation(value: number): void;
    /**
     * Returns whether the frame aspect ratio is locked.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::lockAspect`.
     */
    lockAspect(): boolean;
    /**
     * Sets whether the frame aspect ratio is locked.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setLockAspect`.
     */
    setLockAspect(value: boolean | number): void;
    /**
     * Gets the output quality value.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::outputQuality`.
     */
    outputQuality(): number;
    /**
     * Sets the output quality value.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setOutputQuality`.
     */
    setOutputQuality(value: number): void;
    /**
     * Gets the automatic output quality flag.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::autoOutputQuality`.
     */
    autoOutputQuality(): number;
    /**
     * Sets the automatic output quality flag.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setAutoOutputQuality`.
     */
    setAutoOutputQuality(value: number): void;
    /**
     * Gets the OLE object type (link / embedded / static).
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getType`.
     */
    getType(): AcDbOleObjectType;
    /**
     * Sets the OLE object type (link / embedded / static).
     */
    setType(value: AcDbOleObjectType): void;
    /**
     * Gets the OLE object type (link / embedded / static).
     *
     * Prefer {@link getType} when matching ObjectARX naming.
     */
    get oleObjectType(): AcDbOleObjectType;
    set oleObjectType(value: AcDbOleObjectType);
    /**
     * Gets the tile-mode descriptor for this frame.
     */
    get tileMode(): AcDbOleTileMode;
    set tileMode(value: AcDbOleTileMode);
    /**
     * Gets the user-visible OLE type description.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getUserType`. Corresponds to DXF group
     * code **3**.
     */
    getUserType(): string;
    /**
     * Sets the user-visible OLE type description.
     */
    setUserType(value: string): void;
    /**
     * Gets the user-visible OLE type description.
     *
     * Prefer {@link getUserType} when matching ObjectARX naming.
     */
    get userType(): string;
    set userType(value: string);
    /**
     * Gets the linked OLE object name.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getLinkName`.
     */
    getLinkName(): string;
    /**
     * Sets the linked OLE object name.
     */
    setLinkName(value: string): void;
    /**
     * Gets the linked OLE object path.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getLinkPath`.
     */
    getLinkPath(): string;
    /**
     * Sets the linked OLE object path.
     */
    setLinkPath(value: string): void;
    /**
     * Returns the opaque host OLE client item associated with this frame.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::getOleClientItem`. There is no MFC
     * `COleClientItem` in the browser runtime; the value is application-defined.
     */
    getOleClientItem(): unknown;
    /**
     * Associates an opaque host OLE client item with this frame.
     *
     * Mirrors ObjectARX `AcDbOle2Frame::setOleClientItem`.
     */
    setOleClientItem(value: unknown): void;
    /**
     * Returns the full property definition for this OLE 2 frame entity, including
     * general, geometry, and OLE-specific groups.
     *
     * Geometry accessors update location / size / rotation via the ObjectARX-style
     * setters so aspect locking and size preservation stay consistent.
     */
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * @inheritdoc
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets object snap points for this OLE frame.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this OLE frame by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Gets the image blob extracted from the embedded OLE object, when the
     * payload contains a recognizable bitmap / PNG / JPEG / WMF / EMF
     * presentation.
     *
     * Metafile blobs use MIME types `image/wmf` or `image/emf` and must be
     * rasterized by the host renderer (see {@link acdbRasterizeOleMetafile})
     * before WebGL texturing.
     *
     * Extraction is performed lazily on first access and cached until the OLE
     * binary payload changes.
     */
    get image(): Blob | undefined;
    /**
     * Draws the embedded OLE picture when an image can be extracted from the
     * OLE binary payload; otherwise draws a pickable rectangular frame
     * (transparent fill + outline).
     *
     * Excel OLE previews typically arrive as WMF/EMF metafile blobs. Renderers
     * that accept those MIME types (and rasterize them) will show the table
     * picture; others should treat metafiles like missing images.
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity | undefined;
    /** @inheritdoc */
    protected onOleObjectChanged(): void;
    /**
     * Applies frame corners from the OLE2FRAME binary geometry header when
     * present.
     *
     * AutoCAD stores the drawable rectangle inside the OLE payload (the first
     * 0x80 bytes before the MS-CFB document). DWG parsers often expose only the
     * raw blob, and DXF group codes 10/11 are documented as derived from that
     * header — so recovering corners here keeps OLE frames visible for both
     * paths.
     */
    private applyGeometryFromOleObjectData;
    private resolveImage;
    /**
     * Image quad in the same corner order as {@link AcDbRasterImage}:
     * lower-left, lower-right, upper-right, upper-left, then close.
     */
    private imageBoundaryPath;
    /**
     * Writes DXF fields for this OLE 2 frame.
     *
     * Emits the `AcDbOle2Frame` subclass marker and Autodesk OLE2FRAME group
     * codes. Entity-level fields come from {@link AcDbEntity.dxfOutFields};
     * {@link AcDbOleFrame} fields are skipped because OLE2FRAME uses its own
     * layout.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     * @see https://help.autodesk.com/cloudhelp/2018/ENU/AutoCAD-DXF/files/GUID-77747CE6-82C6-4452-97ED-4CEEB38BE960.htm
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private cornerUpperRight;
    private cornerLowerLeft;
    private boundaryPath;
    private syncHeightFromAspect;
    private syncWidthFromAspect;
}
//# sourceMappingURL=AcDbOle2Frame.d.ts.map