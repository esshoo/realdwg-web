import { AcCmColor } from '@mlightcad/common';
import { AcGeBox3d, AcGeIntersectPrimitive, AcGeLoop2dType, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiHatchPatternLine, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbDatabase } from '../database/AcDbDatabase';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Defines the type of hatch pattern.
 */
export declare enum AcDbHatchPatternType {
    /**
     * A user-defined pattern provides a direct method to define a simple hatch pattern using a specified
     * hatch entity linetype. The definition data for user-defined hatch pattern include angle, space and
     * double. "Angle" specifies an angle for the hatch pattern relative to the X axis of the hatch plane
     * in OCS. "Space" defines the vertical distance between two consecutive pattern lines. "Double"
     * specifies that a second set of lines is to be drawn at 90 degrees to the original lines. When
     * specifying a user-defined hatch pattern, you don't need to set the pattern name. AutoCAD designates
     * a default pattern name "U" for all user-defined patterns.
     */
    UserDefined = 0,
    /**
     * A predefined pattern type allows you to select a hatch pattern from the AutoCAD standard hatch
     * pattern file acad.pat in the "support" directory. The file contains many predefined hatch patterns,
     * including ANGLE, ANSI31, BRICK, CLAY, etc. When you use a predefined pattern, you can also specify
     * a scale and angle in order to modify the hatch's appearance. Solid fill is a new predefined pattern
     * type that enables the application to fill in the hatch area with a specified color. The reserved
     * name for this new pattern is "SOLID." SOLID does not appear in the file acad.pat because it has no
     * definition data. To specify a solid, use the keyword "SOLID".
     */
    Predefined = 1,
    /**
     * A custom-defined pattern type stores the pattern in its own PAT file, in which the name of the
     * hatch pattern must match the name of the file. For instance, you must store the TEST hatch pattern
     * in a file named test.pat, and the file must be located in the ACAD search path. When you use a
     * custom-defined pattern, you can also specify a scale and angle in order to modify the hatch's
     * appearance.
     */
    Custom = 2
}
/**
 * Defines the hatch style for determining which areas to hatch.
 */
export declare enum AcDbHatchStyle {
    /**
     * Normal hatch style will hatch inward from the outer loop. If it encounters an internal intersection,
     * it turns off hatching until it encounters another intersection. Thus, areas separated from the
     * outside of the hatched area by an odd number of intersections are hatched, while areas separated by
     * an even number of intersections are not.
     */
    Normal = 0,
    /**
     * Outer hatch style will hatch inward from the outer loop. It turns off hatching if it encounters an
     * intersection and does not turn it back on. Because this process starts from both ends of each hatch
     * line, only the outmost level of the structure is hatched, and the internal structure is left blank.
     */
    Outer = 1,
    /**
     * Ignore hatch style will hatch inward from the outer loop and ignores all internal loops.
     */
    Ignore = 2
}
export declare enum AcDbHatchObjectType {
    /**
     * Indicates that the object is currently a classic hatch
     */
    HatchObject = 0,
    /**
     * Indicates that the object is currently a color gradient
     */
    GradientObject = 1
}
export type AcDbGradientName = 'LINEAR' | 'CYLINDER' | 'INVCYLINDER' | 'SPHERICAL' | 'INVSPHERICAL' | 'HEMISPHERICAL' | 'INVHEMISPHERICAL' | 'CURVED' | 'INVCURVED';
/**
 * Defines the gradient pattern type for hatch.
 */
export declare enum AcDbGradientPatternType {
    /**
     * Indicates that the gradient name refers to one of the predefined gradient patterns
     */
    PreDefinedGradient = 0,
    /**
     * Indicates that the gradient name refers to one of the user-defined gradient patterns.
     */
    UserDefinedGradient = 1
}
/**
 * Represents a hatch entity in AutoCAD.
 *
 * A hatch is a 2D geometric object that fills an area with a pattern of lines, dots, or other shapes.
 * Hatches are commonly used to represent materials, textures, or to distinguish different areas in drawings.
 *
 * @example
 * ```typescript
 * // Create a hatch entity
 * const hatch = new AcDbHatch();
 * hatch.patternName = "ANSI31";
 * hatch.patternType = AcDbHatchPatternType.Predefined;
 * hatch.patternScale = 1.0;
 * hatch.patternAngle = 0;
 * hatch.hatchStyle = AcDbHatchStyle.Normal;
 *
 * // Add a loop to define the hatch boundary
 * const loop = new AcGeLoop2d();
 * loop.add(new AcGePoint2d(0, 0));
 * loop.add(new AcGePoint2d(10, 0));
 * loop.add(new AcGePoint2d(10, 5));
 * loop.add(new AcGePoint2d(0, 5));
 * hatch.add(loop);
 *
 * // Access hatch properties
 * console.log(`Pattern name: ${hatch.patternName}`);
 * console.log(`Pattern scale: ${hatch.patternScale}`);
 * ```
 */
export declare class AcDbHatch extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The underlying geometric area object */
    private _geo;
    /**
     * Cached result of {@link buildAreasFromLoops}. Cleared when loops change
     * (`add`, `transformBy`, grip edits).
     */
    private _areasFromLoopsCache;
    /** The flag to indicate whether the hatch object is configured for solid fill */
    private _isSolidFill;
    /** The elevation (Z-coordinate) of the hatch plane */
    private _elevation;
    /** Extrusion direction / plane normal (DXF group 210). */
    private _normal;
    /** The definition lines for the hatch pattern */
    private _definitionLines;
    /** Whether current definition lines were generated from a predefined PAT entry. */
    private _definitionLinesAutoGenerated;
    /** Pattern name used for the current auto-generated definition lines. */
    private _definitionLinesPatternName;
    /** Pattern scale used for the current auto-generated definition lines. */
    private _definitionLinesPatternScale;
    /** The name of the hatch pattern */
    private _patternName;
    /** Whether the pattern name was assigned explicitly instead of coming from HPNAME. */
    private _patternNameSet;
    /** The type of hatch pattern */
    private _patternType;
    /** The angle of the hatch pattern in radians */
    private _patternAngle;
    /** Whether the pattern angle was assigned explicitly instead of coming from HPANG. */
    private _patternAngleSet;
    /** The scale factor for the hatch pattern */
    private _patternScale;
    /** Whether the pattern scale was assigned explicitly instead of coming from HPSCALE. */
    private _patternScaleSet;
    /** Whether this hatch is associated with its defining boundary objects. */
    private _associative;
    /** Whether associativity was assigned explicitly instead of coming from HPASSOC. */
    private _associativeSet;
    /** Optional background color for hatch patterns. */
    private _backgroundColor?;
    /** Whether the background color was assigned explicitly instead of coming from HPBACKGROUNDCOLOR. */
    private _backgroundColorSet;
    /** Whether user-defined hatch pattern doubling is enabled. */
    private _patternDouble;
    /** Whether pattern doubling was assigned explicitly instead of coming from HPDOUBLE. */
    private _patternDoubleSet;
    /** The hatch style for determining which areas to hatch */
    private _hatchStyle;
    /** Whether the hatch style was assigned explicitly instead of coming from HPISLANDDETECTION. */
    private _hatchStyleSet;
    /**
     * The current state of the gradient object.
     */
    private _hatchObjectType;
    /** The angle, in radians, at which the current gradient definition is applied. */
    private _gradientAngle;
    /**
     * The current interpolation value between the gradient definition's default and shifted
     * values. The default is 0.0f.
     */
    private _gradientShift;
    /**The one-color tint shade (luminance) value. */
    private _shadeTintValue;
    /** Optional start color for gradient fill, stored as packed 0xRRGGBB. */
    private _gradientStartColor?;
    /** Optional end color for gradient fill, stored as packed 0xRRGGBB. */
    private _gradientEndColor?;
    /**
     * Pixel size used to determine the density for intersection and ray-casting
     * operations in hatch pattern computation for associative hatches and
     * hatches created with the Flood method (DXF group 47).
     */
    private _pixelSize?;
    /** The type of the gradient pattern. */
    private _gradientType;
    /** The name of the current gradient. */
    private _gradientName;
    /**
     * Indicates whether the gradient hatch is transitioning from a start to a stop color (two-color)
     * or from a color to an adjusted luminance version of the same color (one-color). In the latter
     * case, the full luminance version is the "tint" and the zero luminance version is the "shade."
     */
    private _gradientOneColorMode;
    /**
     * Creates a new hatch entity.
     *
     * This constructor initializes a hatch with default values.
     * The elevation is 0, pattern type is Predefined, pattern scale is 1,
     * pattern angle is 0, and hatch style is Normal.
     *
     * @example
     * ```typescript
     * const hatch = new AcDbHatch();
     * hatch.patternName = "ANSI31";
     * hatch.patternScale = 2.0;
     * ```
     */
    constructor();
    /**
     * Gets whether the hatch object is currently a gradient object.
     */
    get isGradient(): boolean;
    /**
     * Gets whether the hatch object is currently using a hatched pattern.
     */
    get isHatch(): boolean;
    /**
     * Gets whether the hatch object is configured for solid fill.
     */
    get isSolidFill(): boolean;
    /**
     * Sets whether the hatch object is configured for solid fill.
     */
    set isSolidFill(value: boolean);
    /**
     * Gets the effective hatch color.
     *
     * When the hatch does not have an explicit entity color, hatch color follows
     * HPCOLOR first and falls back to CECOLOR when HPCOLOR is unset.
     */
    get color(): AcCmColor;
    /**
     * Sets an explicit hatch entity color.
     */
    set color(value: AcCmColor);
    /**
     * Gets the definition lines for the hatch pattern.
     *
     * @returns Array of hatch pattern lines
     *
     * @example
     * ```typescript
     * const definitionLines = hatch.definitionLines;
     * console.log(`Number of definition lines: ${definitionLines.length}`);
     * ```
     */
    get definitionLines(): AcGiHatchPatternLine[];
    /**
     * The pattern name of this hatch.
     */
    get patternName(): string;
    set patternName(value: string);
    /**
     * The pattern name of this hatch.
     */
    get patternType(): AcDbHatchPatternType;
    set patternType(value: AcDbHatchPatternType);
    /**
     * The pattern angle (in radians) of this hatch.
     */
    get patternAngle(): number;
    set patternAngle(value: number);
    /**
     * The pattern scale of the hatch entity. It is a non-zero positive number.
     */
    get patternScale(): number;
    set patternScale(value: number);
    /**
     * Indicates whether this hatch is associative with its defining boundary objects.
     */
    get associative(): boolean;
    set associative(value: boolean);
    /**
     * Optional background color of this hatch pattern.
     */
    get backgroundColor(): AcCmColor | undefined;
    set backgroundColor(value: AcCmColor | undefined);
    /**
     * Indicates whether user-defined hatch pattern doubling is enabled.
     */
    get patternDouble(): boolean;
    set patternDouble(value: boolean);
    /**
     * The pattern style of the hatch entity.
     */
    get hatchStyle(): AcDbHatchStyle;
    set hatchStyle(value: AcDbHatchStyle);
    /**
     * The elevation (Z-coordinate) of the hatch plane.
     */
    get elevation(): number;
    set elevation(value: number);
    /**
     * Extrusion direction / plane normal (DXF group 210).
     */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the current state of the gradient object.
     */
    get hatchObjectType(): AcDbHatchObjectType;
    /**
     * Sets the current state of the gradient object.
     */
    set hatchObjectType(value: AcDbHatchObjectType);
    /**
     * Gets the angle, in radians, at which the current gradient definition is applied.
     */
    get gradientAngle(): number;
    /**
     * Sets the angle, in radians, at which the current gradient definition is applied.
     */
    set gradientAngle(value: number);
    /**
     * Gets the current interpolation value between the gradient definition's default and shifted
     * values. The default is 0.0f.
     */
    get gradientShift(): number;
    /**
     * Sets the current interpolation value between the gradient definition's default and shifted
     * values. The default is 0.0f.
     */
    set gradientShift(value: number);
    /**
     * Gets the type of the gradient pattern.
     */
    get gradientType(): AcDbGradientPatternType;
    /**
     * Sets the type of the gradient pattern.
     */
    set gradientType(value: AcDbGradientPatternType);
    /**
     * Gets the name of the current gradient.
     */
    get gradientName(): string;
    /**
     * Sets the name of the current gradient.
     */
    set gradientName(value: string);
    /**
     * Gets whether the gradient hatch is transitioning from a start to a stop color (two-color).
     */
    get gradientOneColorMode(): boolean;
    /**
     * Sets whether the gradient hatch is transitioning from a start to a stop color (two-color)
     * or from a color to an adjusted luminance version of the same color (one-color). In the latter
     * case, the full luminance version is the "tint" and the zero luminance version is the "shade."
     */
    set gradientOneColorMode(value: boolean);
    /**
     * Gets the one-color tint shade (luminance) value.
     */
    get shadeTintValue(): number;
    /**
     * Sets the one-color tint shade (luminance) value. If the gradient is using one-color mode,
     * this function sets the luminance value applied to the first color.
     */
    set shadeTintValue(value: number);
    /**
     * Gets the optional first gradient color as a packed RGB value.
     */
    get gradientStartColor(): number | undefined;
    /**
     * Sets the optional first gradient color as a packed RGB value.
     */
    set gradientStartColor(value: number | undefined);
    /**
     * Gets the optional second gradient color as a packed RGB value.
     */
    get gradientEndColor(): number | undefined;
    /**
     * Sets the optional second gradient color as a packed RGB value.
     */
    set gradientEndColor(value: number | undefined);
    /**
     * Gets the pixel size used for intersection/ray-casting density
     * calculations (DXF group 47), for associative or Flood-method hatches.
     */
    get pixelSize(): number | undefined;
    /**
     * Sets the pixel size used for intersection/ray-casting density
     * calculations (DXF group 47).
     */
    set pixelSize(value: number | undefined);
    /**
     * Applies the current hatch-related system variables as persistent defaults
     * when this hatch is first added to a database.
     *
     * Imported hatches and programmatically assigned hatch values keep their own
     * explicit settings.
     *
     * @internal
     */
    applyPatternDefaultsFromSysVars(db: AcDbDatabase): void;
    private getEffectivePatternName;
    protected shouldResolveColorFromCecolor(): boolean;
    private getEffectivePatternAngle;
    /**
     * Returns the pattern angle consumed by renderers.
     *
     * Explicit definition lines from DXF (or assigned directly) already include
     * pattern rotation in their angles and offsets. Only lines expanded from
     * bundled PAT entries need the entity-level pattern angle applied again.
     */
    private getRenderablePatternAngle;
    private getEffectivePatternScale;
    private getEffectiveAssociative;
    private normalizePatternScale;
    private normalizeHatchStyle;
    private shouldUseSysVarOverride;
    private parseHpBackgroundColor;
    private parseHpTransparency;
    /**
     * Populates renderable pattern definition lines for predefined hatch names.
     *
     * `patternName`, `patternScale`, and `patternType` are the persistent hatch
     * metadata. Renderers consume `definitionLines`, so newly-created predefined
     * hatches need those lines expanded from the bundled PAT library. Imported
     * files usually already contain explicit definition lines; those are kept
     * intact unless they were previously auto-generated by this object.
     */
    private updatePredefinedPatternDefinitionLines;
    /**
     * Append one loop to loops of this area. If it is the first loop added, it is the outter loop.
     * Otherwise, it is an inner loop.
     * @param loop Input the loop to append
     */
    add(loop: AcGeLoop2dType): void;
    private invalidateAreasFromLoopsCache;
    private buildAreasFromLoops;
    private getCalculatedAreaValue;
    /**
     * The area enclosed by this hatch, including holes.
     */
    get area(): number;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Returns the full property definition for this hatch entity, including
     * general group, pattern group, and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the hatch in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this hatch.
     *
     * Associative hatches do not expose editable grips in AutoCAD. Non-associative
     * hatches return boundary definition points from all loops.
     *
     * @returns Array of grip points as 3D points
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Collects editable grip points from hatch boundary loops.
     */
    private collectBoundaryGripPoints;
    /**
     * Moves one boundary grip point using the same index order as
     * {@link collectBoundaryGripPoints}.
     */
    private moveBoundaryGripPointAt;
    private moveCircArc2dGripPoint;
    private moveEllipseArc2dGripPoint;
    /**
     * Gets the object snap points for hatch boundary geometry.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Solid (non-gradient) hatches that draw as a single `area` call.
     * Multi-loop hatches that become a `group` of areas stay on the legacy path.
     *
     * @internal
     */
    get directBatchPrimitive(): "area" | null;
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Transforms this hatch by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbHatch.d.ts.map