import { AcGePoint2d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
/**
 * Picks the candidate snap point closest to the pick point.
 */
export declare function acdbPickNearestOsnapPoint(pickPoint: AcGePoint3dLike, candidates: readonly AcGePoint3dLike[]): AcGePoint3d | undefined;
/**
 * Collects object snap points for one 3D line segment.
 */
export declare function acdbCollectLineSegmentOsnapPoints(start: AcGePoint3dLike, end: AcGePoint3dLike, osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
/**
 * Collects object snap points for one 2D polyline segment, including bulge arcs.
 */
export declare function acdbCollectPolyline2dSegmentOsnapPoints(start: AcGePoint2d, end: AcGePoint2d, bulge: number | undefined, elevation: number, osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
/**
 * Collects object snap points along a 3D vertex path.
 */
export declare function acdbCollectVertexPathOsnapPoints(vertices: readonly AcGePoint3dLike[], closed: boolean, osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
//# sourceMappingURL=AcDbOsnapHelpers.d.ts.map