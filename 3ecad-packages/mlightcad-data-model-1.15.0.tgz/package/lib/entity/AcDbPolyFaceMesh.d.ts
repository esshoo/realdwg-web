import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a polyface mesh vertex in AutoCAD.
 */
export declare class AcDbPolyFaceMeshVertex {
    /** The 3D position of the vertex */
    position: AcGePoint3d;
    /**
     * Creates a new polyface mesh vertex.
     * @param position The 3D position of the vertex
     */
    constructor(position: AcGePoint3dLike);
}
/**
 * Represents a polyface mesh face in AutoCAD.
 */
export declare class AcDbPolyFaceMeshFace {
    /** The vertex indices for the face */
    vertexIndices: number[];
    /**
     * Creates a new polyface mesh face.
     * @param vertexIndices The vertex indices for the face
     */
    constructor(vertexIndices: number[]);
}
/**
 * Represents a polyface mesh entity in AutoCAD.
 */
export declare class AcDbPolyFaceMesh extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The vertices of the mesh */
    private _vertices;
    /** The faces of the mesh */
    private _faces;
    /**
     * Creates a new polyface mesh entity.
     * @param vertices The vertices of the mesh
     * @param faces The faces of the mesh
     */
    constructor(vertices: AcGePoint3dLike[], faces: number[][]);
    /**
     * Gets the number of vertices in the mesh.
     */
    get numberOfVertices(): number;
    /**
     * Gets the number of faces in the mesh.
     */
    get numberOfFaces(): number;
    /**
     * Gets whether this mesh is closed.
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Sets whether this mesh is closed.
     */
    set closed(_value: boolean);
    /**
     * Gets the vertex at the specified index.
     * @param index The index of the vertex
     */
    getVertexAt(index: number): AcDbPolyFaceMeshVertex;
    /**
     * Gets the face at the specified index.
     * @param index The index of the face
     */
    getFaceAt(index: number): AcDbPolyFaceMeshFace;
    /**
     * Gets the geometric extents (bounding box) of this mesh.
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this mesh.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this mesh.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this polyface mesh by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this mesh entity.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Draws this mesh using the specified renderer.
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Writes this object to the DXF output.
     */
    dxfOut(filer: AcDbDxfFiler, allXdata?: boolean): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the XY boundary of the largest face in the mesh as a closed
     * {@link AcDbPolyline}. When no face records exist, falls back to all mesh vertices
     * in storage order.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Side test uses the same largest-face boundary as {@link getOffsetCurves}.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline around the dominant face boundary, or `null` on failure
     */
    private createOffsetCurve;
    /**
     * Selects the face with the most referenced vertices and returns its XY outline.
     *
     * Face vertex indices follow mesh face records; negative indices are ignored. If no
     * suitable face is found, every mesh vertex position is projected to XY in index order.
     *
     * @returns Closed or open 2D loop used for offset approximation
     */
    private collectLargestFaceBoundary2d;
}
//# sourceMappingURL=AcDbPolyFaceMesh.d.ts.map