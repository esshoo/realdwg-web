import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint2d, AcGePoint3d, AcGePoint3dLike, AcGeVector2d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbObjectId } from '../base/AcDbObject';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Defines the clip boundary type for raster images.
 */
export declare enum AcDbRasterImageClipBoundaryType {
    /** Undefined state */
    Invalid = 0,
    /** Rectangle aligned with the image pixel coordinate system */
    Rect = 1,
    /** Polygon with points entirely within the image boundary */
    Poly = 2
}
/**
 * Defines the display options for raster images.
 */
export declare enum AcDbRasterImageImageDisplayOpt {
    /** Show image (or draw frame only) */
    Show = 1,
    /** Show rotates images (or draw frame only) */
    ShowUnAligned = 2,
    /** Clip image */
    Clip = 4,
    /** Use transparent background for bitonal images (or use opaque background color) */
    Transparent = 8
}
/**
 * Represents a raster image entity in AutoCAD.
 *
 * The AcDbRasterImage entity (or "image entity") works with the AcDbRasterImageDef object
 * (or "image definition object") to implement raster images inside AutoCAD. The relationship
 * between these two classes is much like the relationship between an AutoCAD block definition
 * object and a block insert entity.
 *
 * Two or more image entities can be linked to a single image definition object. Since each
 * image entity has its own clip boundary, this is an efficient way to display different
 * regions of a single raster image at different positions in the drawing.
 *
 * @example
 * ```typescript
 * // Create a raster image entity
 * const rasterImage = new AcDbRasterImage();
 * rasterImage.position = new AcGePoint3d(0, 0, 0);
 * rasterImage.width = 100;
 * rasterImage.height = 75;
 * rasterImage.scale = new AcGeVector2d(1, 1);
 * rasterImage.rotation = 0;
 * rasterImage.brightness = 50;
 * rasterImage.contrast = 50;
 *
 * // Access raster image properties
 * console.log(`Position: ${rasterImage.position}`);
 * console.log(`Width: ${rasterImage.width}`);
 * console.log(`Height: ${rasterImage.height}`);
 * ```
 */
export declare class AcDbRasterImage extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The current brightness value of the image (0-100) */
    private _brightness;
    /** The current contrast value of the image (0-100) */
    private _contrast;
    /** The current fade value of the image (0-100) */
    private _fade;
    /** The width of the image */
    private _width;
    /** The height of the image */
    private _height;
    /** The position of the image in WCS coordinates */
    private _position;
    /** The rotation angle of the image in radians */
    private _rotation;
    /** The scale factors for the image */
    private _scale;
    /** The image size in pixels (U and V values) */
    private _imageSize;
    /** The clip boundary type */
    private _clipBoundaryType;
    /** The clip boundary points */
    private _clipBoundary;
    /** The image definition object ID */
    private _imageDefId;
    /** Whether the image is clipped */
    private _isClipped;
    /** Whether to use clipping boundary */
    private _isShownClipped;
    /** Whether the image is shown */
    private _isImageShown;
    /** Whether the image is transparent */
    private _isImageTransparent;
    /** Class version (DXF group 90) */
    private _classVersion;
    /**
     * Clip mode (DXF group 290): 0 = outside mode, 1 = inside mode.
     */
    private _clipMode;
    /** The image data as a Blob */
    private _image?;
    /**
     * Creates a new raster image entity.
     *
     * This constructor initializes a raster image with default values.
     * The brightness and contrast are set to 50, fade to 0, position to origin,
     * scale to (1,1), rotation to 0, and clip boundary type to Rect.
     *
     * @example
     * ```typescript
     * const rasterImage = new AcDbRasterImage();
     * rasterImage.position = new AcGePoint3d(10, 20, 0);
     * rasterImage.width = 200;
     * rasterImage.height = 150;
     * ```
     */
    constructor();
    /**
     * Gets the current brightness value of the image.
     *
     * @returns The brightness value (0-100)
     *
     * @example
     * ```typescript
     * const brightness = rasterImage.brightness;
     * console.log(`Image brightness: ${brightness}`);
     * ```
     */
    get brightness(): number;
    set brightness(value: number);
    /**
     * The current contrast value of the image.
     */
    get contrast(): number;
    set contrast(value: number);
    /**
     * The current fade value of the image.
     */
    get fade(): number;
    set fade(value: number);
    /**
     * The height of the image.
     */
    get height(): number;
    set height(value: number);
    /**
     * The width of the image.
     */
    get width(): number;
    set width(value: number);
    /**
     * The position of the image in wcs.
     */
    get position(): AcGePoint3d;
    set position(value: AcGePoint3d);
    /**
     * The rotation of the image.
     */
    get rotation(): number;
    set rotation(value: number);
    /**
     * The scale of the image.
     */
    get scale(): AcGeVector2d;
    set scale(value: AcGeVector2d);
    /**
     * The image size in pixels (U and V values).
     */
    get imageSize(): AcGePoint2d;
    set imageSize(value: AcGePoint2d);
    /**
     * The current clip boundary type.
     */
    get clipBoundaryType(): AcDbRasterImageClipBoundaryType;
    set clipBoundaryType(value: AcDbRasterImageClipBoundaryType);
    /**
     * An array of clip boundary vertices in image pixel coordinates.
     */
    get clipBoundary(): AcGePoint2d[];
    set clipBoundary(value: AcGePoint2d[]);
    /**
     * The flag whether the image is clipped.
     */
    get isClipped(): boolean;
    set isClipped(value: boolean);
    /**
     * The flag whether to use clipping boundary.
     */
    get isShownClipped(): boolean;
    set isShownClipped(value: boolean);
    /**
     * The flag whether the image is shown.
     */
    get isImageShown(): boolean;
    set isImageShown(value: boolean);
    /**
     * The flag whether the image is transparent.
     */
    get isImageTransparent(): boolean;
    set isImageTransparent(value: boolean);
    /** Class version (DXF group 90). */
    get classVersion(): number;
    set classVersion(value: number);
    /**
     * Clip mode (DXF group 290): 0 = outside, 1 = inside.
     */
    get clipMode(): number;
    set clipMode(value: number);
    /**
     * The image data of this entity.
     */
    get image(): Blob | undefined;
    set image(value: Blob | undefined);
    /**
     * The object id of an image entity's image definition object.
     */
    get imageDefId(): AcDbObjectId;
    set imageDefId(value: AcDbObjectId);
    /**
     * The file name of the image.
     */
    get imageFileName(): string;
    /**
     * Basename of {@link imageFileName} (path separators stripped).
     * Used for missing-image labels and the property palette.
     */
    get imageDisplayName(): string;
    /**
     * Returns the full property definition for this raster image entity.
     */
    get properties(): AcDbEntityProperties;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * @inheritdoc
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this raster image.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Draws the external image file path centered in the frame when pixel data
     * is missing, sizing the text so the full path fits inside the boundary.
     */
    private drawMissingImageLabel;
    private resolveLabelTextStyle;
    /**
     * Chooses a text height that keeps the full label inside the image frame.
     */
    private fitLabelTextHeight;
    private boundaryCenter;
    /**
     * Local width/height along the first edge and its perpendicular, plus
     * rotation of that edge — works for both rectangular and clipped frames.
     */
    private boundaryLocalSize;
    /**
     * Transforms this raster image by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    private moveUnclippedGripAt;
    private moveClippedBoundaryGripAt;
    protected boundaryPath(): AcGePoint3d[];
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private applyRasterImageDxfIn;
}
//# sourceMappingURL=AcDbRasterImage.d.ts.map