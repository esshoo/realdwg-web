import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
/**
 * Defines the annotation type for leader entities.
 */
export declare enum AcDbLeaderAnnotationType {
    /** Multiline text annotation */
    MText = 0,
    /** Feature control frame annotation */
    Fcf = 1,
    /** Block reference annotation */
    BlockReference = 2,
    /** No annotation */
    NoAnnotation = 3
}
/**
 * Represents a leader entity in AutoCAD.
 *
 * A leader is a dimension-like entity that consists of a line or spline with an arrowhead
 * pointing to a specific object or location, and an annotation (text, block, or feature
 * control frame) at the other end. Leaders are controlled by dimension variable settings
 * and dimension styles.
 *
 * @example
 * ```typescript
 * // Create a leader entity
 * const leader = new AcDbLeader();
 * leader.appendVertex(new AcGePoint3d(0, 0, 0));
 * leader.appendVertex(new AcGePoint3d(5, 5, 0));
 * leader.appendVertex(new AcGePoint3d(10, 5, 0));
 * leader.hasArrowHead = true;
 * leader.hasHookLine = true;
 * leader.annoType = AcDbLeaderAnnotationType.MText;
 *
 * // Access leader properties
 * console.log(`Number of vertices: ${leader.numVertices}`);
 * console.log(`Has arrow head: ${leader.hasArrowHead}`);
 * console.log(`Has hook line: ${leader.hasHookLine}`);
 * ```
 */
export declare class AcDbLeader extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** Whether this leader is spline-fit */
    private _isSplined;
    /** The spline geometry if this leader is spline-fit */
    private _splineGeo?;
    /** Whether this leader has been updated */
    private _updated;
    /** Whether this leader has an arrowhead */
    private _hasArrowHead;
    /** The vertices of the leader line */
    private _vertices;
    /** The dimension style applied to this leader */
    private _dimensionStyle;
    /** Whether this leader has a hook line */
    private _hasHookLine;
    /** Whether the hook line has the same direction as the horizontal vector */
    private _isHookLineSameDirection;
    /** The annotation type for this leader */
    private _annoType;
    private _textHeight;
    private _textWidth;
    private _byBlockColor?;
    private _associatedAnnotation;
    private _normal;
    private _horizontalDirection;
    private _offsetFromBlock?;
    private _offsetFromAnnotation?;
    /**
     * Creates a new leader entity.
     *
     * This constructor initializes a leader with default values.
     * The leader is not spline-fit, has no arrowhead, no hook line,
     * and no annotation type.
     *
     * @example
     * ```typescript
     * const leader = new AcDbLeader();
     * leader.appendVertex(new AcGePoint3d(0, 0, 0));
     * leader.appendVertex(new AcGePoint3d(5, 5, 0));
     * ```
     */
    constructor();
    /**
     * Gets whether this leader is spline-fit.
     *
     * @returns True if the leader is spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * const isSplined = leader.isSplined;
     * console.log(`Leader is spline-fit: ${isSplined}`);
     * ```
     */
    get isSplined(): boolean;
    /**
     * Sets whether this leader is spline-fit.
     *
     * @param value - True to make the leader spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * leader.isSplined = true;
     * ```
     */
    set isSplined(value: boolean);
    /**
     * Gets whether this leader has an arrowhead.
     *
     * @returns True if the leader has an arrowhead, false otherwise
     *
     * @example
     * ```typescript
     * const hasArrowHead = leader.hasArrowHead;
     * console.log(`Leader has arrowhead: ${hasArrowHead}`);
     * ```
     */
    get hasArrowHead(): boolean;
    /**
     * Sets whether this leader has an arrowhead.
     *
     * @param value - True to enable arrowhead, false to disable
     *
     * @example
     * ```typescript
     * leader.hasArrowHead = true;
     * ```
     */
    set hasArrowHead(value: boolean);
    /**
     * Gets whether this leader has a hook line.
     *
     * The "hookline" is the small horizontal line at the end of the leader line
     * just before the annotation.
     *
     * @returns True if the leader has a hook line, false otherwise
     *
     * @example
     * ```typescript
     * const hasHookLine = leader.hasHookLine;
     * console.log(`Leader has hook line: ${hasHookLine}`);
     * ```
     */
    get hasHookLine(): boolean;
    /**
     * Sets whether this leader has a hook line.
     *
     * @param value - True to enable hook line, false to disable
     *
     * @example
     * ```typescript
     * leader.hasHookLine = true;
     * ```
     */
    set hasHookLine(value: boolean);
    get isHookLineSameDirection(): boolean;
    set isHookLineSameDirection(value: boolean);
    /**
     * Gets the number of vertices in the leader's vertex list.
     *
     * @returns The number of vertices
     *
     * @example
     * ```typescript
     * const numVertices = leader.numVertices;
     * console.log(`Number of vertices: ${numVertices}`);
     * ```
     */
    get numVertices(): number;
    get vertices(): AcGePoint3d[];
    /**
     * Gets the dimension style applied to this leader.
     *
     * @returns The dimension style name
     *
     * @example
     * ```typescript
     * const dimensionStyle = leader.dimensionStyle;
     * console.log(`Dimension style: ${dimensionStyle}`);
     * ```
     */
    get dimensionStyle(): string;
    /**
     * Sets the dimension style applied to this leader.
     *
     * @param value - The new dimension style name
     *
     * @example
     * ```typescript
     * leader.dimensionStyle = "Standard";
     * ```
     */
    set dimensionStyle(value: string);
    /**
     * Gets the leader's annotation type.
     *
     * @returns The annotation type
     *
     * @example
     * ```typescript
     * const annoType = leader.annoType;
     * console.log(`Annotation type: ${annoType}`);
     * ```
     */
    get annoType(): AcDbLeaderAnnotationType;
    /**
     * Sets the leader's annotation type.
     *
     * @param value - The new annotation type
     *
     * @example
     * ```typescript
     * leader.annoType = AcDbLeaderAnnotationType.MText;
     * ```
     */
    set annoType(value: AcDbLeaderAnnotationType);
    get textHeight(): number;
    set textHeight(value: number);
    get textWidth(): number;
    set textWidth(value: number);
    get byBlockColor(): number | undefined;
    set byBlockColor(value: number | undefined);
    get associatedAnnotation(): string;
    set associatedAnnotation(value: string);
    get normal(): AcGeVector3dLike;
    set normal(value: AcGeVector3dLike);
    get horizontalDirection(): AcGeVector3dLike;
    set horizontalDirection(value: AcGeVector3dLike);
    get offsetFromBlock(): AcGeVector3dLike | undefined;
    set offsetFromBlock(value: AcGeVector3dLike | undefined);
    get offsetFromAnnotation(): AcGeVector3dLike | undefined;
    set offsetFromAnnotation(value: AcGeVector3dLike | undefined);
    /**
     * Appends vertex to the end of the vertex list for this leader. If vertex is not in the plane of the
     * leader, then it will be projected parallel the leader's normal onto the leader's plane and the
     * projection will be appended to the leader's vertex list. If the new vertex is too close to the one
     * next to it (that is, within 1.e-10 for X, Y, and Z), the new vertex will not be appended.
     * @param point Input point (in WCS coordinates) to add to the vertex list
     */
    appendVertex(point: AcGePoint3dLike): void;
    /**
     * Reset the vertex at index to the point point projected (along the plane normal) onto the plane
     * containing the leader. It doesn't reset the vertex if that would cause one of the segments to
     * become zero length (within 1e-10).
     * @param index Input index number (0 based) of the vertex to change
     * @param point Input new point value (in WCS) to use
     */
    setVertexAt(index: number, point: AcGePoint3dLike): this;
    /**
     * Get the point that is the vertex at the location index (0 based) in this leader's vertex array.
     * @param index Input index number (0 based) of the vertex desired
     */
    vertexAt(index: number): AcGePoint3d;
    /**
     * Gets the grip points for this leader.
     *
     * @returns Array of grip points at each leader vertex.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this leader.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * @inheritdoc
     */
    get closed(): boolean;
    set closed(_value: boolean);
    /** @inheritdoc */
    get area(): number;
    /**
     * Transforms this leader by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * This leader always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Builds the leader polyline including the optional horizontal hook line
     * segment that spans the associated annotation width.
     */
    private collectDrawPoints;
    /**
     * Whether a hook line should be rendered for the landing vertex.
     */
    private shouldDrawHookLine;
    /**
     * Computes the hook-line endpoint from the last leader vertex.
     */
    private computeHookLineEndPoint;
    /**
     * Resolves hook-line length using dimension-style gap plus associated MTEXT
     * geometry when available.
     */
    private resolveHookLineLength;
    /**
     * Returns the signed axis along which the hook line extends.
     */
    private resolveHookAxis;
    /**
     * Computes hook span from the landing vertex to the far edge of MTEXT bounds.
     */
    private resolveHookSpanFromMText;
    /**
     * Estimates annotation width from MTEXT content when extents are unavailable.
     */
    private resolveAnnotationWidth;
    private resolveMTextLayoutMetrics;
    /**
     * Scores how closely one MTEXT annotation matches a leader landing vertex.
     */
    private scoreMTextAssociation;
    /**
     * Resolves the dimension style referenced by this leader.
     */
    private resolveDimensionStyle;
    /**
     * Resolves the MTEXT annotation associated with this leader.
     */
    private resolveAssociatedMText;
    private tryGetDatabase;
    private get splineGeo();
    private createSplineIfNeeded;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the leader's vertex path in the XY plane and returns an {@link AcDbPolyline}.
     * Splined leaders are sampled before offsetting; the leader is always treated as an
     * open path.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Side test follows the straight or sampled spline path as an open polyline.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline along the leader path, or `null` when offset fails
     */
    private createOffsetCurve;
    /**
     * Flattens the leader geometry to a 2D vertex list for offset operations.
     *
     * Uses 64 samples from the fit spline when {@link isSplined} is true; otherwise
     * returns the stored WCS vertices projected to XY.
     *
     * @returns Leader path in the XY plane
     */
    private collectPath2d;
    private transformVector;
}
//# sourceMappingURL=AcDbLeader.d.ts.map