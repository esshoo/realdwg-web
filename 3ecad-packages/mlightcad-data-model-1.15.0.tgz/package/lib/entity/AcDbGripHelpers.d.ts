import { AcGePoint3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
/**
 * Invokes a grip move handler for each valid grip index.
 */
export declare function acdbForEachGripIndex(indices: readonly number[], moveAtIndex: (index: number) => void): void;
/**
 * Moves the primary grip point at index 0.
 */
export declare function acdbMovePrimaryGripPointAt(indices: readonly number[], offset: AcGeVector3dLike, point: AcGePoint3d): void;
/**
 * Moves one vertex on a 2D polyline geometry object.
 */
export declare function acdbMovePolyline2dVertexAt(vertices: Array<{
    x: number;
    y: number;
}>, index: number, offset: AcGeVector3dLike): void;
/**
 * Moves indexed points in a mutable point array.
 */
export declare function acdbMovePointArrayGripAt(indices: readonly number[], offset: AcGeVector3dLike, points: readonly AcGePoint3d[]): void;
//# sourceMappingURL=AcDbGripHelpers.d.ts.map