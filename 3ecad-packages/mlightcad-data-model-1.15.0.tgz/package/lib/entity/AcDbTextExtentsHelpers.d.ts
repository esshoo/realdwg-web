import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiMTextAttachmentPoint } from '@mlightcad/graphic-interface';
/**
 * Strips MTEXT control codes and returns plain text for width/line estimation.
 */
export declare function acdbStripMTextControlCodes(text: string): string;
/**
 * Escapes plain text so it renders literally through MTEXT (no control codes).
 *
 * Windows paths are the common case: `\Pictures` would otherwise become a
 * paragraph break (`\P`) plus `ictures`, and `\Screenshots` would start a
 * stack (`\S`) — exactly the garbled missing-image frame labels.
 */
export declare function acdbEscapePlainTextForMText(text: string): string;
/**
 * Strips tolerance cell formatting and returns measurable plain text.
 *
 * GDT font codes such as `{\Fgdt;r}` or `{\Fgdt;n}0.05` embed a single symbol
 * character after the font name. That glyph must not contribute to ASCII width
 * estimation because it is rendered from the GDT SHX font, not the text style.
 */
export declare function acdbStripToleranceCellTextForWidth(text: string): string;
/**
 * Estimates the rendered width of one tolerance frame cell.
 */
export declare function acdbEstimateToleranceCellWidth(cellText: string, textHeight: number, widthFactor?: number): number;
/**
 * Estimates rendered text width from plain text length and height.
 */
export declare function acdbEstimatePlainTextWidth(text: string, textHeight: number, widthFactor?: number): number;
/**
 * Counts logical MTEXT lines after control-code normalization.
 */
export declare function acdbCountMTextLines(text: string): number;
/**
 * Estimates total MTEXT height from line count and line-spacing factor.
 *
 * Baseline distance starts as `lineSpacingFactor × (5/3) × textHeight`
 * (DXF group 44; single spacing is factor `1`). At Least (DXF group 73 = `0`
 * or `1`, the default) grows that distance when it is tighter than the text
 * height, so nominal glyphs do not overlap. Exact (`2`) keeps the factor
 * spacing. This estimate does not measure per-glyph overflow above the text
 * height.
 */
export declare function acdbEstimateMTextHeight(lineCount: number, textHeight: number, lineSpacingFactor: number, lineSpacingStyle?: number): number;
interface LocalBounds {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
}
/**
 * Returns axis-aligned bounds in text-local coordinates relative to the attachment anchor.
 */
export declare function acdbGetLocalBoundsFromAttachment(width: number, height: number, attachment: AcGiMTextAttachmentPoint): LocalBounds;
/**
 * Expands a box with an oriented text rectangle anchored at `anchor`.
 */
export declare function acdbExpandBoxByOrientedTextRect(box: AcGeBox3d, anchor: AcGePoint3dLike, width: number, height: number, attachment: AcGiMTextAttachmentPoint, rotation?: number, direction?: AcGeVector3dLike): AcGeBox3d;
/**
 * Resolved layout metrics for an oriented MTEXT rectangle.
 *
 * All width/height values are expressed in drawing units. Local axes follow
 * AutoCAD MTEXT semantics: the X axis aligns with {@link AcDbMTextLayoutMetrics.direction}
 * (or {@link AcDbMTextLayoutMetrics.rotation} when direction is unset), and the Y axis
 * is the 90-degree counter-clockwise perpendicular in the text plane.
 */
export interface AcDbMTextLayoutMetrics {
    /** Effective text width used for layout, preferring actual extents when available. */
    width: number;
    /** Estimated total text height from line count and line spacing. */
    height: number;
    /** Attachment point that anchors the local bounds to {@link AcDbMTextLayoutMetrics.location}. */
    attachment: AcGiMTextAttachmentPoint;
    /** Rotation angle in radians relative to the text OCS X axis. */
    rotation: number;
    /** Optional direction vector overriding {@link AcDbMTextLayoutMetrics.rotation}. */
    direction?: AcGeVector3d;
    /** Insertion/anchor point of the MTEXT entity in world coordinates. */
    location: AcGePoint3d;
}
/**
 * Padding applied in MTEXT-local coordinates when scoring annotation association.
 *
 * Padding extends the oriented text bounds along local axes:
 * `padX` on local X, `padYAbove` toward local +Y, and `padYBelow` toward local -Y.
 */
export interface AcDbMTextAssociationPadding {
    /** Extra tolerance along the local X axis on both sides of the text bounds. */
    padX: number;
    /** Extra tolerance toward local +Y (above the oriented top edge). */
    padYAbove: number;
    /** Extra tolerance toward local -Y (below the oriented bottom edge). */
    padYBelow: number;
}
/**
 * Resolves oriented MTEXT layout metrics used for association and hook-line math.
 *
 * Width resolution order matches {@link AcDbMText.geometricExtents}:
 * `extentsWidth` → `width` → estimated plain-text width.
 *
 * @param input - Raw MTEXT properties used to derive oriented layout metrics.
 * @param input.contents - MTEXT contents, used for line-count and width estimation.
 * @param input.height - Text height in drawing units.
 * @param input.width - Reference/wrap width from the entity.
 * @param input.extentsWidth - Cached actual rendered width from the source file.
 * @param input.lineSpacingFactor - Line spacing factor (DXF group 44 semantics).
 * @param input.lineSpacingStyle - Line spacing style (DXF group 73). `2` is Exact;
 *   omitted, `0`, and `1` are At Least.
 * @param input.attachmentPoint - Attachment point for local bound anchoring.
 * @param input.rotation - Text rotation in radians.
 * @param input.direction - Text direction vector; takes precedence over rotation when non-zero.
 * @param input.location - MTEXT insertion point in world coordinates.
 * @returns Normalized layout metrics with cloned direction/location values.
 */
export declare function acdbResolveMTextLayoutMetrics(input: {
    contents: string;
    height: number;
    width: number;
    extentsWidth: number;
    lineSpacingFactor: number;
    lineSpacingStyle?: number;
    attachmentPoint: AcGiMTextAttachmentPoint;
    rotation: number;
    direction: AcGeVector3d;
    location: AcGePoint3dLike;
}): AcDbMTextLayoutMetrics;
/**
 * Converts a world-space point into MTEXT-local coordinates.
 *
 * Local X/Y are dot-product projections onto the oriented text axes derived
 * from {@link AcDbMTextLayoutMetrics.rotation} and
 * {@link AcDbMTextLayoutMetrics.direction}.
 *
 * @param point - Point to convert, typically a leader landing vertex.
 * @param layout - Resolved MTEXT layout metrics.
 * @returns Local coordinates `{ x, y }` relative to {@link AcDbMTextLayoutMetrics.location}.
 */
export declare function acdbWorldPointToMTextLocal(point: AcGePoint3dLike, layout: AcDbMTextLayoutMetrics): {
    x: number;
    y: number;
};
/**
 * Returns the four corners of an oriented MTEXT rectangle in world space.
 *
 * Corners are ordered counter-clockwise starting from
 * `(minX, minY)` in local coordinates.
 *
 * @param layout - Resolved MTEXT layout metrics.
 * @returns World-space corner points of the oriented text bounds.
 */
export declare function acdbCollectMTextOrientedCorners(layout: AcDbMTextLayoutMetrics): AcGePoint3d[];
/**
 * Scores how closely one world point matches an oriented MTEXT annotation.
 *
 * The score is the Manhattan distance from the point to the inner text bounds
 * in local coordinates. A score of `0` means the point lies inside the
 * oriented bounds; larger values indicate proximity within the padded region.
 *
 * @param point - Candidate association point, usually a leader landing vertex.
 * @param layout - Resolved MTEXT layout metrics.
 * @param padding - Local-axis padding applied before rejecting a candidate.
 * @returns Association score, or `null` when the point is outside padded bounds.
 */
export declare function acdbScorePointAgainstMTextLayout(point: AcGePoint3dLike, layout: AcDbMTextLayoutMetrics, padding: AcDbMTextAssociationPadding): number | null;
export {};
//# sourceMappingURL=AcDbTextExtentsHelpers.d.ts.map