import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a polygon mesh vertex in AutoCAD.
 */
export declare class AcDbPolygonMeshVertex {
    /** The 3D position of the vertex */
    position: AcGePoint3d;
    /**
     * Creates a new polygon mesh vertex.
     * @param position The 3D position of the vertex
     */
    constructor(position: AcGePoint3dLike);
}
/**
 * Represents a polygon mesh entity in AutoCAD.
 */
export declare class AcDbPolygonMesh extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The number of vertices in the M direction */
    private _mCount;
    /** The number of vertices in the N direction */
    private _nCount;
    /** Whether the mesh is closed in the M direction */
    private _closedM;
    /** Whether the mesh is closed in the N direction */
    private _closedN;
    /** The vertices of the mesh */
    private _vertices;
    /**
     * Creates a new polygon mesh entity.
     * @param mCount The number of vertices in the M direction
     * @param nCount The number of vertices in the N direction
     * @param vertices The vertices of the mesh
     * @param closedM Whether the mesh is closed in the M direction
     * @param closedN Whether the mesh is closed in the N direction
     */
    constructor(mCount: number, nCount: number, vertices: AcGePoint3dLike[], closedM?: boolean, closedN?: boolean);
    /**
     * Gets the number of vertices in the M direction.
     */
    get mCount(): number;
    /**
     * Gets the number of vertices in the N direction.
     */
    get nCount(): number;
    /**
     * Gets whether the mesh is closed in the M direction.
     */
    get closedM(): boolean;
    /**
     * Gets whether the mesh is closed in the N direction.
     */
    get closedN(): boolean;
    /**
     * Gets whether this mesh is closed.
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Sets whether this mesh is closed.
     */
    set closed(value: boolean);
    /**
     * Gets the number of vertices in the mesh.
     */
    get numberOfVertices(): number;
    /**
     * Gets the vertex at the specified index.
     * @param index The index of the vertex
     */
    getVertexAt(index: number): AcDbPolygonMeshVertex;
    /**
     * Gets the vertex at the specified M and N coordinates.
     * @param m The M coordinate
     * @param n The N coordinate
     */
    getVertexAtMN(m: number, n: number): AcDbPolygonMeshVertex;
    /**
     * Gets the geometric extents (bounding box) of this mesh.
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this mesh.
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this mesh.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this polygon mesh by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this mesh entity.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Draws this mesh using the specified renderer.
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Writes this object to the DXF output.
     */
    dxfOut(filer: AcDbDxfFiler, allXdata?: boolean): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the mesh perimeter in XY: a single row/column for degenerate meshes, or a
     * counter-clockwise walk around the M×N grid when both dimensions exceed one.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Uses the same perimeter path and closed flag as {@link getOffsetCurves}.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * @param offsetDist - Signed offset distance in drawing units
     * @returns Offset polyline along the mesh boundary, or `null` on failure
     */
    private createOffsetCurve;
    /**
     * Whether the collected perimeter should be offset as a closed polygon.
     *
     * Requires both M and N closure flags and at least two vertices along each direction.
     */
    private isBoundaryClosed;
    /**
     * Builds the XY perimeter of the polygon mesh for offset operations.
     *
     * For `M === 1` or `N === 1`, returns the sole row or column. Otherwise traces the
     * outer ring: first column up, last row across, last column down, first row back.
     *
     * @returns Boundary vertices in traversal order
     */
    private collectBoundary2d;
}
//# sourceMappingURL=AcDbPolygonMesh.d.ts.map