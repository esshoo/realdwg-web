import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer, AcGiTextStyle } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a shape entity in AutoCAD.
 *
 * A shape is a planar geometric object that references a shape definition from an
 * SHX font file. Shapes are positioned by an insertion point, scaled by {@link size}
 * and {@link widthFactor}, and oriented by {@link rotation}, {@link oblique}, and
 * {@link normal}. This class mirrors {@link AcDbShape} in ObjectARX.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbShape
 *
 * @example
 * ```typescript
 * const shape = new AcDbShape();
 * shape.name = 'ARROW';
 * shape.position = new AcGePoint3d(10, 20, 0);
 * shape.size = 2.5;
 * shape.rotation = Math.PI / 4;
 * ```
 */
export declare class AcDbShape extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The insertion point of the shape in WCS coordinates. */
    private _position;
    /** The height of the shape. */
    private _size;
    /** The name of the shape within the associated SHX font. */
    private _name;
    /** The rotation angle relative to the shape OCS X axis, in radians. */
    private _rotation;
    /** The relative X-scale factor (width factor). */
    private _widthFactor;
    /** The oblique angle relative to the shape vertical, in radians. */
    private _oblique;
    /** The thickness along {@link normal}. */
    private _thickness;
    /** The normal vector of the plane containing the shape, in WCS coordinates. */
    private _normal;
    /** The numeric shape code within the SHX font. */
    private _shapeNumber;
    /** The text style name that references the SHX font for this shape. */
    private _styleName;
    /**
     * Creates a new shape entity at the origin with unit size and no rotation.
     */
    constructor();
    /**
     * Gets the insertion point of this shape in WCS coordinates.
     *
     * Mirrors `AcDbShape::position()` in ObjectARX.
     */
    get position(): AcGePoint3d;
    /** Sets the insertion point of this shape in WCS coordinates. */
    set position(value: AcGePoint3dLike);
    /**
     * Gets the height of this shape.
     *
     * Mirrors `AcDbShape::size()` in ObjectARX.
     */
    get size(): number;
    /** Sets the height of this shape. */
    set size(value: number);
    /**
     * Gets the name of the shape within the associated SHX font.
     *
     * Mirrors `AcDbShape::name()` in ObjectARX.
     */
    get name(): string;
    /** Sets the name of the shape within the associated SHX font. */
    set name(value: string);
    /**
     * Gets the rotation angle of this shape in radians.
     *
     * The angle is relative to the X axis of the shape OCS, with positive angles
     * going counterclockwise when looking down the Z axis toward the origin.
     *
     * Mirrors `AcDbShape::rotation()` in ObjectARX.
     */
    get rotation(): number;
    /** Sets the rotation angle of this shape in radians. */
    set rotation(value: number);
    /**
     * Gets the width factor applied to this shape.
     *
     * Mirrors `AcDbShape::widthFactor()` in ObjectARX.
     */
    get widthFactor(): number;
    /** Sets the width factor applied to this shape. */
    set widthFactor(value: number);
    /**
     * Gets the oblique angle of this shape in radians.
     *
     * Mirrors `AcDbShape::oblique()` in ObjectARX.
     */
    get oblique(): number;
    /** Sets the oblique angle of this shape in radians. */
    set oblique(value: number);
    /**
     * Gets the thickness of this shape along {@link normal}.
     *
     * Mirrors `AcDbShape::thickness()` in ObjectARX.
     */
    get thickness(): number;
    /** Sets the thickness of this shape. */
    set thickness(value: number);
    /**
     * Gets the normal vector of the plane containing this shape.
     *
     * Mirrors `AcDbShape::normal()` in ObjectARX.
     */
    get normal(): AcGeVector3d;
    /** Sets the normal vector of the plane containing this shape. */
    set normal(value: AcGeVector3dLike);
    /**
     * Gets the numeric shape code within the SHX font.
     *
     * Mirrors `AcDbShape::shapeNumber()` in ObjectARX.
     */
    get shapeNumber(): number;
    /** Sets the numeric shape code within the SHX font. */
    set shapeNumber(value: number);
    /**
     * Gets the object ID of the text style table record that references this
     * shape's SHX font.
     *
     * Mirrors `AcDbShape::styleId()` in ObjectARX.
     */
    get styleId(): string;
    /**
     * Sets the text style table record by object ID.
     *
     * Mirrors `AcDbShape::setStyleId()` in ObjectARX.
     */
    set styleId(value: string);
    /**
     * Gets the text style name associated with this shape.
     *
     * Used when reading or writing DXF group code 3 (shape file/style name).
     */
    get styleName(): string;
    /** Sets the text style name associated with this shape. */
    set styleName(value: string);
    /**
     * Gets whether this shape is planar.
     *
     * Mirrors `AcDbShape::isPlanar()` in ObjectARX.
     */
    get isPlanar(): boolean;
    get geometricExtents(): AcGeBox3d;
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    transformBy(matrix: AcGeMatrix3d): this;
    get properties(): AcDbEntityProperties;
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Glyph identity passed to renderers.
     *
     * Purely numeric names are treated as shape codes (common for DWG→DXF
     * exports). Renderers look up by name only when a non-numeric name is set,
     * so keeping `"9"` as a name would hide glyphs that exist only by code.
     */
    private renderGlyphIdentity;
    /**
     * Gets the text style that references the SHX font for this shape.
     *
     * When {@link styleName} is empty, returns `undefined` so renderers search
     * shape-file definition entries in the STYLE table instead of falling back to
     * `$TEXTSTYLE` (which is for TEXT/MTEXT, not SHAPE entities).
     */
    protected getTextStyle(): AcGiTextStyle | undefined;
    /**
     * DXF group 2 identity for this shape.
     *
     * Autodesk documents group 2 as the shape name. DWG stores only the numeric
     * shape index; CadLib / libredwg treat post-R12 DXF group 2 as that index
     * when no name is available. Prefer an explicit name (DXF-sourced), otherwise
     * fall back to the shape number so round-trips from DWG stay resolvable.
     */
    private get dxfShapeIdentity();
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbShape.d.ts.map