import { AcGeBox3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbEntityProperties, AcDbEntityPropertyGroup } from './AcDbEntityProperties';
import { AcDbFrame } from './AcDbFrame';
/**
 * Represents a legacy OLE 1 frame entity in AutoCAD.
 *
 * {@link AcDbOleFrame} stores the raw OLE binary payload for an embedded OLE
 * object. Prefer {@link AcDbOle2Frame} for OLE 2 objects, which also expose
 * frame geometry and display attributes.
 *
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-AcDbOleFrame
 * @see https://help.autodesk.com/view/OARX/2024/ENU/?guid=OARX-RefGuide-__MEMBERTYPE_Methods_AcDbOleFrame
 *
 * @example
 * ```typescript
 * const oleFrame = new AcDbOleFrame()
 * oleFrame.oleVersion = 1
 * oleFrame.setOleObject(binaryPayload)
 * ```
 */
export declare class AcDbOleFrame extends AcDbFrame {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** OLE version number (DXF group code 70). */
    private _oleVersion;
    /** Raw OLE binary payload. */
    private _oleObject?;
    /**
     * Creates a new OLE 1 frame entity.
     *
     * Objects created with this constructor must receive a valid OLE payload
     * through {@link setOleObject} before they represent a complete OLE entity.
     */
    constructor();
    /**
     * Gets the OLE version number stored with this frame.
     *
     * Corresponds to DXF group code **70**.
     */
    get oleVersion(): number;
    /**
     * Sets the OLE version number stored with this frame.
     *
     * @param value - OLE version number (DXF group code **70**).
     */
    set oleVersion(value: number);
    /**
     * Returns the raw OLE object data associated with this frame.
     *
     * Mirrors ObjectARX `AcDbOleFrame::getOleObject`. In this TypeScript port the
     * payload is exposed as a byte array rather than an opaque MFC pointer.
     *
     * @returns A copy of the stored OLE bytes, or `undefined` when unset.
     */
    getOleObject(): Uint8Array | undefined;
    /**
     * Sets the raw OLE object data associated with this frame.
     *
     * Mirrors ObjectARX `AcDbOleFrame::setOleObject`. The supplied buffer is
     * copied so later mutations of the caller's array do not affect this entity.
     *
     * @param value - OLE binary payload, or `null`/`undefined` to clear.
     */
    setOleObject(value?: Uint8Array | ArrayBuffer | null): void;
    /**
     * Loads OLE binary data from DXF group codes **90** / **310**.
     *
     * @param length - Expected byte length from group code **90**.
     * @param data - Decoded binary payload (already converted from hex chunks).
     */
    loadOleObjectFromDxf(length: number | undefined, data?: Uint8Array | null): void;
    /**
     * Raw OLE payload retained by this frame (no copy).
     *
     * Subclasses use this for decoding presentation data without cloning the
     * buffer on every draw.
     */
    protected get oleObjectData(): Uint8Array | undefined;
    /**
     * Hook invoked when the OLE binary payload changes.
     *
     * Subclasses override this to invalidate cached presentation images.
     */
    protected onOleObjectChanged(): void;
    /**
     * Returns property-group metadata for OLE-frame-specific attributes
     * (currently the OLE version number).
     *
     * Subclasses such as {@link AcDbOle2Frame} merge these properties into their
     * own `ole` group.
     */
    protected getOleProperties(): AcDbEntityPropertyGroup;
    /**
     * Returns the full property definition for this OLE frame entity, including
     * the general group and OLE-specific attributes.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the geometric extents of this OLE frame.
     *
     * Legacy OLEFRAME entities do not store independent corner geometry in DXF;
     * an empty box is returned unless a subclass overrides this property.
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Draws this OLE frame.
     *
     * Legacy OLE 1 frames have no drawable geometry outside the embedded OLE
     * payload, which is not rendered here.
     *
     * @param _renderer - Target graphics renderer.
     */
    subWorldDraw(_renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Writes DXF fields for this OLE frame.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     * @see https://help.autodesk.com/cloudhelp/2018/ENU/AutoCAD-DXF/files/GUID-4A10EF68-35A3-4961-8B15-1222ECE5E8C6.htm
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
}
//# sourceMappingURL=AcDbOleFrame.d.ts.map