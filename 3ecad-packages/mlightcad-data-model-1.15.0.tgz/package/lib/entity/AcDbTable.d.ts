import { AcGeBox3d, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiMTextAttachmentPoint, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import type { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord';
import { AcDbBlockReference } from './AcDbBlockReference';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Interface defining the properties of a table cell within an AcDbTable entity.
 *
 * Table cells can contain various types of content including text, blocks, and other
 * entities. Each cell has properties that control its appearance, content, and behavior.
 */
export interface AcDbTableCell {
    /** The text content displayed in the cell */
    text: string;
    /** The attachment point for text positioning within the cell */
    attachmentPoint: AcGiMTextAttachmentPoint;
    /** Optional text style name for the cell content */
    textStyle?: string;
    /** Optional rotation angle for the cell content in radians */
    rotation?: number;
    /** The type of cell (text, block, etc.) */
    cellType: number;
    /** Optional flag value for cell behavior */
    flagValue?: number;
    /** Optional value indicating merged cell information */
    mergedValue?: number;
    /** Optional auto-fit behavior setting */
    autoFit?: boolean;
    /** Optional border width for merged cells */
    borderWidth?: number;
    /** Optional border height for merged cells */
    borderHeight?: number;
    /** Optional override flag for cell properties */
    overrideFlag?: number;
    /** Optional virtual edge flag for cell borders */
    virtualEdgeFlag?: number;
    /** Optional border visibility overrides (cell-level) */
    topBorderVisibility?: boolean;
    rightBorderVisibility?: boolean;
    bottomBorderVisibility?: boolean;
    leftBorderVisibility?: boolean;
    /** Optional field object ID for text type cells */
    fieldObjetId?: string;
    /** Optional block table record ID for block type cells */
    blockTableRecordId?: string;
    /** Optional scale factor for block type cells */
    blockScale?: number;
    /** Optional number of block attributes */
    blockAttrNum?: number;
    /** Optional array of attribute definition IDs */
    attrDefineId?: string[];
    /** Optional attribute text content */
    attrText?: string | string[];
    /** The height of text in the cell */
    textHeight: number;
    /** Extended cell flags from AutoCAD 2007 and later */
    extendedCellFlags?: number;
    /** Cell value block begin marker (from AutoCAD 2007) */
    cellValueBlockBegin?: string;
}
export interface AcDbTableBorderColors {
    left?: number;
    top?: number;
    insideHorizontal?: number;
    bottom?: number;
    insideVertical?: number;
    right?: number;
}
export interface AcDbTableCellTypeOverride {
    textStyle?: string;
    textHeight?: number;
    alignment?: number;
    backgroundColor?: number;
    contentColor?: number;
    backgroundColorEnabled?: boolean;
    borderLineweights?: {
        top?: number;
        right?: number;
        bottom?: number;
        left?: number;
        insideHorizontal?: number;
        insideVertical?: number;
    };
    borderVisibility?: {
        top?: boolean;
        right?: boolean;
        bottom?: boolean;
        left?: boolean;
        insideHorizontal?: boolean;
        insideVertical?: boolean;
    };
}
/**
 * Represents a table entity in AutoCAD.
 *
 * A table is generally thought of as an n x m rectangular array of cells whose contents
 * consist of annotation objects, primarily text. Tables often contain a title row, a
 * header row, and multiple data rows.
 *
 * After creating a new table object using the constructor, applications usually need to
 * set the table style, number of rows and columns, column width, row height, insert
 * position, width direction, and normal vector. Applications can also enter text or
 * block contents into each cell using methods of this class.
 *
 * Tables are commonly used for bills of materials, schedules, data sheets, and other
 * tabular information in technical drawings and documentation.
 */
export declare class AcDbTable extends AcDbBlockReference {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    private _attachmentPoint;
    private _numRows;
    private _numColumns;
    private _rowHeight;
    private _columnWidth;
    private _cells;
    /** Table data version number (DXF group code 280) */
    tableDataVersion?: number;
    /** Hard pointer ID of the TABLESTYLE object (DXF group code 342) */
    tableStyleId?: string;
    /** Hard pointer ID of the owning BLOCK record (DXF group code 343) */
    owningBlockRecordId?: string;
    /** Horizontal direction vector (DXF group code 11,21,31) */
    horizontalDirection?: AcGeVector3d;
    /** Flag for table value (DXF group code 90) */
    tableValueFlag?: number;
    /** Flag for an override (DXF group code 93) */
    tableOverrideFlag?: number;
    /** Flag for an override of border color (DXF group code 94) */
    borderColorOverrideFlag?: number;
    /** Flag for an override of border lineweight (DXF group code 95) */
    borderLineweightOverrideFlag?: number;
    /** Flag for an override of border visibility (DXF group code 96) */
    borderVisibilityOverrideFlag?: number;
    /** Flow direction; table-level override (DXF group code 70) */
    flowDirection?: number;
    /** Horizontal cell margin; table-level override (DXF group code 40) */
    horizontalCellMargin?: number;
    /** Vertical cell margin; table-level override (DXF group code 41) */
    verticalCellMargin?: number;
    /** Flag for whether the title is suppressed; table-level override (DXF group code 280) */
    suppressTitle?: boolean;
    /** Flag for whether the header row is suppressed; table-level override (DXF group code 281) */
    suppressHeader?: boolean;
    /** Table-level border colors (DXF group codes 63/64/65/66/68/69) */
    tableBorderColors?: AcDbTableBorderColors;
    /** Table-level cell-type overrides (one entry per cell type) */
    cellTypeOverrides?: AcDbTableCellTypeOverride[];
    /** Standard/title/header row data type (DXF group code 97) */
    rowDataTypes?: number[];
    /** Standard/title/header row unit type (DXF group code 98) */
    rowUnitTypes?: number[];
    /** Standard/title/header row format string (DXF group code 4) */
    rowFormats?: string[];
    /**
     * Creates a new table entity.
     *
     * @param name - The name of the table block reference
     * @param numRows - The number of rows in the table
     * @param numColumns - The number of columns in the table
     */
    constructor(name: string, numRows: number, numColumns: number);
    /**
     * Resolves the anonymous table block used for rendering.
     *
     * LibreDWG sometimes omits the block name (`ldata.name`) while still providing
     * the hard-pointer block record handle. Prefer name lookup, then fall back to
     * {@link owningBlockRecordId}.
     */
    get blockTableRecord(): AcDbBlockTableRecord | undefined;
    /**
     * Gets or sets the cell alignment value for this table.
     *
     * This property controls how text is positioned within table cells by default.
     * Individual cells can override this setting with their own attachment point.
     *
     * @returns The default attachment point for table cells
     */
    get attachmentPoint(): AcGiMTextAttachmentPoint;
    set attachmentPoint(value: AcGiMTextAttachmentPoint);
    /**
     * Gets or sets the number of rows in the table.
     *
     * Changing this value will resize the table and may affect existing cell data.
     *
     * @returns The current number of rows in the table
     */
    get numRows(): number;
    set numRows(value: number);
    /**
     * Gets or sets the number of columns in the table.
     *
     * Changing this value will resize the table and may affect existing cell data.
     *
     * @returns The current number of columns in the table
     */
    get numColumns(): number;
    set numColumns(value: number);
    /**
     * Gets the number of contents in the specified cell.
     *
     * @param row - Row index. Must be greater than or equal to 0 and less than the number of rows
     * @param col - Column index. Must be greater than or equal to 0 and less than the number of columns
     * @returns The number of contents in the specified cell
     */
    numContents(row: number, col: number): number;
    /**
     * Gets the row height of the specified row in the table.
     *
     * @param index - Zero-based row index
     * @returns The row height of the specified row in the table
     */
    rowHeight(index: number): number;
    /**
     * Sets the row height for the specified row index in the table.
     *
     * @param index - Zero-based row index
     * @param height - Height to be used for the specified row
     */
    setRowHeight(index: number, height: number): void;
    /**
     * Sets a uniform row height for all the rows in the table.
     *
     * @param height - Height to be used for all the rows in the table
     */
    setUniformRowHeight(height: number): void;
    /**
     * Gets the column width at the specified column index in the table.
     *
     * @param index - Zero-based column index
     * @returns The width of the specified column
     */
    columnWidth(index: number): number;
    /**
     * Sets a uniform column width for all the columns in the table.
     *
     * @param width - Uniform width to be used for all the columns in the table
     */
    setUniformColumnWidth(width: number): void;
    /**
     * Sets the column width at the specified column index in the table.
     *
     * @param index - Zero-based column index
     * @param width - Width to be used for the specified column
     */
    setColumnWidth(index: number, width: number): void;
    /**
     * Resizes row/column/cell storage for DXF import when counts are known.
     */
    resizeGrid(numRows: number, numColumns: number): void;
    /**
     * Gets the cell at the specified index.
     *
     * @param index - Cell index (calculated as row * numColumns + column)
     * @returns The specified cell by index, or undefined if index is out of range
     */
    cell(index: number): AcDbTableCell | undefined;
    /**
     * Sets the cell at the specified index.
     *
     * @param index - Cell index (calculated as row * numColumns + column)
     * @param cell - The cell data to set
     */
    setCell(index: number, cell: AcDbTableCell): void;
    /**
     * Gets the text string in the specified cell.
     *
     * @param row - Integer specifying the zero-based row index for the cell
     * @param col - Integer specifying the zero-based column index for the cell
     * @param content - Content index. Should be greater than or equal to 0 and less than the number of contents
     * @returns The text string in the specified cell
     */
    textString(row: number, col: number, content?: number): string;
    /**
     * Sets the text for the first content at the specified content index.
     *
     * @param row - Integer specifying the zero-based row index for the cell
     * @param col - Integer specifying the zero-based column index for the cell
     * @param text - Text string to set
     */
    setTextString(row: number, col: number, text: string): void;
    /**
     * Checks if the content of the specified cell is empty.
     *
     * @param row - Integer specifying the zero-based row index for the cell
     * @param col - Integer specifying the zero-based column index for the cell
     * @returns True if the content of the specified cell is empty, false otherwise
     */
    isEmpty(row: number, col: number): boolean;
    /**
     * Gets the geometric extents (bounding box) of this table entity.
     *
     * The geometric extents define the minimum bounding box that completely contains
     * the table entity, including all its cells, borders, and content.
     *
     * @returns A 3D bounding box containing the table entity
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Returns the full property definition for this table entity, including
     * general group, table group, and geometry group.
     *
     * The geometry group exposes editable properties via {@link AcDbPropertyAccessor}
     * so the property palette can update the table in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Renders the table entity using the specified graphics renderer.
     *
     * This method draws the table structure including borders, cell content, and text.
     * It handles the rendering of individual cells, merged cells, and applies the
     * appropriate transformations and styling.
     *
     * @param renderer - The graphics renderer used to draw the table
     * @returns The rendered graphics entity representing the table
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity;
    private drawAnonymousTableBlock;
    /**
     * Marks cells as visited to handle merged cell rendering.
     *
     * This method prevents duplicate rendering of merged cells by marking all
     * constituent cells as visited.
     *
     * @param visited - Array tracking which cells have been processed
     * @param currentIndex - Index of the current cell being processed
     * @param columnCount - Total number of columns in the table
     * @param columnSpan - Number of columns this cell spans
     * @param rowSpan - Number of rows this cell spans
     * @private
     */
    private fillVisited;
    /**
     * Gets the text style for a specific cell.
     *
     * This method retrieves the appropriate text style for the cell, falling back
     * to the standard style if no specific style is specified.
     *
     * @param cell - The cell for which to get the text style
     * @returns The text style configuration for the cell
     * @private
     */
    private getTextStyle;
    /**
     * Calculates the text offset within a table cell based on attachment point.
     *
     * This method determines the appropriate positioning offset for text within
     * a cell based on the specified attachment point and cell dimensions.
     *
     * @param textAlign - The text alignment/attachment point value
     * @param width - The width of the cell
     * @param height - The height of the cell
     * @returns A vector representing the text offset from the cell corner
     * @private
     */
    private getTableTextOffset;
    /**
     * Resolves a usable text height for table cells.
     *
     * Some DXF tables omit per-cell text height because their anonymous table block
     * carries the final MTEXT geometry. When that block is unavailable, fall back to
     * a conservative half-row height so the table text still has visible geometry.
     */
    private getCellTextHeight;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private writeCellText;
}
//# sourceMappingURL=AcDbTable.d.ts.map