import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * How characters are distributed between the arc's left and right offsets.
 *
 * Values match DXF group 72 / LibreDWG `alignment`:
 * 1 fit, 2 left, 3 right, 4 center.
 */
export declare enum AcDbArcTextAlignment {
    Fit = 1,
    Left = 2,
    Right = 3,
    Center = 4
}
/**
 * Which way the glyph "up" direction points relative to the arc center.
 *
 * Values match DXF group 71: 1 outward from center, 2 inward to the center.
 */
export declare enum AcDbArcTextDirection {
    OutwardFromCenter = 1,
    InwardToTheCenter = 2
}
/**
 * Which side of the reference arc the text sits on.
 *
 * Values match DXF group 73: 1 convex (outside), 2 concave (inside).
 */
export declare enum AcDbArcTextPosition {
    OnConvexSide = 1,
    OnConcaveSide = 2
}
/** One character of an {@link AcDbArcAlignedText}, placed on the arc. */
export interface AcDbArcAlignedTextGlyph {
    text: string;
    position: AcGePoint3d;
    rotation: number;
}
/**
 * Arc-aligned text created by the AutoCAD Express Tools `ARCTEXT` command.
 *
 * This is not `AcDbText`. The string is laid out along an arc
 * (center, radius, start angle, end angle), one glyph at a time, with its
 * baseline following the arc tangent.
 */
export declare class AcDbArcAlignedText extends AcDbEntity {
    static typeName: string;
    get dxfTypeName(): string;
    private _textString;
    private _textSize;
    private _xScale;
    private _characterSpacing;
    private _styleName;
    private _fontName;
    private _bigFontName;
    private _offsetFromArc;
    private _rightOffset;
    private _leftOffset;
    private _center;
    private _radius;
    private _startAngle;
    private _endAngle;
    private _normal;
    private _characterSet;
    private _pitchAndFamily;
    private _isShx;
    private _isBold;
    private _isItalic;
    private _isUnderlined;
    private _alignment;
    private _isReverse;
    private _wizardFlag;
    private _textPosition;
    private _textDirection;
    private _arcId;
    /** Last DXF group 90 / LibreDWG raw color, when known. */
    private _rawTextColor;
    get textString(): string;
    set textString(value: string);
    /** Text height (DXF group 42). */
    get textSize(): number;
    set textSize(value: number);
    /** Width factor (DXF group 41). */
    get xScale(): number;
    set xScale(value: number);
    /** Extra distance inserted between characters, in drawing units. */
    get characterSpacing(): number;
    set characterSpacing(value: number);
    get styleName(): string;
    set styleName(value: string);
    get fontName(): string;
    set fontName(value: string);
    get bigFontName(): string;
    set bigFontName(value: string);
    /** Radial distance from the reference arc to the text baseline. */
    get offsetFromArc(): number;
    set offsetFromArc(value: number);
    get rightOffset(): number;
    set rightOffset(value: number);
    get leftOffset(): number;
    set leftOffset(value: number);
    /** Arc center in OCS (DXF group 10). */
    get center(): AcGePoint3d;
    set center(value: AcGePoint3dLike);
    get radius(): number;
    set radius(value: number);
    get startAngle(): number;
    set startAngle(value: number);
    get endAngle(): number;
    set endAngle(value: number);
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    get characterSet(): number;
    set characterSet(value: number);
    get pitchAndFamily(): number;
    set pitchAndFamily(value: number);
    get isShx(): boolean;
    set isShx(value: boolean);
    get isBold(): boolean;
    set isBold(value: boolean);
    get isItalic(): boolean;
    set isItalic(value: boolean);
    get isUnderlined(): boolean;
    set isUnderlined(value: boolean);
    get alignment(): AcDbArcTextAlignment;
    set alignment(value: AcDbArcTextAlignment);
    get isReverse(): boolean;
    set isReverse(value: boolean);
    get wizardFlag(): number;
    set wizardFlag(value: number);
    get textPosition(): AcDbArcTextPosition;
    set textPosition(value: AcDbArcTextPosition);
    get textDirection(): AcDbArcTextDirection;
    set textDirection(value: AcDbArcTextDirection);
    /** Handle of the arc this text was created from (DXF group 330). */
    get arcId(): string;
    set arcId(value: string);
    /**
     * Applies the arc-text color (DXF group 90 / LibreDWG `color`).
     *
     * `0` is ByBlock, `256` is ByLayer, `1..255` is an ACI index. Larger values
     * are treated as a CMC color whose high byte is the method.
     */
    applyRawTextColor(raw: number): void;
    /**
     * Encodes the entity color as DXF group 90 / LibreDWG `rawTextColor`.
     *
     * Prefers the last value passed to {@link applyRawTextColor} so DWG→DXF
     * round-trips keep the original packed form.
     */
    rawTextColor(): number;
    /**
     * Places each character on the reference arc.
     *
     * The arc runs counter-clockwise from {@link startAngle} to {@link endAngle}.
     * {@link offsetFromArc} is the gap to the nearest text edge. Inward text
     * sits with its baseline one text height farther from the center.
     */
    glyphPlacements(): AcDbArcAlignedTextGlyph[];
    get geometricExtents(): AcGeBox3d;
    get properties(): AcDbEntityProperties;
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    private getTextStyle;
    private isPlanarInWcs;
    private extrusionMatrix;
    private rotationInWcs;
}
export declare function acdbParseArcAlignedNumber(value: unknown, fallback?: number): number;
//# sourceMappingURL=AcDbArcAlignedText.d.ts.map