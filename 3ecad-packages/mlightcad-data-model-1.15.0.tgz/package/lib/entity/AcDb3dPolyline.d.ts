import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents the spline-fit type for this 3D polyline.
 */
export declare enum AcDbPoly3dType {
    /**
     * A standard polyline with no spline fitting.
     */
    SimplePoly = 0,
    /**
     * A spline-fit polyline that has a Quadratic B-spline path.
     */
    QuadSplinePoly = 1,
    /**
     * A spline-fit polyline that has a Cubic B-spline path.
     */
    CubicSplinePoly = 2
}
/**
 * Represents a 3d polyline entity in AutoCAD.
 */
export declare class AcDb3dPolyline extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The spline-fit type for this 3D polyline */
    private _polyType;
    /** The underlying geometric polyline object */
    private _geo;
    /**
     * Creates a new empty 2d polyline entity.
     */
    constructor(type: AcDbPoly3dType, vertices: AcGePoint3dLike[], closed?: boolean);
    /**
     * Gets the spline-fit type for this 3D polyline.
     *
     * @returns The spline-fit type for this 3D polyline.
     */
    get polyType(): AcDbPoly3dType;
    /**
     * Sets the spline-fit type for this 3D polyline.
     *
     * @param value - The spline-fit type for this 3D polyline.
     */
    set polyType(value: AcDbPoly3dType);
    /**
     * Gets whether this polyline is closed.
     *
     * A closed polyline has a segment drawn from the last vertex to the first vertex,
     * forming a complete loop.
     *
     * @returns True if the polyline is closed, false otherwise
     *
     * @example
     * ```typescript
     * const isClosed = polyline.closed;
     * console.log(`Polyline is closed: ${isClosed}`);
     * ```
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Sets whether this polyline is closed.
     *
     * @param value - True to close the polyline, false to open it
     *
     * @example
     * ```typescript
     * polyline.closed = true; // Close the polyline
     * ```
     */
    set closed(value: boolean);
    get numberOfVertices(): number;
    getPointAt(index: number): AcGePoint3d;
    /**
     * Gets the geometric extents (bounding box) of this polyline.
     *
     * @returns The bounding box that encompasses the entire polyline
     *
     * @example
     * ```typescript
     * const extents = polyline.geometricExtents;
     * console.log(`Polyline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this polyline.
     *
     * Grip points are control points that can be used to modify the polyline.
     * For a polyline, the grip points are all the vertices.
     *
     * @returns Array of grip points (all vertices)
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this polyline.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this 3D polyline by the specified matrix.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this polyline entity, including
     * general group and geometry group.
     *
     * The geometry group exposes properties via {@link AcDbPropertyAccessor} so
     * the property palette can update the polyline in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * This 3d polyline always draws as a single `lineStrip` primitive.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip";
    /**
     * Draws this polyline using the specified renderer.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered polyline entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes the DXF record for the polyline, plus VERTEX/SEQEND records.
     *
     * The extra records are required by the legacy POLYLINE entity format.
     *
     * @param filer - DXF output writer.
     * @param allXdata - When true, emits all XData attached to this entity.
     * @returns The entity instance (for chaining).
     */
    /**
     * Writes this object to the DXF output.
     *
     * @param filer - DXF output writer.
     * @param allXdata - When true, emits all XData attached to this object.
     * @returns The instance (for chaining).
     */
    dxfOut(filer: AcDbDxfFiler, allXdata?: boolean): this;
    /**
     * Writes the POLYLINE entity fields (header) for a 3D polyline.
     *
     * @param filer - DXF output writer.
     * @returns The entity instance (for chaining).
     */
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * {@inheritDoc AcDbCurve.getOffsetCurves}
     *
     * Offsets the XY projection of the 3D path, then restores elevation on each result
     * vertex by interpolating Z from the original polyline segments.
     */
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    /**
     * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
     *
     * Uses the sampled 2D projection of this polyline for the side test.
     */
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    /**
     * Offsets in XY and lifts vertices back to 3D with {@link interpolateZ}.
     *
     * @param offsetDist - Signed offset distance in drawing units
     * @returns A new 3D polyline with the same spline-fit type and closed flag, or `null`
     * when offsetting fails
     */
    private createOffsetCurve;
    /**
     * Samples the underlying geometry into a 2D path used for planar offset.
     *
     * @returns XY points along the 3D polyline projection
     */
    private collectPath2d;
    /**
     * Estimates the Z coordinate at a planar point by projecting onto the original segments.
     *
     * For each segment (respecting {@link closed}), finds the closest point in XY and
     * linearly interpolates Z between the segment endpoints. Used when promoting a 2D
     * offset polyline back to {@link AcDb3dPolyline}.
     *
     * @param x - X coordinate in WCS
     * @param y - Y coordinate in WCS
     * @returns Interpolated elevation, or `0` when the polyline has no vertices
     */
    private interpolateZ;
    private moveVertexAt;
}
//# sourceMappingURL=AcDb3dPolyline.d.ts.map