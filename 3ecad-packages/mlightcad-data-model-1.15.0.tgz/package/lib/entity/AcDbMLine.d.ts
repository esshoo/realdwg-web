import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Defines MLINE justification relative to the style element offsets.
 */
export declare enum AcDbMLineJustification {
    /**
     * Places all style elements below or on the reference path.
     */
    Top = 0,
    /**
     * Centers style elements around the reference path.
     */
    Zero = 1,
    /**
     * Places all style elements above or on the reference path.
     */
    Bottom = 2
}
/**
 * Bit flags used by MLINE entities.
 */
export declare enum AcDbMLineFlags {
    /**
     * Indicates the MLINE currently contains at least one segment vertex.
     */
    HasVertex = 1,
    /**
     * Indicates the MLINE should be treated as a closed loop.
     */
    Closed = 2,
    /**
     * Suppresses cap geometry at the start of the MLINE.
     */
    SuppressStartCaps = 4,
    /**
     * Suppresses cap geometry at the end of the MLINE.
     */
    SuppressEndCaps = 8
}
/**
 * Input payload for one MLINE element in a segment.
 */
export interface AcDbMLineElementLike {
    /**
     * Number of line parameters described in {@link parameters}.
     * If omitted, the count is inferred from the array length.
     */
    parameterCount?: number;
    /**
     * Element parameters where the first value is treated as the miter offset.
     */
    parameters?: number[];
    /**
     * Number of fill parameters described in {@link fillParameters}.
     * If omitted, the count is inferred from the array length.
     */
    fillCount?: number;
    /**
     * Fill parameters used by consumers that need style-specific fill metadata.
     */
    fillParameters?: number[];
}
/**
 * Normalized MLINE element data.
 */
export interface AcDbMLineElement {
    /**
     * Number of values in {@link parameters}.
     */
    parameterCount: number;
    /**
     * Resolved element parameter array.
     */
    parameters: number[];
    /**
     * Number of values in {@link fillParameters}.
     */
    fillCount: number;
    /**
     * Resolved fill parameter array.
     */
    fillParameters: number[];
}
/**
 * Input payload for one MLINE segment.
 */
export interface AcDbMLineSegmentLike {
    /**
     * Segment vertex in world coordinates.
     */
    position: AcGePoint3dLike;
    /**
     * Segment direction vector along the reference path.
     */
    direction: AcGeVector3dLike;
    /**
     * Miter direction used to offset each style element.
     */
    miterDirection: AcGeVector3dLike;
    /**
     * Optional per-element parameter data for this segment.
     */
    elements?: AcDbMLineElementLike[];
}
/**
 * Normalized MLINE segment data.
 */
export interface AcDbMLineSegment {
    /**
     * Segment vertex in world coordinates.
     */
    position: AcGePoint3d;
    /**
     * Segment direction vector along the reference path.
     */
    direction: AcGeVector3d;
    /**
     * Miter direction used to offset each style element.
     */
    miterDirection: AcGeVector3d;
    /**
     * Resolved per-element parameter data for the segment.
     */
    elements: AcDbMLineElement[];
}
/**
 * Represents the AutoCAD MLINE entity.
 */
export declare class AcDbMLine extends AcDbEntity {
    /**
     * Runtime type name used by the entity factory and RTTI helpers.
     */
    static typeName: string;
    /**
     * DXF entity type token written to or read from drawing files.
     */
    get dxfTypeName(): string;
    private _styleName;
    private _styleObjectHandle;
    private _scale;
    private _justification;
    private _flags;
    private _styleCount;
    private _startPosition;
    private _normal;
    private _segments;
    /**
     * Creates a new MLINE entity initialized with AutoCAD-compatible defaults.
     */
    constructor();
    /**
     * Gets the style name used to resolve the MLINE style object.
     *
     * @returns Current style name.
     */
    get styleName(): string;
    /**
     * Sets the style name used to resolve the MLINE style object.
     *
     * @param value New style name.
     */
    set styleName(value: string);
    /**
     * Gets the handle of the referenced MLINESTYLE object.
     *
     * @returns Style object handle.
     */
    get styleObjectHandle(): string;
    /**
     * Sets the handle of the referenced MLINESTYLE object.
     *
     * @param value Style object handle.
     */
    set styleObjectHandle(value: string);
    /**
     * Gets the global scale factor applied to style offsets.
     *
     * @returns MLINE scale.
     */
    get scale(): number;
    /**
     * Sets the global scale factor applied to style offsets.
     *
     * @param value MLINE scale.
     */
    set scale(value: number);
    /**
     * Gets the current justification mode.
     *
     * @returns Justification enum value.
     */
    get justification(): AcDbMLineJustification;
    /**
     * Sets the current justification mode.
     *
     * @param value Justification enum value.
     */
    set justification(value: AcDbMLineJustification);
    /**
     * Gets the raw MLINE bit flags.
     *
     * @returns Bitwise combination of {@link AcDbMLineFlags}.
     */
    get flags(): number;
    /**
     * Sets the raw MLINE bit flags.
     *
     * @param value Bitwise combination of {@link AcDbMLineFlags}.
     */
    set flags(value: number);
    /**
     * Gets the number of style elements expected by the entity.
     *
     * @returns Style element count.
     */
    get styleCount(): number;
    /**
     * Sets the style element count.
     * Negative values are clamped to `0`.
     *
     * @param value Requested style element count.
     */
    set styleCount(value: number);
    /**
     * Gets the MLINE start point in world coordinates.
     *
     * @returns Start point instance.
     */
    get startPosition(): AcGePoint3dLike;
    /**
     * Sets the MLINE start point in world coordinates.
     *
     * @param value New start point.
     */
    set startPosition(value: AcGePoint3dLike);
    /**
     * Gets the MLINE plane normal.
     *
     * @returns Normal vector instance.
     */
    get normal(): AcGeVector3dLike;
    /**
     * Sets the MLINE plane normal.
     *
     * @param value New normal vector.
     */
    set normal(value: AcGeVector3dLike);
    /**
     * Gets a deep-cloned snapshot of all segments.
     * Mutating the returned array or objects will not affect internal state.
     *
     * @returns Cloned segment collection.
     */
    get segments(): AcDbMLineSegmentLike[];
    /**
     * Replaces all segments using normalized internal copies.
     * Also updates the internal `HasVertex` flag.
     *
     * @param value Segment list to normalize and store.
     */
    set segments(value: AcDbMLineSegmentLike[]);
    /**
     * Gets the number of stored segment vertices.
     *
     * @returns Vertex count.
     */
    get vertexCount(): number;
    /**
     * Indicates whether the MLINE is closed.
     *
     * @returns `true` when the `Closed` flag is set.
     */
    get closed(): boolean;
    /**
     * Enables or disables closed-loop behavior.
     *
     * @param value `true` to close the path, otherwise `false`.
     */
    set closed(value: boolean);
    /**
     * Indicates whether start caps are suppressed during rendering.
     *
     * @returns `true` when the `SuppressStartCaps` flag is set.
     */
    get suppressStartCaps(): boolean;
    /**
     * Enables or disables start cap suppression.
     *
     * @param value `true` to suppress start caps.
     */
    set suppressStartCaps(value: boolean);
    /**
     * Indicates whether end caps are suppressed during rendering.
     *
     * @returns `true` when the `SuppressEndCaps` flag is set.
     */
    get suppressEndCaps(): boolean;
    /**
     * Enables or disables end cap suppression.
     *
     * @param value `true` to suppress end caps.
     */
    set suppressEndCaps(value: boolean);
    /**
     * Appends one segment to the MLINE.
     * The segment is normalized into internal geometry instances.
     *
     * @param segment Segment payload to append.
     */
    appendSegment(segment: AcDbMLineSegmentLike): void;
    /**
     * Removes all segments and clears the `HasVertex` flag.
     */
    clearSegments(): void;
    /**
     * Computes a bounding box from renderable MLINE geometry.
     *
     * @returns Axis-aligned 3D extents box.
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Applies a transformation matrix to the full MLINE geometry.
     * Points are transformed directly, while vectors are transformed without
     * introducing translation components.
     *
     * @param matrix Matrix to apply.
     * @returns The same entity instance for chaining.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Exposes editable property metadata for UI/property panels.
     *
     * @returns Entity property definition grouped by category.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this MLINE reference path.
     *
     * Grip points are placed at the start point and each segment vertex,
     * matching AutoCAD MLINE grip behavior on the reference path.
     *
     * @returns Array of grip points as 3D points
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Gets the object snap points for this MLINE reference path.
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Renders this MLINE into one or more graphic interface entities.
     * It draws optional fill first and then style element lines.
     *
     * @param renderer Active graphics renderer.
     * @returns A single entity, an entity group, or `undefined` when nothing is drawable.
     */
    subWorldDraw(renderer: AcGiRenderer): AcGiEntity | undefined;
    /**
     * Serializes MLINE-specific fields to the DXF filer.
     *
     * @param filer DXF writer context.
     * @returns The current entity instance.
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Sets or clears a single MLINE bit flag.
     *
     * @param flag Flag bit to update.
     * @param enabled Whether the flag should be set.
     */
    private setFlag;
    /**
     * Synchronizes the `HasVertex` flag with current segment count.
     */
    private updateHasVertexFlag;
    /**
     * Normalizes segment-like input into internal segment storage.
     *
     * @param segment Segment-like payload.
     * @returns Normalized segment.
     */
    /**
     * Recomputes segment direction vectors affected by moving one reference-path grip.
     *
     * @param gripIndex Zero-based index into {@link subGetGripPoints}.
     */
    private updateReferencePathDirectionsAfterGripMove;
    private createSegment;
    /**
     * Normalizes element-like input and infers count fields when missing.
     *
     * @param element Element-like payload.
     * @returns Normalized element.
     */
    private createElement;
    /**
     * Produces a deep clone of one normalized segment.
     *
     * @param segment Source segment.
     * @returns Deep-cloned segment.
     */
    private cloneSegment;
    /**
     * Collects points that represent all drawable geometry for extents calculation.
     *
     * @returns Geometry point list in world coordinates.
     */
    private collectGeometryPoints;
    /**
     * Calculates how many element paths should be rendered.
     * Uses the max of entity style count, style definition count, and segment data.
     *
     * @param mlineStyle Resolved style object, if available.
     * @returns Renderable element count.
     */
    private getRenderableElementCount;
    /**
     * Builds the un-offset reference polyline path from start point and segments.
     *
     * @returns Reference path points, optionally closed when needed.
     */
    private getReferencePath;
    /**
     * Computes one style element path by offsetting every segment along its miter direction.
     *
     * @param elementIndex Style element index to evaluate.
     * @param mlineStyle Resolved style object, if available.
     * @returns Offset path points, optionally closed when needed.
     */
    private getElementPath;
    /**
     * Resolves the offset distance for an element at a specific segment.
     * Prefers segment element parameters and falls back to style offsets.
     *
     * @param segment Segment to evaluate.
     * @param elementIndex Style element index.
     * @param mlineStyle Resolved style object, if available.
     * @returns Miter offset distance.
     */
    private getElementMiterOffset;
    /**
     * Resolves one element boundary point at the start/end of open MLINE paths.
     *
     * @param side `start` or `end`.
     * @param segment Segment data used to resolve miter offset.
     * @param elementIndex Style element index.
     * @param mlineStyle Resolved style object, if available.
     * @returns Boundary point after cap-angle cut adjustment.
     */
    private getElementBoundaryPoint;
    /**
     * Indicates whether cap-angle cut should be applied at the given side.
     *
     * @param side `start` or `end`.
     * @param mlineStyle Resolved style object, if available.
     * @returns `true` when side has cap components and is not suppressed.
     */
    private shouldApplyCapCutAtSide;
    /**
     * Computes longitudinal cut distance based on cap angle and style-element offset.
     *
     * @param offset Element offset along miter direction.
     * @param angleDegrees Cap angle in degree units.
     * @param side `start` or `end`.
     * @returns Signed distance to move along segment direction.
     */
    private computeCapCutDistance;
    /**
     * Normalizes cap angle from DXF degree units to radians.
     *
     * @param angleDegrees Cap angle in degree units.
     * @returns Safe radian value in `(0, PI)` with 90-degree fallback.
     */
    private normalizeCapAngle;
    /**
     * Resolves forward direction at MLINE start.
     *
     * @returns Unit vector along the first segment.
     */
    private getStartSegmentDirection;
    /**
     * Resolves forward direction at MLINE end.
     *
     * @returns Unit vector along the last visible segment.
     */
    private getEndSegmentDirection;
    /**
     * Creates a fill area between outermost and innermost element paths when style fill is enabled.
     *
     * @param mlineStyle Resolved style object.
     * @param elementCount Total renderable element count.
     * @returns Fill area polygon(s), or `undefined` when fill cannot be formed.
     */
    private createFillArea;
    /**
     * Finds the element indices that define fill boundaries by minimum and maximum reference offsets.
     *
     * @param elementCount Total renderable element count.
     * @param mlineStyle Resolved style object, if available.
     * @returns Outer/inner boundary indices, or `undefined` when not resolvable.
     */
    private getFillBoundaryElementIndices;
    /**
     * Resolves an element's reference offset from first-segment data or style defaults.
     *
     * @param elementIndex Style element index.
     * @param mlineStyle Resolved style object, if available.
     * @returns Reference offset used for boundary comparison.
     */
    private getElementReferenceOffset;
    /**
     * Resolves style-defined element offset to world offset under current
     * justification and entity scale.
     *
     * @param elementIndex Style element index.
     * @param mlineStyle Resolved style object, if available.
     * @returns Final offset distance used for miter displacement.
     */
    private getStyleElementOffset;
    /**
     * Calculates justification shift in style-offset space.
     *
     * - `Zero`: shift = 0
     * - `Top`: highest style offset is moved to 0
     * - `Bottom`: lowest style offset is moved to 0
     *
     * @param mlineStyle Resolved style object, if available.
     * @returns Offset shift before scaling.
     */
    private getStyleJustificationShift;
    /**
     * Removes a duplicated closing vertex when the first and last points are numerically equal.
     *
     * @param points Candidate closed path.
     * @returns Path without duplicated terminal point.
     */
    private stripClosingPoint;
    /**
     * Offsets a point along a miter direction by a scalar distance.
     *
     * @param point Base point.
     * @param miterDirection Offset direction.
     * @param distance Offset distance.
     * @returns Offset point clone.
     */
    private offsetPoint;
    /**
     * Appends the first point to the end of a path when closed mode requires an explicit closure.
     *
     * @param points Path points to inspect.
     * @returns Original or explicitly closed path array.
     */
    private closePathIfNeeded;
    /**
     * Appends style-driven joint/cap entities after element path rendering.
     *
     * @param renderer Active graphics renderer.
     * @param entities Output entity list to append into.
     * @param mlineStyle Resolved style object, if available.
     * @param elementCount Renderable style element count.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     */
    private appendStyleDrivenJointAndCapEntities;
    /**
     * Draws miter connector lines at interior joints when style enables it.
     *
     * @param renderer Active graphics renderer.
     * @param mlineStyle Resolved style object.
     * @param elementCount Renderable style element count.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     * @returns Drawn joint entities.
     */
    private drawMiterJointEntities;
    /**
     * Draws start/end cap entities according to MLINESTYLE cap flags.
     *
     * @param renderer Active graphics renderer.
     * @param mlineStyle Resolved style object.
     * @param elementCount Renderable style element count.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     * @returns Drawn cap entities.
     */
    private drawCapEntities;
    /**
     * Draws one-side cap entities (line/outer-arc/inner-arcs).
     *
     * @param renderer Active graphics renderer.
     * @param side `start` or `end`.
     * @param mlineStyle Resolved style object.
     * @param elementCount Renderable style element count.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     * @returns Drawn one-side cap entities.
     */
    private drawCapEntitiesForSide;
    /**
     * Creates sorted element boundary points for one cap side.
     *
     * @param side `start` or `end`.
     * @param elementCount Renderable style element count.
     * @param mlineStyle Resolved style object.
     * @returns Cap points sorted by descending element offset.
     */
    private getCapElementPoints;
    /**
     * Draws one cap arc between two cap element points.
     *
     * @param renderer Active graphics renderer.
     * @param startPointPair Start element point.
     * @param endPointPair End element point.
     * @param capDirection Outward cap direction.
     * @param traits Mutable renderer traits.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     * @param mlineStyle Resolved style object.
     * @returns Arc entity, or `undefined` when arc cannot be constructed.
     */
    private drawCapArcBetweenElements;
    /**
     * Applies per-element traits while restoring baseline traits first.
     *
     * @param traits Mutable renderer traits.
     * @param originalColor Original trait color.
     * @param originalLineType Original trait linetype.
     * @param mlineStyle Resolved style object.
     * @param elementIndex Style element index.
     */
    private applyElementDrawTraits;
    /**
     * Transforms a vector by matrix rotation/scale only.
     * Translation is canceled by transforming an origin-endpoint pair.
     *
     * @param vector Vector to transform in place.
     * @param matrix Transformation matrix.
     */
    private transformVector;
    /**
     * Resolves the effective MLINE style from database dictionary.
     * Lookup order: handle, exact name, then case-insensitive name match.
     *
     * @returns Matching style object, or `undefined` when no style is found.
     */
    private getMLineStyle;
    /**
     * Applies style-element color and linetype traits to renderer traits.
     * BYBLOCK and BYLAYER colors are ignored.
     *
     * @param mlineStyle Resolved style object.
     * @param elementIndex Style element index.
     * @param traits Mutable renderer trait set.
     */
    private applyStyleElementTraits;
    /**
     * Applies fill color traits from style definition to the renderer traits object.
     * BYBLOCK and BYLAYER colors are ignored.
     *
     * @param mlineStyle Resolved style object.
     * @param traits Mutable renderer trait set.
     */
    private applyFillTraits;
    /**
     * Resolves a style-element linetype token to concrete renderer linetype traits.
     *
     * @param rawLineType Style element linetype token.
     * @returns Resolved linetype traits, or `undefined` when no override is needed.
     */
    private resolveStyleElementLineType;
    /**
     * @inheritdoc
     */
    resolveEffectiveProperties(): void;
    /**
     * Resolves the default style name for newly created MLINE entities.
     */
    private getDefaultStyleName;
}
//# sourceMappingURL=AcDbMLine.d.ts.map