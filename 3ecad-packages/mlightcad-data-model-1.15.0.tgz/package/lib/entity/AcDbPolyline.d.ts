import { AcGeBox3d, AcGeIntersectPrimitive, AcGeMatrix3d, AcGePoint2d, AcGePoint3d, AcGePoint3dLike, AcGePolyline2d, AcGeVector3d, AcGeVector3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbDxfFiler } from '../base/AcDbDxfFiler';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a polyline entity in AutoCAD.
 *
 * A polyline is a complex geometric object composed of connected line segments
 * and/or arc segments. Polylines can have:
 * - Straight line segments
 * - Bulge (arc segments) between vertices
 * - Constant and variable width
 * - Thickness
 * - Multiple vertices
 *
 * Polylines are commonly used for creating complex shapes, paths, and boundaries
 * in drawings.
 *
 * @example
 * ```typescript
 * // Create a polyline
 * const polyline = new AcDbPolyline();
 *
 * // Add vertices to create a rectangle
 * polyline.addVertexAt(0, new AcGePoint2d(0, 0));
 * polyline.addVertexAt(1, new AcGePoint2d(10, 0));
 * polyline.addVertexAt(2, new AcGePoint2d(10, 5));
 * polyline.addVertexAt(3, new AcGePoint2d(0, 5));
 * polyline.closed = true; // Close the polyline
 *
 * // Access polyline properties
 * console.log(`Number of vertices: ${polyline.numberOfVertices}`);
 * console.log(`Is closed: ${polyline.closed}`);
 * ```
 */
export declare class AcDbPolyline extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    get dxfTypeName(): string;
    /** The elevation (Z-coordinate) of the polyline plane */
    private _elevation;
    /** Thickness along the normal (DXF group 39) */
    private _thickness;
    /** Extrusion / plane normal (DXF group 210) */
    private _normal;
    /** The underlying geometric polyline object */
    private _geo;
    /**
     * Creates a new empty polyline entity.
     *
     * This constructor initializes an empty polyline with no vertices.
     * Vertices can be added using the addVertexAt method.
     *
     * @example
     * ```typescript
     * const polyline = new AcDbPolyline();
     * // Add vertices as needed
     * polyline.addVertexAt(0, new AcGePoint2d(0, 0));
     * ```
     */
    constructor();
    /**
     * Gets the number of vertices in this polyline.
     *
     * @returns The number of vertices
     *
     * @example
     * ```typescript
     * const vertexCount = polyline.numberOfVertices;
     * console.log(`Polyline has ${vertexCount} vertices`);
     * ```
     */
    get numberOfVertices(): number;
    /**
     * Gets the elevation of this polyline.
     *
     * The elevation is the distance of the polyline's plane from the WCS origin
     * along the Z-axis.
     *
     * @returns The elevation value
     *
     * @example
     * ```typescript
     * const elevation = polyline.elevation;
     * console.log(`Polyline elevation: ${elevation}`);
     * ```
     */
    get elevation(): number;
    /**
     * Sets the elevation of this polyline.
     *
     * @param value - The new elevation value
     *
     * @example
     * ```typescript
     * polyline.elevation = 10;
     * ```
     */
    set elevation(value: number);
    /**
     * Thickness along the entity normal (DXF group 39).
     */
    get thickness(): number;
    set thickness(value: number);
    /**
     * Extrusion direction / plane normal (DXF group 210).
     */
    get normal(): AcGeVector3d;
    set normal(value: AcGeVector3dLike);
    /**
     * Gets whether this polyline is closed.
     *
     * A closed polyline has a segment drawn from the last vertex to the first vertex,
     * forming a complete loop.
     *
     * @returns True if the polyline is closed, false otherwise
     *
     * @example
     * ```typescript
     * const isClosed = polyline.closed;
     * console.log(`Polyline is closed: ${isClosed}`);
     * ```
     */
    get closed(): boolean;
    /** @inheritdoc */
    get area(): number;
    /**
     * Sets whether this polyline is closed.
     *
     * @param value - True to close the polyline, false to open it
     *
     * @example
     * ```typescript
     * polyline.closed = true; // Close the polyline
     * ```
     */
    set closed(value: boolean);
    /**
     * Adds a vertex to this polyline at the specified index.
     *
     * This method inserts a vertex at the specified position. If the index is 0,
     * the vertex becomes the first vertex. If the index equals the number of vertices,
     * the vertex becomes the last vertex. Otherwise, the vertex is inserted before
     * the specified index.
     *
     * @param index - The index (0-based) before which to insert the vertex
     * @param pt - The vertex location point
     * @param bulge - The bulge value for the vertex (0 for straight line, >0 for arc)
     * @param startWidth - The starting width for the vertex (-1 for default)
     * @param endWidth - The ending width for the vertex (-1 for default)
     *
     * @example
     * ```typescript
     * // Add a straight line vertex
     * polyline.addVertexAt(0, new AcGePoint2d(0, 0));
     *
     * // Add a vertex with arc bulge
     * polyline.addVertexAt(1, new AcGePoint2d(5, 0), 0.5);
     *
     * // Add a vertex with custom width
     * polyline.addVertexAt(2, new AcGePoint2d(10, 0), 0, 2, 1);
     * ```
     */
    addVertexAt(index: number, pt: AcGePoint2d, bulge?: number, startWidth?: number, endWidth?: number): void;
    /**
     * This function removes a vertex from the polyline at the specified index.
     *
     * @param index Input index (0 based) of the vertex to remove
     * @throws Error if the index is out of bounds
     */
    removeVertexAt(index: number): void;
    /**
     * This function resets the polyline by optionally retaining some vertices.
     * If reuse is true, the numVerts number of vertices are left intact and all vertices
     * beyond that number are deleted. If reuse is false, numVerts is ignored and all
     * existing vertex information will be deleted.
     *
     * @param reuse Input Boolean indicating whether or not to retain some vertices
     * @param numVerts Input number of vertices to retain (only used when reuse is true)
     */
    reset(reuse: boolean, numVerts?: number): void;
    /**
     * Gets the 2D location of a vertex at the specified index.
     *
     * The point is returned in the polyline's own object coordinate system (OCS).
     *
     * @param index - The index (0-based) of the vertex
     * @returns The 2D point location of the vertex
     *
     * @example
     * ```typescript
     * const point2d = polyline.getPoint2dAt(0);
     * console.log(`Vertex 0: ${point2d.x}, ${point2d.y}`);
     * ```
     */
    getPoint2dAt(index: number): AcGePoint2d;
    /**
     * Gets the 3D location of a vertex at the specified index.
     *
     * The point is returned in World Coordinates, with the Z-coordinate
     * set to the polyline's elevation.
     *
     * @param index - The index (0-based) of the vertex
     * @returns The 3D point location of the vertex
     *
     * @example
     * ```typescript
     * const point3d = polyline.getPoint3dAt(0);
     * console.log(`Vertex 0: ${point3d.x}, ${point3d.y}, ${point3d.z}`);
     * ```
     */
    getPoint3dAt(index: number): AcGePoint3d;
    /**
     * Gets the geometric extents (bounding box) of this polyline.
     *
     * @returns The bounding box that encompasses the entire polyline
     *
     * @example
     * ```typescript
     * const extents = polyline.geometricExtents;
     * console.log(`Polyline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /** @inheritdoc */
    subGetIntersectCurves(): AcGeIntersectPrimitive[];
    /**
     * Gets the grip points for this polyline.
     *
     * Grip points are control points that can be used to modify the polyline.
     * For a polyline, the grip points are all the vertices. When the **GRIPS**
     * system variable is `2`, midpoint grips are also returned for each segment.
     *
     * @returns Array of grip points (vertices, then optional segment midpoints)
     *
     * @example
     * ```typescript
     * const gripPoints = polyline.subGetGripPoints();
     * // gripPoints contains all vertices of the polyline
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /** @inheritdoc */
    subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike): this;
    /**
     * Returns whether segment midpoint grips should be included.
     *
     * Matches AutoCAD **GRIPS** = `2`.
     */
    private shouldIncludeSegmentMidpointGrips;
    /**
     * Reads the current **GRIPS** system variable value.
     */
    private getGripsMode;
    /**
     * Returns the number of editable polyline segments.
     */
    private getSegmentCount;
    /**
     * Appends one midpoint grip for each polyline segment.
     */
    private appendSegmentMidpointGrips;
    /**
     * Gets the object snap points for this polyline.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this polyline by the specified matrix.
     *
     * The lightweight polyline stores 2D vertices plus a shared elevation, so we
     * transform each vertex in 3D and then write the projected XY values back.
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Returns the full property definition for this polyline entity, including
     * general group and geometry group.
     *
     * The geometry group exposes properties via {@link AcDbPropertyAccessor} so
     * the property palette can update the polyline in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Thin centerline → `lineStrip`; any renderable width → solid `area`.
     *
     * @internal
     */
    get directBatchPrimitive(): "lineStrip" | "area" | null;
    /**
     * Draws this polyline using the specified renderer.
     *
     * This method renders the polyline as a series of connected line segments
     * using the polyline's current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered polyline entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    /**
     * Writes DXF fields for this object.
     *
     * @param filer - DXF output writer.
     * @returns The instance (for chaining).
     */
    dxfOutFields(filer: AcDbDxfFiler): this;
    /**
     * Writes this LWPOLYLINE as a legacy R12 POLYLINE + VERTEX + SEQEND sequence.
     *
     * Used when the target DXF version does not support LWPOLYLINE.
     */
    dxfOutAs2dPolyline(filer: AcDbDxfFiler, _allXdata?: boolean): this;
    dxfInFields(filer: AcDbDxfFiler): this;
    /**
     * Returns a single constant width when every vertex uses that same start and
     * end width; otherwise `undefined` so per-vertex 40/41 codes are written.
     */
    private resolveConstantWidth;
    /**
     * True when any vertex carries a start/end width above the render epsilon.
     * Matches the width gate used by {@link createWidthProfile}.
     */
    private hasRenderableWidth;
    /**
     * Builds a sampled centerline profile carrying interpolated width values.
     *
     * This method converts polyline vertices (including bulge-based arc segments)
     * into a point list where each sampled point stores:
     * - 2D position on the centerline
     * - Effective width at that position
     *
     * For each segment:
     * - Width starts from the segment start vertex `startWidth`
     * - Width ends at the segment start vertex `endWidth`
     * - Width transitions linearly along sampled points
     *
     * Closed polylines avoid duplicating the seam point; open polylines include
     * full start/end coverage.
     *
     * @returns A width profile suitable for wide-line loop construction, or `null`
     * if the polyline has insufficient geometry or no renderable width.
     */
    private createWidthProfile;
    /**
     * Samples one polyline segment into a point sequence.
     *
     * If the start vertex contains a non-zero bulge, this segment is treated as an
     * arc and sampled via {@link AcGeCircArc2d}. Otherwise, the method returns the
     * two segment endpoints as a straight segment.
     *
     * @param startVertex - Segment start vertex. Its `bulge` controls whether arc
     * sampling is used.
     * @param endVertex - Segment end vertex.
     * @returns Sampled points in segment order (start to end), always at least two
     * points for the straight fallback path.
     */
    private sampleSegment;
    /**
     * Constructs a temporary {@link AcDbPolyline} from a planar vertex list.
     *
     * Other curve types use this factory when they need polyline offset or side-test
     * behavior without persisting an intermediate entity in the database. Vertices are
     * added in list order with zero bulge; arc segments are not represented.
     *
     * @param points - 2D vertices in WCS (XY), at least one point
     * @param closed - Whether the path forms a closed loop for offset and side tests
     * @returns A new lightweight polyline with the given topology
     */
    static from2dPoints(points: AcGePoint2d[], closed: boolean): AcDbPolyline;
    /**
     * Creates a polyline entity from {@link AcGePolyline2d} geometry.
     *
     * @param geo - Source polyline geometry
     * @returns Polyline entity with matching vertices and closed flag
     */
    static fromGePolyline(geo: AcGePolyline2d): AcDbPolyline;
    getOffsetCurves(offsetDist: number): AcDbCurve[];
    getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1;
    private createOffsetCurve;
}
/**
 * Offsets a planar vertex path using {@link acgeOffsetVertexPath} and wraps the
 * result as an {@link AcDbPolyline}.
 *
 * @param points - Sampled or vertex-derived 2D path in WCS (XY)
 * @param closed - Whether the path is treated as a closed polygon for offsetting
 * @param offsetDist - Signed offset distance in drawing units (see {@link AcDbCurve#getOffsetCurves})
 * @returns The first offset polyline, or `null` when the path has fewer than two points
 * or offsetting fails
 */
export declare function acdbOffsetVertexPathAsPolyline(points: AcGePoint2d[], closed: boolean, offsetDist: number): AcDbPolyline | null;
//# sourceMappingURL=AcDbPolyline.d.ts.map